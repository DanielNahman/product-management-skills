---
client: <Client legal name>
project: <Project name>
sow_number: <SOW-N>
project_type: ai_plus_sw
phase: development
status: draft                       # draft | in_review | locked
case_doc: ./case.md
linked_specs:
  discovery: ./discovery-spec.md    # path to the signed discovery spec
discovery_locked_at: <YYYY-MM-DD>   # date discovery spec was signed
budget_usd: <number>
funding_notes: <e.g. "$65K AWS Incremental, $X client" — or null>
delivery_partner: Commit
last_updated: <YYYY-MM-DD>
---

# <Client> — <Project> — Development Spec

> This spec extends the signed [discovery spec](./discovery-spec.md) with development-phase detail.
>
> **What's locked at signature** (inherited from discovery, change order required to modify): KPIs, NFRs, Customer-Provided Inputs, Out-of-Scope items, the list of features, and the discovery-level "shall" requirements.
>
> **What's added here:** detailed stories with UX and system behavior, feature-level acceptance criteria, high-level API and data shapes, resolved decisions, open design questions, and links to sibling artifacts (eval set, QA plan).

---

## 1. Business Context

<2–4 sentence anchor: client, business problem, MVP outcome.>

See [`./case.md`](./case.md) for the full business case and [`./discovery-spec.md`](./discovery-spec.md) for the contracted scope.

---

## 2. Reference to Discovery Spec

The following items are **inherited from `./discovery-spec.md`** (signed `<discovery_locked_at>`) and are NOT redefined here. Any change requires a change order:

- **Success Criteria & KPIs** — see discovery-spec §2.
- **Non-Functional Requirements** — see discovery-spec §3.
- **Out of Scope** — see discovery-spec §7.
- **Customer-Provided Inputs** — see discovery-spec §8.
- **Feature list and high-level "shall" requirements** — see discovery-spec §4. These appear below in §4 of this dev spec for traceability, but their *wording* is locked.

If discovery items have been **modified by change order** since signature, list each modification here:

| Date | Item changed | From | To | Change order ref |
|---|---|---|---|---|
| <YYYY-MM-DD> | <e.g. "KPI: classification accuracy"> | <e.g. "≥80%"> | <e.g. "≥85%"> | <CO-1> |

If no change orders, write *"No change orders to date."*

---

## 3. Resolved Assumptions & New Constraints

Discovery-phase assumptions that have been resolved into concrete decisions, plus any new constraints surfaced post-signature.

### Resolved assumptions

| Discovery assumption | Resolved decision | Resolved on |
|---|---|---|
| <e.g. "Prompt management via Langfuse OR AWS Prompt Management"> | <e.g. "Langfuse, hosted at langfuse.commit-internal.com"> | <YYYY-MM-DD> |

### New constraints surfaced post-signature

Constraints that were not in the discovery spec but are now binding (e.g. discovered during architectural review, surfaced by a customer technical contact, learned from a vendor):

- <One constraint per bullet, specific and disputable.>

---

## 4. Scope

Scope is organized as **Epic → Feature → Requirement → Stories**, with feature-level acceptance criteria.

### Hierarchy

- **Epics** and **Features** are inherited from discovery-spec §4 — same names, same descriptions, same IDs.
- **Requirements** (the high-level "shall" statements, IDs like `1.1.3`) are inherited from discovery-spec §4 — same wording, same IDs. They appear here purely for traceability so each story can be walked back to its contracted requirement.
- **Stories** (IDs like `1.1.3.1`, `1.1.3.2`) are NEW in dev. Each story is one implementable unit covering UX and system behavior. Stories are what the Jira-generator skill extracts (for `SW`-typed requirements) and what the eval-md skill seeds eval cases from (for `AI`-typed requirements).
- **Acceptance Criteria** sit at the **feature level** — testable conditions that apply to all stories under that feature. Avoids repetition.

### ID conventions

- Story IDs format: `<epic>.<feature>.<requirement>.<story>` (e.g. `1.1.3.4`).
- Append-only — never renumber. If a story is removed, leave its ID retired.
- Story type inherits from its parent requirement (`SW` or `AI`).

### Story authoring rules

- One implementable unit per story.
- Each story names a UX trigger or system event AND the resulting behavior. *"User taps send → message appears in chat with timestamp, send button briefly disabled until response begins."*
- Compound stories ("X **and** Y" = two unrelated behaviors) get split.
- Stories under `AI`-typed requirements describe the agent's behavior, not deterministic code. *"Agent encounters ambiguous classification → asks clarifying question before classifying."*

---

### Epic 1: <Epic name from discovery-spec>

<Same description as discovery spec.>

#### Feature 1.1: <Feature name from discovery-spec>

<Same description as discovery spec.>

##### Requirement 1.1.1 (SW \| AI): <Discovery-level "shall" statement, verbatim from discovery spec>

**Stories:**

| ID | Story | UX / System Behavior |
|---|---|---|
| 1.1.1.1 | <Story name> | <One sentence describing the trigger and resulting behavior.> |
| 1.1.1.2 | <Story name> | <Trigger → behavior.> |

##### Requirement 1.1.2 (SW \| AI): <Discovery-level "shall" statement>

**Stories:**

| ID | Story | UX / System Behavior |
|---|---|---|
| 1.1.2.1 | <Story name> | <Trigger → behavior.> |

##### Feature 1.1 — Acceptance Criteria

Testable conditions that apply across all stories under Feature 1.1. The Jira-generator copies these into the feature's epic-level Jira issue; the eval-md skill uses AI-relevant criteria to seed eval cases.

- <One self-contained criterion per bullet. Format: "Given X, when Y, then Z" OR a clear assertion the system must satisfy.>
- <Another criterion.>

##### Feature 1.1 — UI References

- **Figma:** <link to frame>
- **Notes:** <Optional feature-level UX notes — cross-screen behavior, design system constraints, etc.>

---

#### Feature 1.2: <Feature name>

<Same description as discovery.>

##### Requirement 1.2.1 (SW \| AI): <"shall" statement>

**Stories:**

| ID | Story | UX / System Behavior |
|---|---|---|
| 1.2.1.1 | <Story name> | <Trigger → behavior.> |

##### Feature 1.2 — Acceptance Criteria

- <Criterion.>

##### Feature 1.2 — UI References

- **Figma:** <link>

---

> *Continue with Epic 2, Epic 3, etc. — same structure throughout. Every requirement from discovery-spec §4 must appear here with at least one story, OR be explicitly removed via change order (logged in §2).*

---

## 5. API Schema (product surface)

> The user-facing input/output of the product only. Internal contracts between components (e.g. lambda-to-lambda, service-to-Bedrock) are the developer's design work and do NOT live here.
>
> What lives here: what the user (or the calling client) sends to the product, and what the product sends back.

For each entry point of the product, describe:
- **What it is** — the user-facing action.
- **Trigger** — when it happens from the user's perspective.
- **Request shape** — conceptual fields the product receives.
- **Response shape** — conceptual fields the product returns.

### Example format:

**Send a chat message**
- Trigger: user taps send in the chatbot UI.
- Request: `{userQuery, sessionId, authJWT, attachedMedia?}`.
- Response: `{assistantResponse, ticketEmitted, error?}`.

**Attach a file**
- Trigger: user picks a file via the upload control.
- Request: `{filename, contentType, sizeBytes, sessionId, authJWT}`.
- Response: `{uploadURL, error?}` — UI uses uploadURL to send the file directly to storage.

<Add one block per user-facing entry point. Don't add internal API calls — those belong in the developer's design docs, not here.>

---

## 6. Storage & Persistence

> A storage inventory: what gets stored, where, and any retention or scope decision the PM owns. Schemas, table structures, and field-level design are the developer's work and do NOT live here.

For each thing the product persists, describe:
- **What's stored** — at the conceptual level (e.g. "user conversations", "uploaded media", "complex tickets").
- **Where** — at the storage-medium level (e.g. "in an S3 bucket", "in a database").
- **Retention / lifecycle** — how long it lives and what happens to it.

### Example format:

- **Complex tickets (JSON):** stored in an S3 bucket. Each ticket persisted on emission and consumed by the HubSpot integration. Retained 90 days, then auto-deleted.
- **Conversation history:** stored in a database, persisted indefinitely while the user's account is active. Includes thread metadata and per-turn messages.
- **Long-term user memory:** stored across sessions so the agent has continuity. Persisted indefinitely while the user's account is active.
- **Uploaded media (images, videos):** stored in an S3 bucket. Auto-deleted 90 days after upload (matches ticket retention).

<Add one bullet per stored thing. Stay at this level — no schemas, no partition keys, no field-level detail.>

---

## 7. Architecture

<Conceptual block diagram, same shape as discovery spec §5. May be slightly enriched if anything was clarified post-signature (specific Bedrock model chosen, specific S3 bucket layout, etc.) but stays conceptual.>

```
<ASCII diagram>
```

**Changes from discovery architecture (if any):**
- <e.g. "Bedrock model selected: Claude Sonnet 4.6 (was 'TBD' at discovery)."> 
- <e.g. "Long-term memory: DynamoDB single-table design (was 'TBD' at discovery)."> 

If nothing changed: *"No changes from discovery-spec §5."*

---

## 8. Open Design Questions

Decisions that need to be made during the dev phase but haven't yet. Each question is tracked explicitly so it doesn't get forgotten.

| ID | Question | Owner | Needed By | Status | Resolution |
|---|---|---|---|---|---|
| Q-1 | <e.g. "Should we cache KB retrieval results across sessions, or keep retrieval per-turn?"> | <e.g. "AI architect"> | <YYYY-MM-DD> | open \| resolved | <If resolved, summarize the decision and link to where it's documented.> |
| Q-2 | <e.g. "What's the retention period for failed-upload media in S3?"> | <e.g. "DevOps"> | <YYYY-MM-DD> | open | |

Resolved questions are kept in this table (not deleted) — they're a record of decisions made during dev.

---

## 9. Sibling Artifacts

Files that work together with this dev spec:

- [`./case.md`](./case.md) — business context and case for the project.
- [`./discovery-spec.md`](./discovery-spec.md) — signed discovery spec; this dev spec inherits from it.
- [`./eval.md`](./eval.md) — eval set definition (AI dev consumes this alongside the dev spec). *Created by the eval-md skill.*
- [`./eval-set.csv`](./eval-set.csv) — the actual eval cases, populated by the client.
- [`./qa.md`](./qa.md) — QA / E2E test plan (created later).
- Figma project: <URL>
- Architecture diagram: <`./architecture.png` or external link>

**For the AI developer:** read this file + `eval.md`. Stories under `AI`-typed requirements are the capability spec.

**For the SW developer:** read this file + the Jira tickets generated from it. Stories under `SW`-typed requirements become Jira stories grouped under feature- and epic-level Jira issues.
