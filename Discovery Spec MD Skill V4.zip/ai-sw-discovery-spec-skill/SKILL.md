---
name: ai-sw-discovery-spec-skill
description: Use when a Commit product manager has just completed discovery meetings for an AI+SW project (chatbots, agents, LLM-powered products mixed with traditional software) and needs to produce the discovery-spec.md that feeds the SOW Excel and downstream Jira/eval skills. Triggers on requests like "write the discovery spec", "create the spec md from these notes", "I just finished discovery, help me structure it", or when a PM uploads meeting notes/transcripts and asks for a structured spec.
---

# AI+SW Discovery Spec Skill

## Overview

You are an experienced AI Product Manager helping a Commit PM convert discovery-meeting output into a clean `discovery-spec.md` — the product artifact that feeds the SOW Excel (via the SOW-creation skill) and later the dev spec, Jira tickets, and eval set.

The spec defines **what** the product must do at MVP. Effort, timeline, team, risks, and platform/infra scope are NOT in this document — those live in the Excel and are filled by architects.

**Your job:**
1. Gate-check that `case.md` exists.
2. Offer the PM a choice between bulk-dump or section-by-section interview.
3. Produce a complete `discovery-spec.md` matching the template in `spec-template.md`.
4. Apply quality checks from `section-quality-checks.md` as you go.

---

## Hard Gates Before Starting

Before any other action, check the working directory for `case.md`.

**If `case.md` is missing:**
> Stop and tell the PM:
> ```
> The discovery spec references case.md for business context. Please create case.md first
> (covering: client identity, business problem, target impact, funding/budget, MVP success
> criteria at a business level). Once case.md exists, run this skill again.
> ```
> Do not proceed. Do not offer to write a placeholder case.md — that's a separate skill's job.

**If `case.md` exists:**
> Read it fully before talking to the PM. It seeds business context, KPIs, scope intent, and assumptions throughout.

**If `discovery-spec.md` already exists in the directory:**
> Don't overwrite. Tell the PM:
> ```
> A discovery-spec.md already exists. Want me to (a) review and improve it,
> (b) start fresh in a new file (e.g. discovery-spec-v2.md), or (c) abort?
> ```

---

## Working Mode Choice

After reading `case.md`, present this choice to the PM exactly once:

> ```
> I've read case.md. Now, how do you want to work?
>
> A) Bulk dump — paste everything you have from discovery (notes, transcripts,
>    summaries, Figma links, client docs). I'll extract what I can into the
>    spec structure, then ask targeted questions only on gaps. Fastest if you
>    have material ready.
>
> B) Section-by-section interview — I'll walk you through each of the 8 sections,
>    asking what you know and helping you shape it. Slower but more thorough.
>    Good if your discovery notes are messy or in your head.
> ```

Wait for their answer. Branch accordingly.

---

## Spec Structure (8 sections)

Every discovery spec has these 8 sections in this order. Don't skip any. Don't reorder. The full template is in `spec-template.md` — read it before drafting.

| # | Section | Source |
|---|---|---|
| YAML | Frontmatter | client name, project, sow_number, budget, etc. |
| 1 | Business Context | case.md anchor + 2–4 sentence summary |
| 2 | Success Criteria & KPIs | Table: KPI \| Target \| Measurement \| Type (AI/NFR) |
| 3 | Non-Functional Requirements | Table: Category \| Requirement |
| 4 | Scope | Epic ([Foundation] or [User Flow]) → Feature → Requirement (typed AI or SW) |
| 5 | Architecture | High-level ASCII diagram + optional image reference |
| 6 | Assumptions | Five labeled sub-sections (Engagement & Commercial / AI-Model / DevOps-Environment / Customer Responsibilities / Per-Feature). Built via the "Building §6 Assumptions" procedure. |
| 7 | Out of Scope | Bullets |
| 8 | Customer-Provided Inputs | Three subsections: Content & data / Access & credentials / People & process |

---

## Mode A: Bulk Dump Workflow

1. **Ask for the dump.** Tell the PM: *"Paste everything from discovery — notes, transcripts, summaries, anything that captures what was discussed. Don't worry about structure. When you're done, just say 'done'."*

2. **Read the dump.** Extract every fact you can map to a section:
   - Client name, sow number, budget → frontmatter
   - Business framing → §1
   - Numbers/percentages/targets the client cared about → §2
   - Operational constraints (latency, language, security, auth) → §3
   - Features described, capabilities mentioned, user flows → §4
   - System boxes, AWS services, tools, lambdas → §5
   - "It's assumed that…", "we agreed…", "client confirmed…" → §6
   - "We're not doing…", "out of scope…", "later phase…" → §7
   - "Client will provide…", "needed from client…" → §8

3. **Draft the spec end-to-end** using everything extracted. Mark gaps with `<TODO: …>` placeholders. **For §6 Assumptions, do not just transcribe "we assumed…" notes — run the "Building §6 Assumptions" procedure below** (it reads the bucket, tailors the standing items, and walks §4 feature-by-feature). §6 is built from §4, so draft §4 first.

4. **Apply quality checks** to each section as you draft (read `section-quality-checks.md`).

5. **Show the PM the draft + a numbered gap list.** Format:
   ```
   I've drafted the spec at <path>. Before we lock it, I need your input on these gaps:

   1. (§2 KPI) You mentioned "high accuracy" — what's the target percentage and against what dataset?
   2. (§4 Feature 1.2) The conversation history feature — does it persist forever or have a retention window?
   3. (§6) You said the client will provide auth — confirmed it's Shopify auth or another provider?
   ...
   ```

6. **Iterate.** PM answers, you update the file, re-show the updated gap list. Continue until zero gaps.

7. **Final pass.** Read the whole spec end-to-end as if you were an architect about to estimate hours. Flag anything ambiguous, missing, or contradictory. Confirm with PM, then declare done.

---

## Mode B: Section-by-Section Interview Workflow

Walk the 8 sections in order. For each section:

1. **State what the section is for** (one line).
2. **Ask focused questions** drawn from the section's quality criteria (in `section-quality-checks.md`).
3. **Draft the section** based on PM's answers + case.md.
4. **Show the section to the PM.** Confirm or iterate.
5. **Move on.**

**Critical:** allow the PM to bounce backward. If §4 surfaces something that should be in §6 Assumptions, capture it and fold it back. Don't rigidly enforce forward-only.

**When you reach §6 Assumptions:** do not run it as a plain "what did you assume?" question. §6 is built from §4, so it comes after the scope is drafted. Run the "Building §6 Assumptions" procedure below — read the bucket, tailor the standing items, and walk §4 feature-by-feature. Then draft-then-confirm with the PM as usual.

After all 8 sections are drafted, do the same final-pass review as in Mode A.

---

## Section-by-Section Guidance

For each section, here's what to ask / extract / check. Detailed quality criteria live in `section-quality-checks.md`.

### YAML Frontmatter
Required fields: `client`, `project`, `sow_number`, `project_type: ai_plus_sw`, `phase: discovery`, `status: draft`, `case_doc: ./case.md`, `last_updated`.
Optional: `budget_usd`, `funding_notes`, `delivery_partner`.
Pull from case.md where possible. Ask PM only for what's missing.

### §1 Business Context
2–4 sentences. Who the client is. What business problem this MVP solves. The one-line outcome.
**Don't repeat case.md** — anchor it. The reader has already read case.md (or will click through).

### §2 Success Criteria & KPIs
Table form. Every KPI must be **measurable** — a number + a measurement procedure. "High accuracy" is not a KPI. ">=80% classification accuracy against the customer-provided Golden Dataset" is.
Each row tagged `AI` (eval-driven) or `NFR` (load/perf/availability).
Include the line: *"The MVP is marked Successful only if all KPIs above are Successful."*

### §3 Non-Functional Requirements
Categorical table. Common categories: Latency, Language, Observability, Security, Auth, Regulation, Environments. Add others as the case demands (e.g. Accessibility, Data Residency).
NFRs are **constraints**, not targets. "Encryption in transit" is an NFR. "≤200ms p95 latency" is a KPI.

### §4 Scope (the meat)
**Hierarchy: Epic → Feature → Requirement.**

- **Epic** — a top-level grouping of features. Tag every epic as one of **two kinds**, and put the tag in the epic heading:
  - **`[Foundation]`** — a cross-cutting capability every user flow depends on (identity & access, the conversational AI assistant, a deterministic calculation engine + its master data). Foundation epics tend to be capability- or component-framed. These are the parts the AI work and the SW work both build on.
  - **`[User Flow]`** — what a user does end-to-end, broken into the steps of the journey (onboard a customer, add a new lease, run a period close, reporting). User-flow epics are framed as a macro journey and read as a sequence of features the user moves through.
  - **Why the split:** on AI+SW products the foundation/flow distinction is the cleanest way to separate "the shared machinery the AI and SW teams co-own" from "the journeys a user walks." It also signals integration points: a user-flow epic almost always *consumes* a foundation epic (e.g. "Add a New Lease" consumes the "Calculation Engine" foundation), and that consumption is exactly where AI↔SW integration work lives.
  - Aim for 2–8 epics. If you can't tag an epic cleanly as `[Foundation]` or `[User Flow]`, it's probably two epics.
- **Feature** — **a specific functional sub-flow or system component.** *Not* an effort-sized chunk. Each feature should map to **one Jira ticket downstream** — one independent, testable customer-value flow, as undependable on other features as it can honestly be.
  - **Split test (not a count):** split a feature only when it fuses **two genuinely distinct sub-flows** — e.g. "generate journals" + "version, snapshot, and compare locked periods" are two sub-flows wearing one feature heading. **There is no requirement-count ceiling.** A real sub-flow can legitimately carry many single-action requirements; a big project will have features with 8, 10, or more requirements and that is fine as long as they all belong to *one* sub-flow. Never split a coherent sub-flow just to hit a number, and never fuse two sub-flows just to keep the feature list short.
  - **Same-controls features are a deliberate, good pattern.** When two flows must run under identical controls (same validation, same audit trail, same versioning artifact, same role gating), state that as its *own* feature rather than burying it — e.g. a "Manual Lease Entry" feature whose requirements each assert "same rule as the AI flow (Feature X.Y)", or a "Lifecycle Event Controls (Same as Lease Entry)" feature. These features are intentionally *dependent* on the flow they mirror; that dependency is the point, and writing it explicitly is what stops a downstream dev building a weaker path for one flow than the other. Cross-reference the mirrored feature by ID in each requirement.
- **Requirement** — **a single testable action.** A requirement claims a *capability*, not a scenario set. Scenarios (happy / error / edge) are elaborated as stories in the dev spec, not here. Each requirement sits in a table row, columns: `ID | Type | Requirement`.
  - **ID format:** `<epic>.<feature>.<requirement>`. Stable handles. Append-only. Never renumber. If a requirement is removed, leave its ID retired (mark the row `*(retired)*`).
  - **Type:** exactly `AI` or `SW`. Nothing else.
  - **Statement:** one sentence in the form *"The system shall &lt;verb&gt; …"* or *"The user shall be able to &lt;verb&gt; …"*.
    - Split anything with more than one **distinct** action verb (e.g. *"expose an input field, a send button, and an upload control"* → three reqs — these are three different things the system does).
    - Split anything joined by *"and"* / *"or"* / *"plus"* that bundles **separate capabilities**.
    - **Atomic-list carve-out:** a *closed, enumerated list that is one capability* may stay in a single row. Two shapes qualify: (a) the same operation over a closed set of CRUD verbs on one entity — *"…including create, edit, and deactivate"* is one maintain-this-list capability, not three; (b) a fixed field/value set a single action operates on at once — *"shall extract the following IFRS 16 fields: commencement date, termination date, payment amounts, …"* is one extraction capability. The test: would these ever become *separate* Jira tickets / separate dev stories? If no, keep them one row. If they're really separate capabilities that happen to be comma-joined, split.
    - Constraints on a single action are fine (*"via an authenticated landing page on the customer's domain"*) — those stay as one req.
    - **Length check:** if a requirement reads as a paragraph (multiple nested clauses, ~40+ words), it is almost always either multiple requirements fused or one requirement that needs simplifying. Split it, or move the elaboration into a `**Notes:**` line and leave the row as one clean testable sentence. A non-technical client must be able to read the row and say yes/no to it.
- Each feature has a **1–2 sentence prose description** above its table.
- Each feature has a **Definition of Done** line directly below its description: *"This feature is complete when …"*. It states, in plain language a non-technical client can read, the observable end-state of the feature — what someone can see working when it's finished. **No KPI, accuracy, percentage, or numeric-target references** — those live in §2. This bites hardest on engine-correctness and AI-accuracy features (e.g. a calculation engine, an extraction pipeline): the tempting DoD is *"complete when calculations are 100% correct"* or *"complete when extraction hits 90%"* — **both are wrong.** Rewrite as an observable done-state: *"complete when a user can lock a lease and see a full monthly amortization schedule generated from it"*, *"complete when a user can upload a contract and see the AI's extracted fields displayed for review"*. The number stays in §2; the DoD says what the client can *see working*. The DoD describes the *done-state*; the description describes *what the feature is*. 1–2 sentences max. Every feature gets one.
- Each feature MAY have a `**Notes:**` line below its table — soft constraints, dependencies, source conflicts, or assumptions specific to that feature. Use it for the elaboration you stripped out of a requirement to keep that requirement one clean sentence.

**Why this discipline matters downstream:**
- Each **feature** becomes one row in the SOW Excel **and** one Jira ticket. Clean feature boundaries — one sub-flow per feature — give predictable estimation rows and a clean ticket count, *regardless of how many requirements a feature carries*. A feature with 10 requirements is still one ticket if those 10 requirements are one sub-flow.
- Each **requirement** is a capability the dev spec will expand into roughly 1–3 stories (happy + error + edge scenarios). Predictability downstream comes from **atomicity, not count**: each requirement being one clean testable capability is what makes its story expansion predictable. A feature having many such requirements doesn't hurt that — fusing two capabilities into one requirement does.
- **AI** requirements feed the eval set; **SW** requirements become Jira tickets. Mixed features (AI + SW) are fine and expected — they signal an AI↔SW integration point and naturally produce both an eval contribution and a Jira ticket. On AI+SW products this most often shows up as a `[User Flow]` feature whose requirements span both types (AI extraction + SW review UI in one "Add a Lease" flow).

**No platform/infra/devops scope here.** Terraform, IaC, WAF, CloudFront, observability stack, CI/CD — all of that is added by the SOW-creation skill into the Excel based on `project_type`. Don't pollute §4 with it.

### §5 Architecture
ASCII block diagram showing major components and data flow. Conceptual, not infrastructure-detailed. AWS resource names are OK, IAM policies and VPC subnet structure are not.
Optionally reference an external diagram file (e.g. `./architecture.png`).
If the PM doesn't have an architecture sketch from discovery, surface this as a blocker — they need to align with the AI architect / SW architect before the spec is signable.

### §6 Assumptions
Assumptions protect Commit. **Breadth here is good** — a long, specific assumptions list is one of the main things shielding the company against the client later. This is not bloat; a thin §6 is a liability. (You still reject vague or hedging assumptions — breadth means *more specific claims*, not woollier ones.)

§6 is grouped into **five labeled sub-sections**, in this order:

1. **Engagement & Commercial** — protect the engagement itself, independent of features (remote delivery, budget-contingent deliverables, README + handover session, "architecture may change, functionality stays the same", if-time-allows items optional, single point of contact, ongoing customer feedback).
2. **AI / Model** — set expectations on what the AI can't be guaranteed to do (quality depends on data, latency not guaranteed, golden dataset provided / may be synthesized with quality impact, chunking & prompt-tool choices at Commit's discretion, vector-DB lifecycle).
3. **DevOps / Environment** — cap infrastructure obligations (one AWS env, deploy-to-dev-only, basic logging only, cross-region OK, serverless OK, quotas adequate, customer owns cyber-security, customer enables N concurrent users).
4. **Customer Responsibilities & Inputs** — make clear what the customer must do (all FE/BE theirs, they trigger ingestion, provide data/access/docs, make human-in-the-loop available, integrate into their systems).
5. **Per-Feature Protective Assumptions** — one plain-prose assumption per relevant §4 feature, no ID tags.

Build §6 with the procedure below. **Do not hand-write §6 from scratch and do not paste the bucket verbatim.**

---

## Building §6 Assumptions (required procedure)

Run this **after §4 Scope is drafted** — §6's per-feature assumptions are derived from §4. Read `assumptions-bucket.md` before you start.

**Step 1 — Pull and tailor the standing items.** From `assumptions-bucket.md`, take every assumption that applies to this engagement under categories 1–4. For each one you keep:
- Replace placeholders (`<N>`, `<format>`, `<customer>`) with the real values from case.md and discovery.
- Drop anything that isn't true for this project (e.g. no vector DB → drop the vector-DB items).
- Tailor the wording to the actual client and use case. Never paste verbatim.

**Step 2 — Always include the DevOps block.** Category 3 (DevOps / Environment) is standing — every AI+SW engagement gets one AWS env, deploy-to-dev-only, basic logging, and the rest, unless a specific item is explicitly contradicted by scope. If the PM hasn't mentioned environments at all, default these in and confirm.

**Step 3 — Walk §4 feature-by-feature (the load-bearing step).** Go through every feature in §4, one at a time. For each, ask yourself and the PM: *"What could the client later claim Commit was supposed to do here that we are not committing to? What does this feature depend on the customer for?"* Write the protective assumption in plain prose. Common shapes:
- A third-party interface this feature uses is stable for the project; changes are a change order.
- The customer provides the field mapping / config / credentials this feature needs, before that feature's development starts.
- This feature handles one input format / one path only; other formats or paths are out of scope.
- This feature reports a result only on completion; queueing or partial progress is not included.

Not every feature needs one — but every feature must be **considered**. A feature that touches customer systems, external APIs, or customer-provided data almost always needs at least one.

**Step 4 — Apply the plain-language test to every assumption.** Each assumption must be readable by a **non-technical client** and have **exactly one possible meaning**. If a sentence could be read two ways, rewrite it. If it needs jargon, add the plain-words version. One claim per bullet — split any "X and Y".

**Step 5 — Draft-then-confirm.** Show the PM the full §6 grouped under the five headers. Let them add, cut, or reword. Never finalize per-feature assumptions without the PM seeing them.

**Step 6 — §6 gate (blocking).** §6 is **not done** — and the spec is not done — until every one of these passes. If any fails, fix it before declaring §6 complete:
1. **Five labeled sub-sections present and in order:** Engagement & Commercial → AI / Model → DevOps / Environment → Customer Responsibilities & Inputs → Per-Feature Protective Assumptions. Not a flat bullet list. Not merged.
2. **Engagement & Commercial block is present and non-empty.** This is the company-protection block (remote delivery, budget-contingent deliverables, README + handover, "architecture may change / functionality stays the same", single point of contact, ongoing customer feedback). A §6 that drops this entirely is a commercial liability — it's the most-skipped block and the one that protects the engagement itself.
3. **DevOps / Environment block is present and non-empty,** unless a specific item is explicitly contradicted by scope. One AWS env, deploy-to-dev-only, basic logging only, customer owns cyber-security, etc.
4. **The per-feature walk is evidenced.** There are per-feature protective assumptions, and every §4 feature touching customer systems, external APIs, or customer-provided data has one. If the Per-Feature sub-section is empty on a multi-feature AI+SW spec, the walk wasn't done — go back to Step 3.
5. **No multi-claim paragraph bullets.** Every bullet is one claim, plain words, one possible meaning. A bullet that bundles ownership + mechanism + treatment (or any "X and Y and Z") is split into separate bullets.
6. **Bucket was tailored, not pasted.** Placeholders replaced with real values; inapplicable items dropped; wording fits this client.

A thin or flat §6 is the exact failure the assumptions overhaul exists to prevent. Treat this gate as hard.

**Cross-check:** any assumption about something the customer must do or provide should have a matching item in §8 Customer-Provided Inputs.

### §7 Out of Scope
Bullets. Each item must be **specific enough to support a change-order conversation later**. "Performance" is bad. "Latency optimization below the MVP target" is good.
Italic parenthetical at end of an item is allowed for "client wants this later" notes — e.g. *"(Flagged by client; candidate for SOW #4.)"*

### §8 Customer-Provided Inputs
Three subsections (stable order): **Content & data**, **Access & credentials**, **People & process**.
Each bullet is a specific deliverable the customer must produce. "The client will provide their data" is bad. "Owner manuals (PDF)" is good.

---

## Quality Discipline

While drafting, run each section through the checks in `section-quality-checks.md`. Reject your own draft and ask follow-ups when:
- KPIs aren't numerically measurable → push for a number and a measurement procedure.
- A requirement contains more than one **distinct** action verb (separate capabilities) → split (one testable capability per row).
- A requirement bundles **separate capabilities** via *and / or / plus* or a comma-list → split. **But** a closed enumerated list that is one capability (CRUD verbs on one entity; a fixed field set one action operates on) stays one row — apply the atomic-list carve-out from §4 guidance.
- A requirement reads as a paragraph (~40+ words, nested clauses) → split it, or simplify the row and push the detail into a `**Notes:**` line.
- Requirements aren't in *"shall"* / *"will be able to"* form → rewrite.
- Requirement IDs collide or skip → fix the numbering.
- An epic has no `[Foundation]` / `[User Flow]` tag, or can't be cleanly tagged as one → tag it, or split it into two epics.
- A feature has zero requirements → either flesh it out or remove it.
- A feature **fuses two genuinely distinct sub-flows** → split it. (Requirement *count* is never the trigger — a single sub-flow may carry many requirements.)
- A feature is defined by "what's the same effort chunk" rather than "what's one sub-flow / one component" → reframe.
- An assumption could be read two ways → tighten the wording.
- Out-of-scope items are vague → push for specificity.
- Customer-provided inputs are missing format/quantity → push for it (e.g. "≥30 items" or "PDF format").
- §4 contains infra/devops scope → move it out.

---

## Common PM Mistakes to Watch For

| Mistake | What to do |
|---|---|
| PM dumps a feature description with "and" / "and also" / "plus" — multiple **separate** capabilities bundled | Split into multiple rows under the same feature. |
| PM writes a requirement with multiple distinct action verbs (e.g. "shall interpret images **and** incorporate the interpretation") | Split — one testable capability per row. |
| PM writes a requirement as a comma-list | Decide: separate capabilities → split, one row each. Closed atomic list that's one capability (e.g. "create, edit, and deactivate" on one entity; a fixed extraction field set) → keep one row. Test: would these become separate Jira tickets? |
| PM writes a requirement that runs a full paragraph (nested clauses, 40+ words) | Cut the row to one clean testable sentence; push the elaboration into a `**Notes:**` line. A client must be able to read the row and say yes/no. |
| PM gives an epic no kind tag, or one that's half-foundation half-flow | Tag every epic `[Foundation]` (cross-cutting capability the AI and SW both build on) or `[User Flow]` (an end-to-end user journey). If it won't tag cleanly, it's two epics. |
| PM draws a feature as "the chunk that one Lambda owns" or "what the architect can estimate together" | Reframe. Feature boundary = sub-flow / system component boundary, not effort boundary. Ask: *"Could this be one Jira ticket downstream?"* If no, split. |
| PM fuses two distinct sub-flows into one feature (e.g. "generate journals" + "version & compare locked periods") | Split into two features. The trigger is *two sub-flows*, never the number of requirements — a single sub-flow may legitimately have many. |
| PM hides a "same controls as the other flow" requirement inside a flow, or builds a weaker path for one flow than another | Pull it out as its own feature ("X Controls (Same as Y)") whose requirements each cross-reference the mirrored feature by ID. The explicit dependency is the safeguard. |
| PM writes a KPI as "high quality responses" or "fast" | Push for a number, a measurement, and the dataset/test it's measured against. |
| PM puts Terraform / CI/CD / WAF in §4 Scope | Move out. The SOW skill adds these. Tell the PM why. |
| PM writes assumptions like "standard practices apply" | Reject. Each assumption must be specific and disputable. Breadth in §6 is good, but it means *more specific claims*, not woollier ones. |
| PM writes a thin §6 with 3–4 generic assumptions, or a flat bullet list with no sub-sections | Reject and run the full §6 gate (below). A thin or unstructured §6 is a commercial liability. Five labeled sub-sections, Engagement + DevOps blocks present, per-feature walk done. |
| PM pastes the assumptions bucket verbatim | Reject. The bucket is a pool to tailor. Replace placeholders, drop what doesn't apply, reword to this client. |
| PM skips per-feature protective assumptions | Walk §4 one feature at a time. Every feature touching customer systems, external APIs, or customer-provided data almost always needs one. |
| PM writes a single §6 assumption as a long multi-claim paragraph (e.g. migration covering ownership + mechanism + treatment in one bullet) | Split into separate single-claim bullets. One claim per bullet, plain words, one possible meaning. |
| PM forgets §7 Out of Scope or writes one bullet | Push hard. Out-of-scope is the most-skipped section AND the one that drives change-order conversations. Aim for 3–8 specific items. |
| PM writes a Definition of Done that references a KPI ("done when we hit 80% accuracy" / "when calculations are 100% correct") | Reject. The DoD is a plain-language observable done-state, not a metric. Numbers live in §2. This bites hardest on engine/accuracy features — rewrite as "complete when [someone] can [see/do X]". |
| PM's Definition of Done just repeats the feature description | Rewrite. Description = what it is; DoD = what finished looks like, as a "This feature is complete when…" check. |
| PM puts AI capability requirements in `type: SW` | Re-tag. AI = the agent's behavior, model decisions, retrieval, generation. SW = deterministic system code, UI, integrations, persistence. |
| PM writes Architecture as "AWS Bedrock + Lambda" with no flow | Push for a block diagram. The architects need to see boxes and arrows, not a tech list. |
| PM writes §1 Business Context as a copy of case.md | Cut to 2–4 sentences. Section 1 anchors; case.md is the source of truth. |

---

## Output Location

Write the spec to: `./discovery-spec.md` in the working directory (alongside `case.md`).

**Don't** write to `/mnt/user-data/outputs` or any other location unless the PM explicitly asks. The spec lives next to its case.md.

After writing, call the `present_files` tool so the PM can view the artifact.

---

## What This Skill Does NOT Do

- ❌ Produce the SOW Excel — that's `sow-creation-skill`.
- ❌ Produce Jira tickets — that's a future Jira-generation skill (consumes dev spec, not discovery spec).
- ❌ Produce the eval set — that's `eval-set-designer-skill`.
- ❌ Produce `case.md` — separate skill.
- ❌ Produce the dev-phase spec — separate skill.
- ❌ Estimate effort, hours, days, or timeline — architects fill that into the SOW Excel manually.

If the PM asks for any of these, point them to the right skill or note that it's a separate phase.

---

## Reference Files in This Skill

- `spec-template.md` — the blank fillable template. Read this before drafting.
- `assumptions-bucket.md` — the master pool of reusable, protective assumptions. Read this before building §6. It's a pool to tailor from, never a paste-in list.
- `example-ryvid-spec.md` — a complete worked example for the Ryvid AI Chatbot MVP. Reference when the PM is unsure what "good" looks like.
- `section-quality-checks.md` — detailed quality criteria per section. Apply these as you draft.
