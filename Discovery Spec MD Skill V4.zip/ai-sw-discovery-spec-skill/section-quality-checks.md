# Section Quality Checks

Apply these checks as you draft each section. When a check fails, ask the PM for specifics rather than guessing.

---

## YAML Frontmatter

| Check | Why it matters |
|---|---|
| `client` is the legal name, not a nickname | The SOW Excel uses this in the contract preamble. |
| `sow_number` follows the `SOW-N` format | Skill convention. |
| `project_type` is exactly `ai_plus_sw` or `pure_sw` | Drives downstream skill routing. |
| `phase` is exactly `discovery` | This skill only produces discovery specs. |
| `last_updated` is today's date in YYYY-MM-DD | Stale dates erode trust. |
| `case_doc` points to a real file | If `./case.md` doesn't exist, you shouldn't be in this skill. |

---

## §1 Business Context

| Check | What good looks like |
|---|---|
| 2–4 sentences, no more | A reader scanning this section gets oriented in <30 seconds. |
| References case.md explicitly | Reader knows where to dig deeper. |
| Names the client and the business problem | Not just "we're building a chatbot" — *whose* chatbot, *what* problem. |
| Mentions the one-line outcome of MVP | What changes for the business when MVP ships. |

**Reject when:**
- It's a copy of case.md §1 — anchor, don't duplicate.
- It opens with company history or mission — irrelevant; cut to the problem.
- It describes the *solution* before the *problem* — flip it.

---

## §2 Success Criteria & KPIs

Every KPI must be a complete, testable claim. The format is:

```
| <KPI name> | <numeric target> | <measurement procedure, including dataset/test> | AI | NFR |
```

| Check | What good looks like |
|---|---|
| Every KPI has a number | "≥80%", "≥20", "99%". Not "high", "fast", "scalable". |
| Every KPI has a measurement procedure | *"Semantic similarity ≥0.8 between solution response and Ideal Response in Golden Dataset"* — clear how to measure. |
| AI KPIs reference the eval/golden dataset | If it's an AI KPI, it's measured against eval data. |
| NFR KPIs reference the load/perf test method | If it's an NFR, it's measured by a test. |
| The Type column is exactly `AI` or `NFR` | No third value. |
| The "Successful only if all KPIs are Successful" line is present | This is the contractual hammer. |

**Reject when:**
- KPI is "user satisfaction" or "great UX" — not measurable at MVP without a survey instrument the SOW doesn't include.
- KPI is a feature presence, not a quality target — *"Chatbot deployed to Shopify"* is scope, not a KPI.
- Two KPIs are bundled — *"Accuracy and correctness ≥80%"* split into two rows.

---

## §3 Non-Functional Requirements

Categorical table. Every row is a constraint the system must respect.

| Check | What good looks like |
|---|---|
| Each row is exactly one category, one constraint | No bundling. |
| Constraints are written as the system's behavior, not goals | *"Encryption in transit"* — clear. *"We aim to be secure"* — useless. |
| Required categories present | At minimum: Latency, Language, Observability, Security, Auth, Environments. |
| Auth row clarifies who builds it | Almost always: "provided by <X>, not built in scope" or "built in scope to <Y> standard". |
| Regulation row is explicit, even when "out of scope" | Saying "HIPAA, COPPA, GDPR out of scope" protects against later scope creep. |

**Reject when:**
- A row is actually a KPI (has a target/measurement) — move to §2.
- A row is actually a feature requirement (a thing the user does) — move to §4.
- A row is "follows industry best practices" — not a constraint, push for specifics.

---

## §4 Scope (the deepest section)

### Hierarchy checks

| Check | What good looks like |
|---|---|
| 2–8 epics, each tagged `[Foundation]` or `[User Flow]` | `[Foundation]` = cross-cutting capability the AI and SW both build on (identity, AI assistant, calc engine). `[User Flow]` = an end-to-end user journey. If an epic won't tag cleanly as one kind, it's two epics. |
| Each epic frames cleanly as its tagged kind | A `[User Flow]` epic reads as a sequence of steps a user walks; a `[Foundation]` epic reads as shared machinery flows depend on. A user-flow epic usually consumes a foundation epic — that's the AI↔SW integration point. |
| Each feature represents one functional sub-flow OR one system component | "Estimable chunk" is not enough. Test: *"Could this become one independent, testable Jira ticket downstream?"* If no, split. |
| Each feature has 1+ requirements | A feature with zero requirements is dead weight. |
| Feature split is triggered by **two fused sub-flows**, never by requirement count | There is **no requirement-count ceiling.** A single coherent sub-flow may carry 8, 10, or more single-action requirements — that's fine. Only split when a feature fuses two genuinely distinct sub-flows (e.g. "generate journals" + "version & compare locked periods"). Never split a coherent sub-flow to hit a number; never fuse two sub-flows to shorten the list. |
| Same-controls flows are their own feature | When one flow must run under identical controls to another (same validation / audit / versioning / role gating), that shared-control surface is captured as its own feature whose requirements cross-reference the mirrored feature by ID — not buried or silently duplicated. The dependency is deliberate. |
| Each feature has a 1–2 sentence prose description | Above the requirements table. |
| Each feature has a Definition of Done | A "This feature is complete when …" line below the description. 1–2 sentences, plain language. |
| The DoD describes an observable done-state, not a metric | "Complete when a user can lock a lease and see its amortization schedule" — good. "Complete when we hit 100% calculation correctness" / "when extraction hits 90%" — wrong, that's a §2 KPI. Reject any DoD referencing a number, percentage, or accuracy target. Watch engine/accuracy features especially — that's where the temptation is strongest. |
| The DoD is not just a restatement of the description | Description = what the feature *is*; DoD = what *finished* looks like, phrased as a completion check. If they're identical, rewrite the DoD as a done-state. |

### Requirement ID checks

| Check | What good looks like |
|---|---|
| IDs follow `<epic>.<feature>.<requirement>` | e.g. `2.3.1`, `2.3.2`. Three levels, dot-separated. |
| IDs within a feature are sequential, append-only | If 2.3.4 is added later, it goes after 2.3.3, never reuses a deleted ID. |
| No duplicate IDs anywhere | The Jira-generator skill keys on these. Collision = corrupt output. |

### Requirement statement checks

| Check | What good looks like |
|---|---|
| Each requirement is one sentence | If you need a paragraph (nested clauses, ~40+ words), it's either multiple requirements fused or one that needs simplifying. Split it, or cut the row to a clean sentence and push detail into `**Notes:**`. |
| Each requirement describes a single testable capability | "Display X, Y, and Z" where X/Y/Z are separate capabilities → split. "Interpret images **and** incorporate the interpretation" is two capabilities → split. "Access page via authenticated route" is one action with a constraint → keep. |
| Form is "The system shall &lt;verb&gt; …" or "The user shall be able to &lt;verb&gt; …" | Not "we will implement", not "the chatbot does", not "users can". One main capability after "shall" / "shall be able to". |
| Separate capabilities are not bundled via joiners | Split anything joined by "and" / "or" / "plus" that bundles *separate* capabilities. |
| Atomic enumerated lists may stay one row | A closed list that is **one** capability stays one row: (a) CRUD verbs on one entity — *"…including create, edit, and deactivate"* is one maintain-list capability; (b) a fixed field/value set one action operates on at once — *"shall extract the following IFRS 16 fields: …"* is one extraction capability. Test: would these ever become *separate* Jira tickets / dev stories? If no, keep one row. If yes, split. |
| Each requirement is a capability claim, not a scenario set | A req describes *what the system can do*. Happy/error/edge paths are scenarios — those belong in the dev spec as stories, not here. |
| Type is exactly `AI` or `SW` | No `AI/SW`, no `Both`, no `null`. If it spans both, split into two requirements. |

### AI vs SW typing

This is the most error-prone field. Use this rule:

- **`AI`** — the agent's *behavior*: what it generates, how it reasons, what it retrieves, what it classifies, what it decides. The thing that's tested by an eval set.
- **`SW`** — deterministic system behavior: UI components, API endpoints, data persistence, integrations, file uploads, auth flows. The thing that's tested by unit/integration/E2E tests.

| Requirement | Type | Why |
|---|---|---|
| "The agent shall classify each request as Simple or Complex." | AI | Classification is a model decision, eval-tested. |
| "The user shall be able to upload images up to 50MB." | SW | Deterministic file-handling code. |
| "The agent shall retrieve relevant passages from the KB." | AI | Retrieval quality is eval-tested. |
| "The system shall persist every JSON ticket to S3." | SW | Deterministic storage code. |
| "The agent shall ask 4–5 diagnostic questions for Complex cases." | AI | Generative behavior, eval-tested. |
| "The system shall transform JSON tickets into HubSpot's API schema." | SW | Deterministic transform code. |

### Scope-purity checks (most important)

| Check | What to do |
|---|---|
| §4 contains no Terraform, CI/CD, WAF, IAM, VPC, CloudFront items | Move out. SOW-creation skill adds these. |
| §4 contains no observability/logging tooling setup | Same. |
| §4 contains no security infra (encryption, key rotation) | Same. |
| §4 contains no test framework setup | Same. |

§4 is **product scope only** — what users do, what the system produces. Everything else is platform scope and goes in the SOW Excel by default.

---

## §5 Architecture

| Check | What good looks like |
|---|---|
| ASCII or external diagram present | Not just a list of services. |
| Major components and data flow are visible | Boxes and arrows, not just boxes. |
| Conceptual level | "API Gateway → Lambda → Bedrock" is fine. IAM policies, subnet CIDRs, security groups are NOT. |
| If external diagram referenced, the path is correct | `./architecture.png` should actually exist or be a placeholder the PM commits to. |

**Reject when:**
- It's just a bulleted list of AWS services with no flow.
- It's so detailed that it pre-empts the dev spec's design work.

---

## §6 Assumptions

§6 is grouped into five sub-sections: **Engagement & Commercial**, **AI / Model**, **DevOps / Environment**, **Customer Responsibilities & Inputs**, **Per-Feature Protective Assumptions**. Assumptions protect Commit — breadth is good, but every assumption must still be a specific, disputable, single claim.

| Check | What good looks like |
|---|---|
| Each assumption is one self-contained claim | No "X and Y" — split. A long multi-claim paragraph bullet (e.g. migration covering ownership + mechanism + treatment in one bullet) is split into separate single-claim bullets. |
| Each assumption passes the plain-language test | A non-technical client can read it and it has exactly one possible meaning. If it reads two ways, rewrite. Jargon gets a plain-words version. |
| Each assumption is specific enough to be disputed | The client must be able to read it and say "yes" or "no, that's wrong." |
| No "standard practices" / "industry norms" / "as agreed" | These are non-claims. Push for specifics. |
| The Engagement & Commercial block is present and non-empty | The company-protection block (remote delivery, budget-contingent deliverables, README + handover, "architecture may change / functionality stays", single POC, ongoing feedback). The most-skipped block — a §6 that drops it entirely is a commercial liability. |
| The DevOps / Environment block is present | Every AI+SW engagement gets one AWS env, dev-only deploy, basic logging, etc. — unless a specific item is explicitly contradicted by scope. |
| Every §4 feature was considered for a protective assumption | Walk §4 one feature at a time. Features touching customer systems, external APIs, or customer-provided data almost always need one. An empty Per-Feature sub-section on a multi-feature AI+SW spec means the walk wasn't done. |
| The bucket was tailored, not pasted | Placeholders replaced, inapplicable items dropped, wording fits this client. |
| Assumptions about customer behavior are flagged and mirrored in §8 | "Customer triggers ingestion" — yes. Anything the customer must do/provide should also appear in §8 Customer-Provided Inputs. |

**Reject when:**
- Assumption is a project goal in disguise: *"We assume the system will be performant"* — that's a KPI or NFR.
- Assumption is hedging language: *"It's expected that things may vary"* — useless.
- Assumption duplicates a §3 NFR or §7 out-of-scope item — pick one home.
- §6 is thin (3–4 generic bullets) — a thin assumptions list is a commercial liability. Run the full "Building §6 Assumptions" procedure.
- The five sub-section headers are missing or merged — keep them labeled and in order.

---

## §7 Out of Scope

This section is the **most-skipped and most-important** for change-order conversations. Push hard for completeness.

| Check | What good looks like |
|---|---|
| 3–8 items at minimum | A spec with 1 out-of-scope item is hiding scope risk. |
| Each item is specific | "Performance optimization" is bad. "Latency optimization below the MVP target" is good. |
| Items the client wants but isn't getting are flagged | Italic parenthetical: *"(Flagged by client; candidate for SOW #N.)"* |
| Items mirror discussion from discovery | If you don't know what was discussed, ask the PM. |
| Major obvious exclusions present | Multi-environment, non-English, regulatory cert, bidirectional integrations, mobile native apps, etc. — list whatever's relevant. |

**Reject when:**
- The list is empty or has 1 item — interrogate the PM for what was deferred during discovery.
- An item is a feature the spec actually delivers — contradiction.

---

## §8 Customer-Provided Inputs

Three stable subsections in this order: **Content & data**, **Access & credentials**, **People & process**.

| Check | What good looks like |
|---|---|
| Each subsection has at least one bullet | If a subsection is genuinely empty, write "None." explicitly so it's clear nothing was missed. |
| Content/data items specify format and (where relevant) quantity | "Owner manuals (PDF)", "Golden Dataset (≥30 items: User Request, Operations, Ticket Classification, Ideal Response)" — not just "manuals" or "dataset". |
| Access items specify what permissions are needed | Not just "AWS access" — "AWS account access and IAM permissions sufficient for Terraform-managed provisioning." |
| People & process items name the cadence | "Weekly sync availability" is good. "Their participation" is vague. |

**Reject when:**
- A bullet is "the customer will provide what's needed" — interrogate for specifics.
- The list is missing items the spec depends on (e.g. spec uses HubSpot but no HubSpot key in customer-provided inputs).

---

## Cross-Section Consistency Checks

After all sections are drafted, run these:

| Check | Action if it fails |
|---|---|
| Every AI KPI in §2 references data the customer is providing in §8 | Add the missing input to §8 or relax the KPI. |
| Every external integration in §4 has its credentials/access listed in §8 | Add to §8. |
| Every architecture component in §5 has at least one requirement in §4 | Either remove from architecture or add the missing requirement. |
| Every "out of scope" item in §7 is NOT also in §4 as a requirement | Remove the contradiction. |
| Every assumption in §6 about customer behavior has a matching item in §8 | If we assume the customer does X, X should be in their delivery list. |
| The case.md's stated impact aligns with §2 KPIs | If case.md says "deflect tickets" and §2 has no deflection KPI, ask why. |

These cross-section checks catch the most damaging spec defects — the kind that surface in dev kickoff and force scope renegotiation.
