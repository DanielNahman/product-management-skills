---
client: Ryvid Inc.
project: AI Chatbot MVP
sow_number: SOW-3
project_type: ai_plus_sw
phase: discovery
status: draft
case_doc: ./case.md
linked_specs:
  discovery: null
budget_usd: 69550
funding_notes: "$65K AWS Incremental Workloads, $4,550 Ryvid"
delivery_partner: Commit
last_updated: 2026-05-03
---

# Ryvid — AI Chatbot MVP — Discovery Spec

> This spec defines **what** the product must do at MVP. Effort, timeline, team, risks, and platform/infra scope are added by the SOW-generator skill into the Excel and filled by architects. This document stays a pure product artifact.

---

## 1. Business Context

Ryvid is building a premium lifestyle EV brand and needs a customer-service experience that matches. Today, human agents handle a long tail of repetitive low-complexity tickets (warranty questions, basic troubleshooting, spec lookups), which inflates cost-to-serve and slows response on the complex, safety-sensitive cases that actually need a human. SOW #3 converts the validated PoC (SOW #2) into a production MVP: an agentic chatbot embedded in Ryvid's Shopify storefront, grounded in their owner manuals, FAQs, and diagnostic playbooks, that deflects simple tickets and writes structured tickets into HubSpot for complex ones.

See [`./case.md`](./case.md) for the full business case, target impact, and funding context.

---

## 2. Success Criteria & KPIs

> The MVP is marked Successful only if all KPIs below are Successful.

| KPI | Target | Measurement | Type |
|---|---|---|---|
| Ticket classification accuracy | ≥80% | Solution's Simple/Complex output matches ground truth in customer-provided Golden Dataset (≥30 items). | AI |
| Response correctness | ≥80% | Semantic similarity ≥0.8 between solution's response and the Ideal Response in the Golden Dataset. | AI |
| Concurrent sessions supported | ≥20 | Load test against deployed environment. | NFR |
| Stability | 99% | Returns a result or error 99% of the time over the test window. | NFR |

**Type values:** `AI` — measured against the eval set in dev phase. `NFR` — measured by load/availability testing on the deployed system.

---

## 3. Non-Functional Requirements

| Category | Requirement |
|---|---|
| Latency | Multi-minute responses acceptable at MVP — explicitly deprioritized. |
| Language | English only. |
| Observability | Error logging and application-event logging (service start/stop, configuration changes, job milestones) via CloudWatch. |
| Security | Encryption in transit (automated). VPC flow logs across all accounts. WAF on inbound traffic. |
| Auth | Provided by Shopify's existing authentication. Authentication is not built in scope. |
| Regulation | HIPAA, COPPA, and other regulatory compliance certifications are out of scope. |
| Environments | Single production AWS environment (customer-provided). Customer deploys to any additional environments. |

---

## 4. Scope

Scope is organized as **Epic → Feature → Requirement**. Each requirement is tagged `AI` or `SW`:

- **`SW`** requirements become Jira tickets in the dev phase (the Jira-generator skill walks `type=SW` rows).
- **`AI`** requirements feed the AI dev's capability spec and the eval set definition.

**Requirement IDs are stable handles.** Format: `<epic>.<feature>.<requirement>`. Append new IDs at the end of a feature when adding requirements; never renumber. If a requirement is removed, leave its ID retired.

**Each requirement is one sentence**, written as *"The system shall…"* or *"The user shall be able to…"*. Compound requirements are split.

---

### Epic 1 [Foundation]: Conversational Support Surface

The user-facing chatbot embedded in Ryvid's Shopify storefront — the page, the message UI, media uploads, and conversation history.

#### Feature 1.1: Chatbot Page on Shopify

A custom chatbot landing page hosted on Ryvid's Shopify domain, accessed by authenticated riders.

**Definition of Done:** This feature is complete when a logged-in Ryvid rider can open the chatbot page on the Shopify site, type a message with an optional attachment, and see their messages and the bot's replies appear in the same window.

| ID | Type | Requirement |
|---|---|---|
| 1.1.1 | SW | The user shall access the chatbot via an authenticated landing page on Ryvid's Shopify domain. |
| 1.1.2 | SW | The chatbot page shall display message bubbles for both user and bot, each with a timestamp and avatar. |
| 1.1.3 | SW | The chatbot page shall expose a message input field for the user to compose their message. |
| 1.1.4 | SW | The chatbot page shall expose a send button to submit the user's composed message. |
| 1.1.5 | SW | The chatbot page shall expose an upload control to attach media to the user's message. |
| 1.1.6 | SW | The user shall only reach the chatbot if Shopify has authenticated their session. |

**Notes:** Authentication is provided by Shopify's existing auth — no new login flow is built. The chatbot UI replaces the CopilotKit demo UI used in the PoC.

#### Feature 1.2: Media Uploads

The ability for the rider to attach images and short videos to a chat turn so the agent can reason over visual evidence.

**Definition of Done:** This feature is complete when a rider can attach an image or short video to a message and that file is stored and made available to the agent for the conversation.

| ID | Type | Requirement |
|---|---|---|
| 1.2.1 | SW | The user shall be able to upload images in JPEG or PNG format up to 50MB per file. |
| 1.2.2 | SW | The user shall be able to upload videos in MP4 format up to 50MB per file. |
| 1.2.3 | SW | The system shall store each uploaded file in a dedicated S3 bucket under a session-unique key. |
| 1.2.4 | SW | The system shall issue a pre-signed URL for each uploaded file and pass it to the AI agent. |

#### Feature 1.3: Conversation History

Persistent thread history per user, surfaced in a sidebar so riders can return to past conversations.

**Definition of Done:** This feature is complete when a rider can see a list of their past conversations in a sidebar and reopen any one of them to keep chatting.

| ID | Type | Requirement |
|---|---|---|
| 1.3.1 | SW | The user shall be able to view a sidebar listing their past conversation threads. |
| 1.3.2 | SW | The user shall be able to reopen any past thread and continue the conversation in it. |
| 1.3.3 | SW | The system shall start each new thread with empty short-term context. |

---

### Epic 2 [Foundation]: Agentic Response & Triage

What the AI agent does once a user message arrives — retrieving grounded answers, interpreting media, deciding simple vs complex, and either answering or producing a structured ticket.

#### Feature 2.1: RAG-Grounded Responses

The agent answers user questions using retrieval over Ryvid's owner manuals, FAQs, and diagnostic playbooks.

**Definition of Done:** This feature is complete when the agent answers a rider's product question using Ryvid's own uploaded content rather than generic knowledge, and decides whether the request can be handled directly or needs a human.

| ID | Type | Requirement |
|---|---|---|
| 2.1.1 | AI | The agent shall retrieve relevant passages from the Knowledge Base (Ryvid manuals, FAQ, diagnostic playbooks) before composing a response. |
| 2.1.2 | AI | The agent shall ground every answer in retrieved Knowledge Base content rather than uninformed model output. |
| 2.1.3 | AI | The agent shall classify each user request as Simple (answerable directly) or Complex (requires human handoff). |
| 2.1.4 | AI | The agent shall answer Simple requests directly in chat using grounded retrieval. |

**Notes:** Knowledge Base source files are PDF only at MVP. Ingestion is triggered by Ryvid, not by the chatbot.

#### Feature 2.2: Image Interpretation

When a user attaches an image, the agent reasons over its visual content as part of the response.

**Definition of Done:** This feature is complete when a rider can attach an image and the agent's reply reflects what is in that image.

| ID | Type | Requirement |
|---|---|---|
| 2.2.1 | AI | The agent shall interpret the visual content of user-uploaded images. |
| 2.2.2 | AI | The agent shall incorporate the image interpretation into its response or diagnostic flow. |

#### Feature 2.3: Diagnostic Question Generation

For complex issues, the agent walks the user through targeted diagnostic questions before producing a ticket — so the human agent picks up a triaged case, not a raw inbound.

**Definition of Done:** This feature is complete when, for a complex issue, the agent asks the rider a short set of follow-up questions and uses their answers to fill in the ticket details.

| ID | Type | Requirement |
|---|---|---|
| 2.3.1 | AI | The agent shall ask 4–5 targeted diagnostic questions when a request is classified as Complex. |
| 2.3.2 | AI | The agent shall use the diagnostic question answers to populate the structured ticket fields. |

#### Feature 2.4: Conversation Memory

Short- and long-term context handling so the agent maintains continuity within and across rider sessions.

**Definition of Done:** This feature is complete when the agent remembers earlier turns within a conversation and recalls a rider's saved preferences and facts when they return in a later session.

| ID | Type | Requirement |
|---|---|---|
| 2.4.1 | AI | The agent shall include the last 10 turns (5 user, 5 bot) of the current thread in its context. |
| 2.4.2 | AI | The agent shall persist user preferences and factual context across sessions in long-term memory. |

#### Feature 2.5: Safety Guardrails

Hard rules that override normal flow when a user message indicates a safety risk.

**Definition of Done:** This feature is complete when a message mentioning a safety risk causes the agent to show a safety disclaimer, hold back DIY advice, and route the case to a human ticket.

| ID | Type | Requirement |
|---|---|---|
| 2.5.1 | AI | The agent shall escalate any message mentioning fire, smoke, electrical shock, or crash to a Complex ticket regardless of other classification signals. |
| 2.5.2 | AI | The agent shall display a safety disclaimer when a safety trigger is matched. |
| 2.5.3 | AI | The agent shall suppress DIY troubleshooting advice when a safety trigger is matched. |

---

### Epic 3 [User Flow]: Ticket Capture & HubSpot Handoff

What happens when the agent decides a case needs a human — producing a structured JSON ticket and pushing it into the customer's CRM.

#### Feature 3.1: Structured Ticket Output

The agent emits a machine-readable ticket for every Complex case, with fields aligned to HubSpot's ticket schema.

**Definition of Done:** This feature is complete when every complex case produces a saved, structured ticket that captures the case details and links to any media the rider uploaded.

| ID | Type | Requirement |
|---|---|---|
| 3.1.1 | AI | The agent shall emit a JSON ticket conforming to a defined schema for every Complex case. |
| 3.1.2 | AI | The agent shall include the pre-signed URLs of any uploaded media in the JSON ticket. |
| 3.1.3 | SW | The system shall persist every emitted JSON ticket to a dedicated S3 bucket. |

**Notes:** The JSON schema's field names and types must match the HubSpot Tickets API mapping provided by Ryvid before dev start.

#### Feature 3.2: HubSpot Integration (Unidirectional)

JSON tickets are written into Ryvid's HubSpot CRM so human agents pick up cases in their existing workflow.

**Definition of Done:** This feature is complete when a ticket created by the chatbot shows up as a new ticket in Ryvid's HubSpot account, and nothing is read back from HubSpot.

| ID | Type | Requirement |
|---|---|---|
| 3.2.1 | SW | The system shall transform each JSON ticket from S3 into the HubSpot Tickets API schema. |
| 3.2.2 | SW | The system shall write the transformed ticket into Ryvid's HubSpot CRM via the HubSpot Tickets API. |
| 3.2.3 | SW | The system shall not read tickets back from HubSpot (integration is unidirectional, chatbot → HubSpot only). |

**Notes:** Bidirectional sync is explicitly out of scope — see §7.

---

## 5. Architecture

High-level target architecture:

```
Shopify (auth'd rider)
   └─ Embedded Chatbot UI (Ryvid domain)
        └─ API Gateway → Chatbot Lambda (session, routing, uploads)
             ├─ Media Upload Lambda → S3 (session-scoped, pre-signed URLs)
             └─ AI Lambda (Bedrock agent)
                   ├─ Tool: KB retriever → Bedrock Knowledge Base (RAG over manuals/FAQ/playbook)
                   ├─ Tool: Image interpreter
                   ├─ Tool: JSON ticket writer → S3 (tickets)
                   ├─ Memory: short-term (10-turn context) + long-term store
                   └─ Guardrails: safety-trigger classifier
        └─ HubSpot integration (S3 ticket → HubSpot Tickets API, unidirectional)
```

The agent is a **single Bedrock LLM orchestrating tools**, not a network of cooperating autonomous agents — confirm architecture narrative with the AI architect at kickoff.

---

## 6. Assumptions

### Engagement & Commercial
- All work under this SOW is done remotely unless both sides agree otherwise in writing.
- All deliverables depend on Commit being able to collect and review the needed information within the agreed budget.
- Commit delivers a README plus one handover session so Ryvid can run the solution after the engagement.
- Ryvid names one main point of contact for the project.
- The architecture described here may change during delivery; the agreed functionality stays the same.
- This solution is AI models and modules plus the chatbot embed and HubSpot integration lambda only; no other frontend or backend work is included.

### AI / Model
- Response quality depends on the quality and amount of the knowledge-base content Ryvid provides.
- Commit cannot guarantee response speed; confirming speed is one reason the POC was run.
- Latency and other performance numbers are not part of this phase's success criteria.
- Commit chooses the chunking strategy that best serves the required functionality.
- Prompt management uses Langfuse or the AWS Prompt Management console; the tool is chosen by the development team during the engagement.
- Prompt editing is done through that tool, not a custom-built UI.
- The vector database used is the one Commit created in the POC stage.
- Commit may create, change, add, delete, or replace items in the vector database during the project.
- The Golden Dataset (≥30 items: User Request, Operations, Ticket Classification, Ideal Response) is provided by Ryvid before dev start.
- If the Golden Dataset is unavailable at dev start, Commit may synthesize one, with likely quality impact on the eval.

### DevOps / Environment
- The solution is deployed to one AWS environment, provided by Ryvid.
- The solution is deployed to the development environment only; Ryvid deploys it to any further environments.
- Ryvid sets up the environment so it can serve more than 5 users at the same time.
- Only basic logging is included; usage and spend dashboards are not.
- Ryvid is responsible for the cyber-security of the deployed solution.
- Some AWS services may run in a different region than Ryvid's main environment, including cross-region use.
- Deploying the solution on a serverless service such as AWS AgentCore or AWS Lambda is acceptable.
- The AWS account has at least standard service quotas, assumed adequate for the project.

### Customer Responsibilities & Inputs
- Ryvid does all frontend and backend work needed to use the AI solution beyond the items listed in scope.
- Ryvid triggers the knowledge-base ingestion service.
- Ryvid provides the knowledge-base content (owner manuals, FAQ, diagnostic playbook, tech specs, instructional videos).
- Ryvid makes a domain expert available for extraction and response review (human-in-the-loop).
- Ryvid gives Commit the AWS access and permissions needed for this work.

### Per-Feature Protective Assumptions
- **Chatbot Page on Shopify (1.1):** Authentication is handled by Ryvid's existing Shopify infrastructure; Commit does not build auth.
- **Media Uploads (1.2):** Uploaded media is handled for the formats agreed in scope; other formats are out of scope for this feature.
- **RAG-Grounded Responses (2.1):** Knowledge-base source files are PDF format; other formats are out of scope for ingestion.
- **Image Interpretation (2.2):** Image interpretation is best-effort against the model's capability; Commit does not guarantee correct interpretation of every image.
- **Conversation Memory (2.4):** When records for a given user ID are updated, earlier records with that user ID may be deleted.
- **Structured Ticket Output (3.1):** The ticket field schema is fixed at the agreed structure; new fields after sign-off are a change order.
- **HubSpot Integration (3.2):** The HubSpot Tickets API field mapping is provided by Ryvid before dev start, and the integration is one-directional (write only).

---

## 7. Out of Scope

- Bidirectional HubSpot sync (chatbot reading tickets back from HubSpot).
- Non-English support.
- Multi-environment deployment.
- Latency optimization.
- Frontend/backend work beyond the chatbot embed and the HubSpot integration lambda.
- Regulatory compliance certifications (HIPAA, COPPA, etc.).
- Custom prompt-management UI.
- Chat usage and spend monitoring dashboards. *(Flagged by Ryvid; candidate for SOW #4.)*

---

## 8. Customer-Provided Inputs

**Content & data:**
- Owner manuals (PDF).
- FAQ (Excel, PDF, or Word).
- Diagnostic playbook (Word).
- Tech specs (Excel).
- 3–5 instructional videos.
- Golden Dataset (≥30 items: User Request, Operations, Ticket Classification, Ideal Response).

**Access & credentials:**
- HubSpot Tickets API key with sufficient permissions.
- HubSpot ticket field mapping (JSON → HubSpot ticket properties).
- AWS account access and IAM permissions sufficient for Terraform-managed provisioning.

**People & process:**
- Named point of contact.
- Weekly sync availability.
- UAT participation.
- Domain expert for human-in-the-loop review of agent responses.
