# Business Case — Discovery Recommendation

```yaml
---
client: <Client Name>
prepared_by: <PM Name>
date: <YYYY-MM-DD>
recommendation: GO | RE_SCOPE | NO_GO
recommendation_summary: <one sentence — the bottom line>
roi_ratio: <e.g., "1:2.3"> | below_threshold | not_evaluated
phase: pre-engagement-discovery
sessions_held: <n>
---
```

> **One-page-readable.** Anyone reading only the **Recommendation** section walks away knowing what we recommend and why. The rest is the case behind it.

---

## Recommendation

*(3–5 sentences. Bottom line up front: who the client is, what we recommend, the headline reasoning, the ROI in one number. No throat-clearing. No "after careful analysis we believe…")*

---

## The Client & Their Goal

*(2–3 paragraphs combining context and business goal.)*

**Who they are.** *(One paragraph: client's business, current product, the problem space they operate in.)*

**The boundary of this engagement.** *(Which product line, which platform, which segment, which market. Anything explicitly *not* in scope for this conversation.)*

**The business metric they need to move.** *(The specific KPI: current number, target number, timeframe. Why this metric matters strategically.)*

---

## The Ecosystem

*(The stakeholder map. Compact table. Anyone whose buy-in is non-obvious but blocking gets called out in a note below the table.)*

| Stakeholder type | Who | Why they matter |
|---|---|---|
| End User | | |
| Buyer | | |
| Decision Maker | | |
| Internal Stakeholder | | |
| External Stakeholder | | |

**Power dynamics to know:** *(2–3 sentences. Who pays vs who uses. Who blocks. Who champions.)*

**Primary segment for v1:** *(Which segment we'd target first and why.)*

---

## The Problem Landscape

*(This section is deliberately broad — it's the receipt that we didn't jump to one solution. Three sub-parts.)*

### Key user journeys & flows

*(The main flows we mapped during discovery, with friction points marked. One subsection per journey. Step sequence + friction notes.)*

**Journey: <name>**
```
<step> → <step> → <step> → <step>
```
*Friction:* <bullets>

### Funnel(s) & where users drop

*(The conversion funnels with rates where known. If the client didn't have funnel data, state that and what was used as proxy.)*

| Funnel stage | Volume / conversion | Notes |
|---|---|---|
| | | |

### Problems we mapped

*(The master list. Every problem tagged by where it surfaced.)*

| # | Problem | Where it surfaced | Frequency | Impact | Affected users |
|---|---|---|---|---|---|
| 1 | | journey / funnel / support / JTBD / ops-workflow | | | |
| 2 | | | | | |
| 3 | | | | | |
| ... | | | | | |

---

## The Prioritized Problem

*(The one we chose, with the reasoning, plus the runner-ups in one line each. The runner-ups matter — they're the fallback hand if scope shifts later.)*

**Chosen problem:** *(restate)*

**Why this one.** *(2–3 sentences linking the criteria — impact, frequency, severity, solvability, strategic fit, measurability — to the business goal stated above.)*

**Runner-ups (kept warm):**
1. *<problem>* — *<one-line reason it could come back if scope shifts>*
2. *<problem>* — *<one-line reason>*

---

## The AI Fit Question

*(Yes / No / Partial in plain English. The signals matter; the jargon doesn't.)*

**Verdict:** *<AI is / is not / is partially>* a fit for this problem.

**Why.** *(3–5 sentences. What signals fire — variation in inputs, language understanding required, personalization, edge case volume, output verifiability. And, if applicable, why rules / workflow / UI fixes wouldn't be enough on their own. Avoid technical jargon — say "the system needs to understand free-text complaints" not "this requires an LLM with semantic retrieval over an embedded corpus.")*

**If PARTIAL:** *(Name which parts of the problem AI handles and which parts stay deterministic / rule-based / human-in-the-loop.)*

---

## The Recommended Path

*(Stages 7 and 8 combined. Plain-language description. No tech-stack details — those belong in the discovery spec, not here.)*

### The solution direction

*(2–3 paragraphs. What the solution does, what kind of user moment it changes, where it sits in the existing product. Mention 1–2 alternatives we evaluated and why we picked this one over them.)*

### What v1 looks like

**The one workflow / segment / use case v1 covers.** *(One paragraph.)*

**The riskiest assumption v1 is designed to test.** *(One sentence. This is the v1 question, the answer to which determines whether v2 happens.)*

**Automation posture for v1.** *(Assist / copilot / guarded autopilot / autonomous — with a one-line description of what the user actually experiences.)*

**Deliberately out of scope for v1:**
- *<specific item>*
- *<specific item>*
- *<specific item>*

---

## The Business Case

*(Stage 9. The savings estimate the skill helped build, the cost estimate from architects, and the ratio. Compact table + plain-English narrative.)*

### Savings estimate

| Line item | Value | Assumption / source |
|---|---|---|
| Current volume | | |
| Time / cost per unit (current) | | |
| AI handle rate (target) | | |
| Acceptance / quality rate (target) | | |
| **Monthly savings (estimated)** | **$** | |
| **Annualized savings** | **$** | |

### Cost estimate (from architects)

| Line item | Value | Notes |
|---|---|---|
| One-time build cost | | |
| Ongoing monthly cost (inference, data, ops) | | |
| **Annual total cost (year 1)** | **$** | |

### The ratio

**ROI ratio:** *<1:X.X>*

**Threshold check (1:1.5):** *PASS / FAIL*

### What the numbers mean

*(One paragraph of plain English. What would change them — if AI handle rate is lower than assumed, what happens. If volume grows, what happens. Where the biggest uncertainty sits.)*

---

## Risks & Guardrails

*(Three to seven risks. Specific, not generic. Both delivery risks and value risks.)*

| Risk | Category | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| | delivery / value / adoption / data / compliance | H / M / L | H / M / L | |

### Rollout posture

*(One paragraph. The phased rollout plan, the segment we'd pilot with, the criteria for expanding.)*

### Guardrail metrics

*(The things we won't let regress, even in pursuit of the primary metric. Examples: CSAT must not drop, hallucination rate must stay below X, latency p95 must stay under Y, refund rate must not increase.)*

---

## Alternatives Considered

*(CONDITIONAL — include only if the PM evaluated more than one problem/solution combo during discovery, either by natural exploration or by ROI fallback. Skip entirely if there was only one path.)*

**Path A: *<problem + solution>***
*(One paragraph: what we considered, why we moved on.)*

**Path B: *<problem + solution>***
*(One paragraph: what we considered, why we moved on.)*

**What we'd revisit and when:** *(One paragraph: under what conditions would we come back to one of these.)*

---

## Recommendation & Next Steps

*(One of three branches.)*

### If **GO**

This use case clears the bar. We recommend proceeding.

**Proposed next step:** *(SoW kickoff, project-case creation, architecture deep-dive — name the specific first step.)*

**What we'll need from the client to move:**
- *<deliverable>*
- *<access / credential>*
- *<person / decision>*

### If **RE-SCOPE**

This use case has merit, but at the current shape it doesn't clear the bar.

**What would need to change to make this a GO:**
- *<specific change — e.g., "client provides X months of labeled support tickets so we can validate the 60% handle rate assumption">*
- *<specific change>*

**Proposed next step:** *(A scoped diagnostic engagement, a data audit, a smaller pilot — name it.)*

### If **NO-GO**

This use case does not justify proceeding.

**Why we're not recommending it:** *(2–3 sentences linking the journey through the funnel — what we found, where the ROI fell apart, why the alternates didn't pan out either.)*

**What we'd suggest the client do instead:** *(One or two suggestions. Often this is "invest in data infrastructure first", "fix the underlying process before adding AI on top", "buy an off-the-shelf solution rather than build", or "wait until [condition] is in place." Be direct, not euphemistic.)*

---

*Prepared during pre-engagement discovery. If this recommendation is accepted, the next artifact is `CASE.md` via the `project-case` skill, which carries this business context forward into the build phase.*
