# Methodology Reference

Compressed cheat sheet for use while running the skill. Pulled and adapted from the AI Product Interview Deep Dive V4 framework. Read this when generating pre-session questions, evaluating AI fit, or applying problem-mapping methods.

---

## Question Patterns by Stage

### Stage 1: Context — questions to ask
- Are we improving an existing product or building something new?
- Is this web, mobile, API, internal tool, omnichannel?
- B2C, B2B, marketplace, or platform?
- Is there a specific market, country, or segment to focus on first?
- What constraints bind: regulatory, integration, timeline, budget?
- Have you tried AI on this problem before? What happened?

### Stage 2: Business Goal — questions to ask
- What's the one business metric this work needs to move?
- Where is that metric today, and where do you need it to be?
- By when?
- What unlocks if it moves? What breaks if it doesn't?
- Is this a growth, activation, retention, revenue, or efficiency play?

### Stage 3: Stakeholders & Users — questions to ask
- Who uses the product directly on a day-to-day basis?
- Who pays for it / approves the purchase?
- Who configures permissions, workflows, integrations?
- Who can block or approve this initiative? Whose buy-in is non-negotiable?
- Who's affected by the output even if they don't use the product (customers, downstream teams)?
- Are Legal, Compliance, Support, Sales, Finance, Ops involved?
- Are there external stakeholders — regulators, payment providers, marketplaces?
- Which segment are we starting with and why?

### Stage 4: Problem Space — questions to ask

*By method:*

**User Journey:**
- Walk me through what [user type] does from start to finish for [main task]. Where do they get stuck? Where do they waste time? Where do they make mistakes?
- What's their workaround today when something doesn't work?

**Funnel:**
- For [main conversion], what are the stages from entry to success?
- What's the volume / conversion rate at each stage? Where's the biggest drop?
- Has the drop-off changed recently? What changed?

**Jobs To Be Done:**
- What is [user type] actually trying to achieve when they reach for this product? (Not the feature — the outcome.)
- What do they do instead when the product doesn't work for them?

**Support / Feedback Mining:**
- What are the top categories of support tickets / complaints / reviews?
- Which complaint types are recurring vs spiking?
- Where do users escalate? What pushes them to call vs self-serve?

**Ops Workflow Mapping:**
- What internal / manual / repetitive work exists today that the product touches?
- What systems do internal users hop between? Where's the swivel-chair work?

### Stage 5: Prioritization — questions to ask
- How many users are affected by each problem?
- How costly / painful is each — to users and to the business?
- How often does each occur?
- Will solving it actually move the business goal we named in stage 2?
- Do we have the data and access to solve it within v1?
- Can we measure success on it?

### Stage 6: AI Fit Check — see signals table below

### Stage 7: Solution Directions — questions to ask
- Does this problem stem from lack of information, lack of trust, inefficiency, inaccuracy, or lack of personalization?
- Could rules / a workflow change / a UI fix solve this? (Force the non-AI baseline.)
- Does the solution need to understand text, images, voice?
- Does it need to predict, rank, recommend, or personalize?
- What's the cost of a wrong AI output here — annoying / expensive / dangerous?

### Stage 8: MVP / v1 — questions to ask
- What's the riskiest assumption v1 needs to prove? (That users want it / that the AI is accurate / that the data exists / that the workflow change is acceptable to operators?)
- Which segment is best to pilot with?
- Which one workflow is narrow enough to ship and measure in 4–8 weeks?
- Is v1 assist, copilot, guarded autopilot, or autonomous?
- What's the fallback if AI confidence is low?

### Stage 9: Saving Estimate — questions to extract numbers
- How many [units of the problem] do you handle per [day/week/month]?
- How long does each one take currently?
- What does each one cost you today (loaded labor cost, refund cost, escalation cost)?
- What's your current error rate? What does an error cost?
- What improvement would make this worth doing — and what would be "wow"?

### Stage 10: Risks & Rollout — questions to ask
- What's the worst plausible outcome of v1 going live?
- Which of these matters most: hallucination, latency, privacy, bias, cost overrun, low adoption?
- What metrics do we monitor to know v1 is healthy, not just live?
- Who's the pilot population? What's the criteria to expand?
- What guardrails (rate limits, human review, fallback) does v1 ship with?

---

## AI Fit Signals & Anti-Signals

### Fit signals (presence supports AI)

| Signal | What it means | Example |
|---|---|---|
| Unstructured data | LLMs / vision good at text, docs, conversations, images | Contract analysis, ticket triage, image-based product info |
| Semantic understanding | Rules can't parse meaning and context | "the package looks damaged" vs "the box says fragile" |
| Personalization needed | Decision varies by user / context / history | Content recommendations, lead scoring |
| Prediction / ranking | Patterns in history support probability | Demand forecasting, churn prediction |
| Many edge cases | Variation defies enumerable rules | Customer inquiry classification across thousands of phrasings |
| Output is verifiable | Eval and guardrails possible | Source-cited answer, prediction with ground truth, human acceptance signal |

### Anti-signals (presence supports rules / no-AI)

| Anti-signal | What it means | Example |
|---|---|---|
| Unambiguous logic | No probabilistic judgment needed | Tax calculation, eligibility check |
| Hard compliance | Deterministic enforcement required | "Do not display medical advice without certified clinician approval" |
| Clear threshold | Simple rule suffices | "Refund automatically if order < $X and < 30 days" |
| High cost-of-error + no fallback | AI introduces unacceptable risk | Autonomous medical decision, autonomous legal approval |

### Capability map

| AI capability | When to reach for it |
|---|---|
| Classification | Bucket inputs into categories (ticket type, document risk class, lead temp) |
| Extraction | Pull facts from text / docs (cancellation clause, invoice fields, key entities) |
| Retrieval / RAG | Answer / generate grounded in client's source of truth (KB, policy, contracts) |
| Summarization | Compress for a decision (call summary, document brief) |
| Generation | Draft text the user edits (sales email, ticket response, content) |
| Recommendation / ranking | Choose the best option (content, leads, products) |
| Prediction | Forecast demand, risk, churn |
| Tool-calling / bounded agent | Execute defined actions across systems with audit trail |
| Fine-tuning | Only after RAG / prompting fail AND there's a large labeled corpus AND a stable recurring pattern |

**Golden rule:** AI fits messy data, context, language, ranking, personalization. Rules fit clear laws, eligibility, calculations, and guardrails. Most real products need both.

---

## Stakeholder Ecosystem Types (the seven)

| Type | Identification question | Why they matter |
|---|---|---|
| End User | Who actually works with the product day-to-day? | The behavior to change. |
| Buyer | Who pays / approves budget? | The SoW signer. |
| Admin / Configurator | Who sets up workflows, permissions, knowledge? | The implementation blocker. |
| Decision Maker | Who can block or approve this initiative? | Often Legal, Security, CISO, or VP. |
| Beneficiary | Who receives the value but doesn't directly use the product? | The downstream customer or executive sponsor. |
| Internal Stakeholder | Which internal unit is affected (Finance, Support, Compliance, Ops)? | Adjacent process owners. |
| External Stakeholder | Who outside the company shapes the rules (regulator, app store, marketplace, payment processor)? | The structural constraints. |

---

## Problem Mapping Methods (the five)

| Method | What it reveals | When to lean on it |
|---|---|---|
| User Journey | Friction and "why" along a flow | Always. Foundation. |
| Funnel Analysis | Quantitative drop-off and "where" | When the metric is conversion / activation / retention. |
| Jobs To Be Done | The real outcome the user wants | When the client describes features instead of needs. |
| Support / Feedback Mining | Recurring complaints, escalations | When the client has support data — almost always do this. |
| Operational Workflow Mapping | Internal manual / repetitive work | When the use case is internal-facing (back office, support, ops). |

**Combine journey + funnel.** Funnel locates the leak (quantitative). Journey explains why users struggle (qualitative). Either one alone is half the picture.

---

## Automation Posture (the four levels)

| Level | Description | Example |
|---|---|---|
| Assist | AI suggests, human always decides and acts | Suggested reply chips agent can click |
| Copilot | AI drafts, human accepts or edits, human acts | Drafted email the rep reviews and sends |
| Guarded Autopilot | AI acts within bounds, human reviews edge cases / errors | AI auto-closes refunds < $50, escalates rest |
| Autonomous Agent | AI acts independently, audit trail only | AI fully handles routine tier-1 tickets |

Most v1s should be **Assist or Copilot**. Move up the ladder only after eval and acceptance data justify it.

---

## ROI Cost Categories to Surface (for the architect handoff)

The skill doesn't compute these — but should remind the PM what the architect needs to estimate so the cost-side comes back complete:

- Model / inference cost (per call × volume)
- Engineering build effort (FE, BE, ML, data)
- Design effort
- Data pipelines, vector DB, embedding infra
- Eval setup and ongoing evaluation cost
- Human-in-the-loop / review labor
- Cost of errors (refunds, escalations, brand risk)
- Ongoing ops (monitoring, on-call, model refresh)

If the architect's cost estimate omits ongoing ops or cost of errors, the ratio will be optimistic. Flag this when the PM brings the ratio back.

---

## Common KPI Distinctions

Keep these straight when the client throws metric language around:

- **Business KPI** — what success looks like to the business (revenue, retention, CSAT).
- **Product input metric** — what moves the business KPI (activation rate, feature adoption, session frequency).
- **AI quality metric** — eval-level (accuracy, precision/recall, hallucination rate, grounding rate, human acceptance rate).
- **Guardrail metric** — what we monitor to ensure the business KPI doesn't come at the cost of trust (CSAT in a cost-cutting engagement, refund rate in a conversion engagement, hallucination rate in any LLM engagement).

Stage 2 captures the **Business KPI**. Stage 10 captures the **Guardrail metrics**. AI quality metrics get fleshed out in the eval set later (separate skill).
