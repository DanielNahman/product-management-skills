# Discovery Workspace — `<Client Name>`

```yaml
---
client: <Client Name>
prepared_by: <PM Name>
discovery_started: <YYYY-MM-DD>
sessions_planned: <e.g., 4 over 3 weeks>
last_updated: <YYYY-MM-DD>
current_active_stage: 1
stage_status:
  1_context: open
  2_business_goal: open
  3_stakeholders: open
  4_problem_space: open
  5_prioritization: open
  6_ai_fit: open
  7_solutions: open
  8_mvp: open
  9_roi: open
  10_risks: always_on
---
```

> **Provenance legend.** Tag every captured fact:
> - `[C]` = Client stated this directly.
> - `[PM]` = PM inference or assumption.
> - `[S]` = Skill suggestion / industry-benchmark estimate.
> - `[?]` = Gap — needed from client.

---

## Stage 1: Context

**Status:** open

### Intro
*(One paragraph: who the client is, what their current product is, why they reached out.)*

### Boundaries
- Product / platform in scope:
- B2B / B2C / Marketplace / Platform:
- Market / geography / segment:
- Channels in scope (web / mobile / API / internal tool):

### Constraints
- Regulatory:
- Technical / integration:
- Timeline / budget signals (rough, if mentioned):
- Existing AI investments or attempts:

### Parking lot
*(Forward-stage facts mentioned during stage 1 discussion. Cleared as stages advance.)*

---

## Stage 2: Business Goal

**Status:** open

### Primary business metric to move
*(The one metric. Not "better experience" — a specific KPI: activation rate, retention D30, conversion, support cost per ticket, time-to-resolution, etc.)*

### Current baseline (number)
*(Where the metric is today.)*

### Target (number + timeframe)
*(Where the client wants it to go and by when.)*

### Why this matters to the business
*(2–3 sentences of strategic reasoning.)*

### Parking lot

---

## Stage 3: Stakeholders & Users

**Status:** open

| Type | Who | Why they matter |
|---|---|---|
| End User | | |
| Buyer | | |
| Admin / Configurator | | |
| Decision Maker | | |
| Beneficiary | | |
| Internal Stakeholder | | |
| External Stakeholder | | |

### Primary segment to focus on first
*(Which segment v1 targets and why.)*

### Notes on power dynamics
*(Who can block. Who's the champion. Who pays vs who uses.)*

### Parking lot

---

## Stage 4: Problem Space

**Status:** open

### 4a. Key user journeys & flows

*(Walk each primary user type's main flow from start to finish. Mark friction points. Use simple text arrows or Mermaid. One block per journey.)*

**Journey: <name> (User type: <X>)**
```
Step 1: <action> → Step 2: <action> → Step 3: <action> → ...
```
*Friction points observed:*
- Step N: <what hurts here, source>
- Step M: <what hurts here, source>

### 4b. Funnels & drop-offs

*(For each conversion-style flow, list the funnel stages and conversion rates if the client has numbers. If not, mark `[?]`.)*

**Funnel: <name>**
| Stage | Volume / rate | Source |
|---|---|---|
| Entry | | |
| Step 2 | | |
| Step 3 | | |
| Conversion | | |

### 4c. Problem master list

| # | Problem | Source of discovery | Frequency | Cost / impact | Affected users |
|---|---|---|---|---|---|
| 1 | | journey / funnel / support / JTBD / ops-workflow | | | |
| 2 | | | | | |
| 3 | | | | | |

**Closure check:** ≥1 journey mapped, ≥1 funnel documented (or explicit "no data, derived from X"), ≥3 problems with all columns filled or marked as known gaps.

### Parking lot

---

## Stage 5: Prioritization

**Status:** open

### Criteria evaluation

*(Score each candidate problem against the six criteria. Use H/M/L or 1–5.)*

| Problem | Impact | Frequency | Severity | Solvability | Strategic fit | Measurability | Total / pick |
|---|---|---|---|---|---|---|---|
| #1 (chosen): | | | | | | | ✓ |
| #2 (alt): | | | | | | | |
| #3 (alt): | | | | | | | |

### Top problem (chosen)

**Problem:** <restate>

**Why this one (criteria narrative):**
*(2–3 sentences linking the scores to the business goal.)*

### Runner-ups (ranked, kept warm)

1. <problem> — <one-line reason it could still come back>
2. <problem> — <one-line reason it could still come back>

### Parking lot

---

## Stage 6: AI Fit Check

**Status:** open

### Fit signals evaluated

| Signal | Present? | Evidence |
|---|---|---|
| Unstructured data involved (text, docs, conversations, images) | yes / no / partial | |
| Semantic understanding needed | yes / no | |
| Personalization / context-dependent decisions | yes / no | |
| Prediction / ranking from historical patterns | yes / no | |
| Many edge cases (variation that defies rules) | yes / no | |
| Output is verifiable (can build eval / guardrails) | yes / no | |

### Anti-signals checked

| Anti-signal | Present? | Evidence |
|---|---|---|
| Unambiguous deterministic logic | yes / no | |
| Hard compliance / zero-tolerance enforcement | yes / no | |
| Clear threshold / rule suffices | yes / no | |
| Cost-of-error too high without human fallback | yes / no | |

### Decision

**AI Fit:** YES / NO / PARTIAL

**Reasoning (3–5 sentences):**

**If PARTIAL:** which parts of the problem are AI-shaped and which are rules/workflow-shaped.

### Parking lot

---

## Stage 7: Solution Directions

**Status:** open

### Directions evaluated (≥2, ideally 3 — include at least one non-AI baseline)

**Direction A: <name>**
- What it is (1–2 sentences):
- AI capability used (classification / extraction / RAG / summarization / generation / recommendation / prediction / tool-calling / fine-tune / NONE-rules-only):
- Estimated effort posture (small / medium / large):
- Pros:
- Cons:
- Cost-of-error profile:

**Direction B: <name>**
*(same structure)*

**Direction C: <name>**
*(same structure)*

### Chosen direction

**Direction:** <A / B / C>

**Why over the others (2–3 sentences):**

### Parking lot
*(Other solution candidates captured throughout discovery — kept warm for ROI fallback.)*

---

## Stage 8: MVP / v1

**Status:** open

### Riskiest assumption v1 tests
*(One sentence. Examples: "that the AI can accurately classify ticket types from the client's actual support corpus", "that agents will accept AI drafts ≥60% of the time", "that the data we need actually exists in the form we'd need it".)*

### v1 scope (the one workflow / segment / use case)

### Automation posture
- [ ] Assist (AI suggests, human always decides)
- [ ] Copilot (AI proposes, human accepts / edits)
- [ ] Guarded Autopilot (AI acts within bounds, human reviews edge cases)
- [ ] Autonomous Agent (AI acts independently)

### Explicit out-of-scope for v1
*(Bullets. Each one specific enough to be a change-order conversation later.)*
- 
- 
- 

### Fallback behavior when AI confidence is low

### Parking lot

---

## Stage 9: Saving Estimate & ROI Check

**Status:** open

### Benefit-side inputs (from client)

| Input | Value | Provenance | Source session |
|---|---|---|---|
| Current volume (e.g., tickets/month) | | C / PM / S / ? | |
| Time per task (current) | | | |
| Cost per task (current) | | | |
| Error rate (current) | | | |
| Cost per error | | | |
| Target improvement (% / time / cost) | | | |

### Savings estimate

**Formula used:**
```
<spell out the math>
```

**Estimate:** $<X> / <period> savings

**Assumptions baked in:**
1. 
2. 
3. 

### ROI ratio (from PM after architect cost-side estimation)

- **Ratio:** <e.g., 1:2.3> or `pending`
- **Threshold check (1:1.5):** PASS / FAIL / pending

### Fallback triggered?
- [ ] No — ratio cleared threshold, proceed to stage 10.
- [ ] Yes — see "Alternative Considered" section below for re-evaluated path.

### Parking lot

---

## Stage 10: Risks & Rollout

**Status:** always-on (formal closure at wrap-up)

### Risk register (continuous capture)

| Risk | Category (delivery / value / adoption / data / compliance) | Likelihood (H/M/L) | Impact (H/M/L) | Mitigation / guardrail | Source |
|---|---|---|---|---|---|
| | | | | | |

### Rollout posture (filled at closure)
*(Phased rollout plan: pilot segment → broader rollout → full. Guardrails for each phase.)*

### Guardrail metrics (what we don't want to break)
*(Examples: CSAT, escalation rate, hallucination rate, latency p95, refund rate. Match to the business goal's failure modes.)*

---

## Alternative Considered
*(Only present if the PM re-opened prioritization mid-discovery — either by natural exploration or by ROI fallback. The previous path's stages 5–9 get archived here. The active path lives in the main sections above.)*

### Previously considered: <problem name>
**Why we moved on:** <one sentence>
**What we'd kept warm:** <one or two sentences on what might bring this back>

*(Archived snapshot of the previous path's stages 5–9 follows.)*

---

## Session Log

| Session # | Date | Attendees (client side) | Topics covered | Key facts captured | Stages advanced |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
