# Stage Closure Criteria

Read this file before judging whether a stage can be marked **closed** in the workspace. These criteria are the gate the skill uses to decide whether to allow active work on the next stage.

**Principle:** A stage is closed only when its content can defend itself in front of a skeptical reader (a senior PM, an architect, the client's CFO). Vague content blocks closure even if the section is "filled in."

---

## Stage 1: Context — Closed when…

- [ ] The product / platform in scope is specified by name and type (web app / mobile app / API / internal tool / omnichannel).
- [ ] B2B / B2C / Marketplace / Platform is stated, not assumed.
- [ ] The relevant market / segment is named (e.g., "US SMB", "EU enterprise customers", "free-tier mobile users").
- [ ] At least one concrete constraint is captured (regulatory, integration, timeline, or budget signal). "No constraints" is acceptable only if explicitly affirmed by the client.
- [ ] Any prior AI investments or attempts by the client are surfaced (or explicitly stated as none).

**Common premature-closure trap:** PM says *"it's a B2B SaaS"* and moves on. That's three words; it's not Context. Push for which product (if multi-product), which platform, which segment, and which constraints actually bind.

---

## Stage 2: Business Goal — Closed when…

- [ ] One primary business metric is named. Not a list of three. One.
- [ ] The metric is something the business already measures or can plausibly measure (not "trust", not "delight" — push for a proxy if those are floated).
- [ ] A current baseline number is captured. `[?]` is acceptable for closure only if the PM has confirmed the client doesn't know either, and a proxy or estimation method is named.
- [ ] A target number with a timeframe is captured.
- [ ] 2–3 sentences explain why this metric matters strategically (what unlocks if it moves, what breaks if it doesn't).

**Common premature-closure trap:** PM writes *"increase efficiency"* or *"improve customer experience"*. Reject. Push to: *"Reduce avg-handle-time of tier-1 support tickets from 8 minutes to 5 minutes by end of Q3, which would free 2 FTEs of capacity."*

---

## Stage 3: Stakeholders & Users — Closed when…

- [ ] At minimum these roles are filled in: **End User**, **Buyer**, **Decision Maker**. (If End User = Buyer, say so explicitly.)
- [ ] At least one **Beneficiary** is named (often the end user's customer or the buyer's boss).
- [ ] At least one **Internal Stakeholder** is named (Legal, Compliance, Support, Finance, Ops — whichever ones are actually involved).
- [ ] External Stakeholders are listed OR explicitly stated as "none for this scope" (regulators, payment providers, marketplace partners, app stores).
- [ ] The **primary segment for v1** is identified — which of the user types we'd target first and why.
- [ ] Power dynamics are noted: who can block, who's the champion, who pays vs who uses.

**Common premature-closure trap:** PM lists "users" and "the company" and calls it done. Reject. The ecosystem table needs the seven types or an explicit declaration that a type doesn't exist for this product.

---

## Stage 4: Problem Space — Closed when…

- [ ] **At least one user journey** is mapped step-by-step with friction points marked. (Two or three if there are multiple primary user types.)
- [ ] **At least one funnel** is documented with stages and conversion/drop-off rates — OR an explicit note that the client doesn't have funnel data and the funnel structure was derived from the journey + the metric.
- [ ] **Problem master list has ≥3 problems**, each with all columns filled (problem, source-of-discovery, frequency estimate, cost/impact estimate, affected users) or marked as known gaps with `[?]`.
- [ ] At least two **different sources of discovery** are represented across the problem list (journey, funnel, support feedback, JTBD interview, ops workflow). A list of 3 problems all from one source means we mapped one channel, not the problem space.

**Common premature-closure trap:** PM has a journey but no funnel, or has a problem list with no journey or funnel behind it. Both are insufficient. Funnel + journey answer different questions (where vs why) — a credible problem space has both.

---

## Stage 5: Prioritization — Closed when…

- [ ] The criteria evaluation table is filled in for the chosen problem AND at least 2 alternates.
- [ ] Each problem is scored against all 6 criteria (impact, frequency, severity, solvability, strategic fit, measurability).
- [ ] The "why this one" narrative explicitly links scores to the business goal from stage 2.
- [ ] Runner-ups are kept warm with one-line "what would bring this back" notes (not deleted).

**Common premature-closure trap:** PM picks the problem they liked from the start and scores the table to justify it (reverse-engineered justification). Watch for: alternates with low scores across the board, or scores filled in without evidence in stage 4's problem list.

---

## Stage 6: AI Fit Check — Closed when…

- [ ] All 6 fit signals are evaluated (yes/no/partial) with evidence.
- [ ] All 4 anti-signals are checked (yes/no) with evidence.
- [ ] The verdict is YES / NO / PARTIAL — not "probably" or "maybe."
- [ ] 3–5 sentences of reasoning explain the verdict by referencing which signals fired.
- [ ] If PARTIAL: the boundary between AI-shaped and rules/workflow-shaped sub-problems is drawn explicitly.

**Common premature-closure trap:** PM asserts "yes, AI fits" because the client asked for AI. Reject. Walk the signals. If the verdict is NO, the recommendation may still be GO for a non-AI engagement, or it may be NO-GO for Commit specifically — but the verdict must be honest.

---

## Stage 7: Solution Directions — Closed when…

- [ ] At least 2 directions are documented (3 is better).
- [ ] At least one direction is a **non-AI baseline** (rules, workflow change, UI fix, integration, process improvement). Even when AI is the chosen direction, the non-AI comparison sharpens the case.
- [ ] Each direction has: what it is, AI capability used (or NONE), effort posture (S/M/L), pros, cons, cost-of-error profile.
- [ ] The chosen direction is named with a 2–3 sentence "why over the others" rationale.

**Common premature-closure trap:** PM writes one direction labeled "the AI solution" and skips comparison. Reject. Without comparison, the choice can't be defended in the business case.

---

## Stage 8: MVP / v1 — Closed when…

- [ ] The riskiest assumption v1 tests is named in one sentence.
- [ ] The v1 scope is narrowed to one workflow / segment / use case.
- [ ] Automation posture is selected (assist / copilot / guarded autopilot / autonomous).
- [ ] At least 3 explicit out-of-scope items are listed, each specific enough to be a change-order conversation later.
- [ ] Fallback behavior when AI confidence is low is described.

**Common premature-closure trap:** PM lists "the full feature" as the MVP and skips the riskiest-assumption framing. Reject. v1 isn't a smaller version of the feature; it's the answer-finding probe.

---

## Stage 9: Saving Estimate & ROI Check — Closed when…

- [ ] Benefit-side input table has values for: current volume, current time/cost per task, target improvement. Each with provenance tag (C / PM / S / ?).
- [ ] The savings formula is spelled out — anyone reading should be able to follow the math without further explanation.
- [ ] The savings estimate has at least 3 explicit assumptions documented (what we're assuming about handle rate, acceptance rate, volume stability, etc.).
- [ ] The ROI ratio is received from the PM (after architect cost-side estimation) and recorded.
- [ ] Threshold check is applied: PASS (≥ 1:1.5) or FAIL (< 1:1.5).
- [ ] If FAIL: fallback was triggered, evaluated, and either resulted in a new active path or in a NO-GO recommendation. The previous path is archived in "Alternative Considered."

**Common premature-closure trap:** PM brings back a ratio without showing the cost side. Push back: the workspace should record the architect-provided cost-side estimate (even at the line-item level) so the business case doc can show both sides transparently.

---

## Stage 10: Risks & Rollout — Closed when…

- [ ] Risk register has ≥3 risks, each with category, likelihood, impact, and a concrete mitigation.
- [ ] Risks span at least 2 categories (don't accept 3 delivery risks and call it done — push for value, adoption, data, or compliance risks too).
- [ ] Mitigations are concrete, not vague. *"We'll monitor"* is not a mitigation. *"We'll set a hallucination rate alarm at 3% with weekly review"* is.
- [ ] Rollout posture is described: pilot segment → broader rollout → full, with the criteria for expanding between phases.
- [ ] Guardrail metrics are named — the ones we won't let regress.

**Common premature-closure trap:** PM writes generic risks ("technical risk", "adoption risk") with vague mitigations ("we'll be careful"). Reject. A risk that can't be alarmed on or reviewed against is not a useful risk.

---

## After All 10 Are Closed

All 10 stages closed = the workspace is ready to be transformed into `business-case-discovery.md`. Run a final consistency pass:

- Business goal (stage 2) is referenced in stages 5 (prioritization), 7 (solution rationale), 8 (MVP riskiest assumption), and 9 (what success looks like).
- Chosen problem (stage 5) is the one stage 6's AI fit was evaluated against (not a different one that slipped in).
- Solution direction (stage 7) is the one stage 8's MVP scopes (not a different one).
- ROI ratio (stage 9) matches the chosen path (not the abandoned one if fallback was triggered).
- Risks (stage 10) reference the actual chosen solution, not the original abandoned one if fallback fired.

If any of these fail consistency, the workspace has drift — fix before generating the output doc.
