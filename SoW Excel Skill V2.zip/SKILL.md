---
name: sow-excel-generator-skill
description: Use when a Commit product manager has a signed AI+SW discovery spec and needs to produce the SoW Excel that goes to the client and to the architects for effort estimation. Triggers on requests like "generate the SoW", "create the SoW excel from the spec", "make the SoW", "build the SoW from this discovery spec", or after a discovery spec hits status signed and the PM is ready to estimate effort. Refuses to run if the discovery spec is unsigned. Ships with a bundled rate card; a project-directory rate card overrides it if present.
---

# SoW Excel Generator Skill

## Overview

You convert a **signed** discovery-spec.md into the SoW Excel file that:
- Goes to the **client** for signature (contains scope, success criteria, NFRs, assumptions, DoD).
- Goes to the **architects** (AI architect, SW architect, DevOps) for effort estimation. Architects fill in the Technical Task, Implementation Details, and Days columns themselves — **you do NOT fill those columns**.

The SoW is **less narrative than the spec.** It's a structured estimation artifact. The Feature column carries a composed, non-ambiguous requirement summary (not the spec's prose description), and each feature shows its plain-language Definition of Done.

**Your job:**
1. Gate-check: discovery spec exists AND is signed/locked, rate card available.
2. Read the spec and case.md.
3. Determine PoC vs MVP (read spec, confirm with PM).
4. Ask a small set of project-specific questions (IL/Global, dual env, AWS account, AWS Calculator).
5. Compose the per-feature requirement summaries (col E) and copy each feature's verbatim DoD (col F); generate the project-level DoD text and Mermaid diagrams from spec content.
6. Interview the PM on ROI benefits.
7. Build an inputs.json with all gathered data.
8. Run `generate_sow.py` to produce the SoW.xlsx.
9. Surface the file and any caveats.

---

## Hard Gates

Before any other action, check the working directory:

**1. `discovery-spec.md` must exist.** If missing:
> ```
> No discovery-spec.md found. The SoW is generated from a signed discovery spec.
> Use the ai-sw-discovery-spec-skill first, get the spec signed by the client,
> then come back here.
> ```

**2. `discovery-spec.md` frontmatter `status` must be `signed` or `locked`.** If `draft` or `in_review`:
> ```
> discovery-spec.md status is "<status>". The SoW is the contractual artifact —
> it can only be generated from a signed discovery spec. Get the spec to status
> "signed" (after client review and approval), then come back.
> ```

**3. Rate card resolution.** The skill bundles a default rate card at `<this-skill-folder>/RateCard.xlsm`. To use a different rate card for a specific project (e.g. a newer version, or one with project-specific negotiated rates), drop a file named `RateCard.xlsm`, `RateCard.xlsx`, or `rate_card.xlsx` into the project's working directory — the project-local file wins.

Tell the PM which rate card you'll use:
> ```
> Using rate card: <bundled (built into skill)> | <project-local: ./RateCard.xlsm>
> ```

If the bundled card is being used, also note its age — if it's >6 months old, suggest the PM confirm rates are still current with Commit ops before sending the SoW to the client.

**4. Existing `SoW.xlsx`.** If one already exists, ask:
> ```
> A SoW.xlsx already exists in this directory. Want me to:
> a) replace it (overwrite),
> b) version it (SoW-v2.xlsx),
> c) abort?
> ```

---

## Read Everything First

Before talking to the PM, read in this order:

1. `discovery-spec.md` — fully. Parse frontmatter, all 8 sections.
2. `case.md` — for business framing (used in DoD text and ROI guidance).
3. The bundled template at `<this-skill-folder>/template/SoW_Template.xlsx`.
4. The rate card file (already located).

Then build a parsed-spec data structure in memory:

```python
parsed_spec = {
  "client": <from frontmatter>,
  "project": <from frontmatter>,
  "epics": [
    {
      "id": <int>,
      "name": <Epic name>,
      "description": <epic description prose>,
      "user_story": <YOU generate this — see "Generating user stories" below>,
      "features": [
        {
          "id": <feature id e.g. "1.1">,
          "name": <feature name>,
          "description": <feature description prose, single paragraph>,
          "summary": <YOU compose this — see "Composing the per-feature requirement summary" below. "shall/will" voice. Goes in col E.>,
          "definition_of_done": <the feature-level DoD line from spec §4, VERBATIM. Goes in col F. Required.>,
          "requirements": [{"id": ..., "type": "AI"|"SW", "text": <verbatim shall statement>}],  # statements, used to compose the summary
          "notes": <feature-level Notes line if present, else None>,
          "requirement_ids": [<list of requirement IDs under this feature>]  # retained for the col-E trace
        }
      ]
    }
  ],
  "assumptions": [<each spec §6 bullet, verbatim>],
  "nfrs": [{"category": ..., "requirement": ...}],   # spec §3 rows
  "kpis": [{"kpi": ..., "target": ..., "measurement": ..., "type": ...}],  # spec §2 rows
  "architecture_services": [<list of AWS services mentioned in spec §5>]
}
```

### Generating per-epic user stories

The SoW has a "Detailed User Story" column merged across all features of an epic. The discovery spec doesn't have a per-epic user story — you generate one.

For each epic, write ONE user story (40-80 words) that summarizes what users do across all features in that epic. Form: *"As a <user type>, I want <capability> so I can <outcome>."*

Read the epic name, description, and feature descriptions to inform it. Example for Ryvid Epic 1 (Conversational Support Surface):

> *"As an authenticated Ryvid rider, I want to chat with an AI support agent on the Shopify site that lets me ask questions, attach images and videos of issues, and continue past conversations, so I can get help 24/7 without waiting for a human agent on simple questions."*

### Composing the per-feature requirement summary (col E)

The LoE "Feature" column (col E) carries the feature name plus a **composed, plain-language summary of the feature's functional requirements** — not the raw discovery-spec description. You compose this from the feature's requirement statements (in `requirements`).

Rules for the summary:
- **Voice:** "The user shall be able to … / The system will …". Same disciplined voice as the spec's requirements.
- **Non-ambiguous:** each clause has exactly one meaning. No "etc.", no "and so on", no vague verbs like "handle" or "support".
- **One capability per clause.** Roll up the feature's requirements into 1–4 short sentences that together say what the feature does. Don't drop a requirement; don't invent one that isn't in `requirements`.
- **Plain enough for the client** (the SoW is signed by them) but precise enough for the architect estimating the row.
- 1–4 sentences. Shorter is better.

Example — Ryvid Feature 1.1 (Chatbot Page on Shopify), composed from its six requirements:
> *"The user shall be able to open the chatbot on an authenticated page on Ryvid's Shopify domain and compose a message. The system will display the conversation as timestamped message bubbles, let the user attach media, and send messages to the agent. The system will only allow access once Shopify has authenticated the session."*

The generator appends a compact requirement-ID trace automatically (e.g. `[covers 1.1.1–1.1.3]`), so you don't add it yourself — just supply the `summary` text and the `requirement_ids`.

### The feature-level Definition of Done (col F)

Col F (formerly "Requirement ID") now carries each feature's **Definition of Done**, copied **VERBATIM** from the discovery spec's §4 feature-level DoD line ("This feature is complete when …").

- **Do not compose, edit, paraphrase, or summarize it.** It is contractual — it must match the signed spec exactly. Copy it straight into `definition_of_done`.
- **Do not confuse it with the project-level DoD** (the 1–2 paragraph blob on the separate `DoD` sheet — see "Generating the DoD Text"). They are different artifacts: the project-level DoD references KPIs and covers the whole engagement; the feature-level DoD is plain-language, per feature, no KPIs.
- **If a feature has no DoD line in the spec**, the spec predates the feature-level DoD change. **Stop and tell the PM** to add the DoD line to that feature in `discovery-spec.md` and re-sign/re-run. Do not invent one and do not fall back to the description. (The generator also hard-stops with an error if `definition_of_done` is missing.)

### Extracting architecture services

Read spec §5 Architecture (ASCII block or prose). Extract the AWS service names and major components. For Ryvid: `["S3", "Bedrock", "Bedrock Knowledge Base", "Lambda", "API Gateway", "DynamoDB", "CloudFront", "WAF", "ALB"]`. For Linkme: `["API Gateway", "SQS FIFO", "ECS Fargate", "Bedrock", "S3 Vectors", "Cohere V3", "DynamoDB", "CloudWatch", "Semantic Cache"]`.

**How this list is used:** the DevOps sheet's "Platform implementation - IaC - Dev" epic contains a fixed set of service-specific template rows (Lambda Setup, API Gateway Setup, S3, CloudFront, Bedrock Setup, Knowledge Base Setup). The generator:
- **Keeps** template service rows that match a service in `architecture_services`.
- **Drops** template service rows whose service is NOT in `architecture_services` (e.g. Linkme has no Lambda, so Lambda Setup is dropped — saving its 20 hrs).
- **Adds** new rows at 5 hrs each for services in `architecture_services` not in the template (e.g. ECS Fargate, SQS FIFO, DynamoDB).
- Always appends a "Service Mix Adjustment" row to reconcile back to 240 hrs (MVP) / 35 hrs (PoC), since the user mandate is that the grand total stays fixed.

Cross-cutting DevOps rows (IAM, WAF, AWS Tuning, E2E, Stage testing, Account Networking, the entire CI/CD epic, Security epic, Monitoring & Logging epic, Backups epic) are always kept regardless of architecture. CloudWatch is intentionally excluded from "new service" additions because it's already covered by the existing Monitoring & Logging epic.

Be thorough when extracting services — include both AWS-native services and any external/specialized services (Cohere V3, Semantic Cache via ElastiCache or similar, RDS pgvector, etc.).

---

## Pre-Interview Setup

Tell the PM what's about to happen, briefly:

> ```
> I've read the signed discovery spec for <project>. I'll now generate the SoW
> Excel. I need to ask a few project-specific questions, then I'll generate the
> Mermaid system flows and propose the DoD text and ROI benefits structure for
> your review.
>
> Architects fill in the Technical Task, Implementation Details, and Days columns
> after — I won't pre-fill those.
> ```

---

## Inputs to Gather (in this order, one question per message)

### 1. PoC or MVP

First look in `discovery-spec.md` and `case.md` for explicit markers ("PoC", "MVP", "Proof of Concept", "Minimum Viable Product"). The `sow_number` field is not a reliable signal.

If clearly indicated, confirm:
> "I see this is an MVP project (case.md title mentions MVP). Confirm to proceed."

If unclear, ask:
> ```
> Is this project a PoC (proof of concept) or an MVP (minimum viable product)?
> The DevOps sheet structure and effort differ significantly between these.
> ```

### 2. IL or Global

> ```
> Is this an Israeli (IL) or Global project? This drives the rate card currency:
> IL = NIS rates (column B of Rate Card IL), Global = USD rates (column C of
> Rate Card Global).
> ```

### 3. (MVP only) Dual environment?

> ```
> Will the project deploy to a single production environment, or to both dev
> and prod environments? Two-env adds 50 hours of DevOps effort (rows 21-23 of
> the DevOps sheet).
> ```

### 4. (MVP only) New AWS account?

> ```
> Will you need to create a new AWS account for the customer (Landing Zone +
> Control Tower setup), or does the customer already have an AWS account
> provisioned for this work? Creating a new account adds 15 hours of DevOps
> effort.
> ```

### 5. AWS Calculator

> ```
> Do you have an AWS Pricing Calculator export with the projected annual
> consumption cost for this project?
>   - If yes: paste the total annual cost in USD (or attach the file path).
>   - If no: I'll proceed with a placeholder ($1000). Note that you should
>     create an AWS Calculator estimate before sending the SoW to the client —
>     it's expected in the ROI section.
> ```

### 6. Application Type / User Type

Default both. Only ask if the PM's context suggests otherwise:
> ```
> The LoE sheet labels each row with Application Type and User Type. I'll
> default to "Web App" + "End User" unless you tell me otherwise. Want to
> override (e.g. "Mobile App", "BO Admin")?
> ```

---

## Generating the DoD Text (project-level — the DoD sheet)

After gathering inputs, draft the **project-level** Definition of Done. 1-2 paragraphs, concise. This is distinct from the per-feature DoD in LoE col F (see "The feature-level Definition of Done"). This one lives on its own `DoD` sheet, covers the whole engagement, and *does* reference KPIs.

For an MVP, the DoD should cover:
- Production deployment to the target AWS environment.
- All KPIs from spec §2 met against the agreed dataset (cite specifically).
- Key feature flows working end-to-end (cite the top-level epics from spec §4).
- Critical integrations confirmed (cite the external systems in spec §5 architecture).
- Infrastructure provisioned and observability in place.
- NFRs satisfied (cite the key ones from spec §3).

For a PoC, the DoD is shorter — the agent passes the success criteria against the golden dataset, demo UI works, evaluation results documented.

Show the draft to the PM for review before finalizing.

---

## Generating the Mermaid Diagrams

Generate 2-4 Mermaid diagrams from spec context. Common useful ones:

1. **Main happy-path sequence diagram** — user interaction through the system. Use `sequenceDiagram`.
2. **Agent decision flowchart** — if the project has AI classification or branching logic. Use `flowchart TD`.
3. **External integration sequence** — for projects with vendor integrations (HubSpot, Salesforce, etc.).

Use exact Mermaid syntax. The diagrams are stored as text in the System Flows sheet — they don't render in Excel, but architects/clients can paste them into a Mermaid renderer (mermaid.live, GitHub, Notion).

Show the diagrams to the PM for review before finalizing.

---

## ROI Benefits Interview

The ROI Calculator sheet's Section 2 (Annual Benefits) is the interactive part. Walk the PM through it.

Read `roi-benefit-patterns.md` for the full guidance. In short: present 4-6 common benefit categories for AI+SW products, ask the PM which apply, and gather the assumptions for each.

For each benefit (max 5):
- **Category**: short name (e.g. "Ticket deflection", "Agent capacity redirection").
- **Assumption**: the assumption the calculation rests on (e.g. "30% of current 1000 monthly tickets handled by chatbot at $5 saved per deflected ticket").
- **Annual saving**: the dollar number.
- **Calculation**: the math behind it (e.g. "1000 * 12 * 0.3 * $5 = $18,000").

If the PM doesn't have data for a benefit, encourage them to make a conservative estimate (it's the client's reality check, not a guarantee). If they refuse all categories, leave the benefits empty — the ROI ratio will be 0 but the formula machinery stays intact.

---

## Building the inputs.json

Once all data is gathered, write it to a temporary `inputs.json` file in `/tmp` (or the project directory) and pass it to the generator script.

Structure:
```json
{
  "spec_path": "...",
  "case_path": "...",
  "template_path": "<bundled in skill folder>",
  "rate_card_path": "<optional — omit to use bundled rate card or project-local override>",
  "output_path": "./SoW.xlsx",
  "project_type": "mvp" or "poc",
  "location": "il" or "global",
  "dual_env": true/false,
  "new_aws_account": true/false,
  "aws_calculator_annual_cost": number or null,
  "application_type": "Web App",
  "user_type": "End User",
  "parsed_spec": { ... full parsed spec ... },
  "dod_text": "...",
  "mermaid_diagrams": [...],
  "roi_benefits": [...]
}
```

---

## Running the Generator

Execute:
```bash
python3 <skill-folder>/generate_sow.py /tmp/inputs.json
```

The script:
- Copies the bundled template to `./SoW.xlsx`.
- Modifies sheets per the inputs.
- Preserves template styling throughout.
- Renames the LoE sheet to "PoC LoE" or "MVP LoE".
- Deletes the unused DevOps sheet.
- Applies rate card values to the LoE summary table and ROI calculator.
- Returns "OK: wrote <path>" on success.

If the script errors, surface the error to the PM with context.

---

## After Generation

1. Verify the file exists at `./SoW.xlsx`.
2. Call `present_files` to show it to the PM.
3. Summarize what was generated and any caveats:
   - "Architects need to fill in Technical Task, Implementation Details, and Days columns in the LoE sheet."
   - "If you didn't supply an AWS Calculator export, the Yearly Consumption Cost in ROI is a placeholder ($1000). Update before sending to client."
   - "The System Flows sheet contains Mermaid diagrams as text plus a clickable 'Open in mermaid.live →' link per diagram — click the link to view the rendered diagram in a browser, or copy the source into any Mermaid-aware tool."
   - "The Cloud Architecture sheet is empty by design — architect/SA fills this."
   - "In the LoE sheet, the Feature column holds a plain-language requirement summary plus a `[covers …]` trace back to the spec requirement IDs, and the Definition of Done column (where Requirement ID used to be) holds each feature's verbatim DoD from the signed spec."

---

## What This Skill Does NOT Do

- ❌ Generate the discovery spec — that's `ai-sw-discovery-spec-skill`.
- ❌ Generate the dev spec — that's `ai-sw-dev-spec-skill`.
- ❌ Fill in days/effort estimates — architects do this manually after.
- ❌ Generate Jira tickets — separate future skill.
- ❌ Modify the discovery spec — discovery is locked at signature.
- ❌ Draw the cloud architecture diagram — architect's deliverable.
- ❌ Generate the AWS Pricing Calculator export — PM does this separately in AWS console.

If the PM asks for any of these, point them to the right skill or note it's outside this skill's scope.

---

## Common PM Mistakes to Watch For

| Mistake | What to do |
|---|---|
| PM runs this skill before the spec is signed | Hard gate fails — refuse and explain. |
| PM wants to fill in effort estimates here | Redirect — those go in the SoW after architect review. The PM doesn't estimate. |
| PM forgets the AWS Calculator | Surface as a caveat after generation; note in the SoW the ROI placeholder must be updated. |
| PM picks "Global" but the team is in Israel | Confirm — "Global" means SoW is in USD; doesn't mean the team. IL is for projects billed in NIS. |
| PM wants to skip the ROI interview | Acceptable — leave benefits empty. The sheet's formulas still work; output ROI ratio will be 0:something. |
| PM wants to add features to the SoW that aren't in the spec | Stop. Either trigger a change order to the discovery spec, or remove from SoW. The SoW must reflect signed scope exactly. |
| PM wants the SoW in a different template format | This skill produces only the Commit-standard template. If a different format is needed, the PM does it manually. |
| PM (or you) edits/paraphrases the feature-level DoD in col F | Don't. Col F is copied verbatim from the signed spec's §4 DoD lines — it's contractual. Editing it makes the SoW disagree with the signed scope. |
| A feature has no DoD line in the spec | Stop. The spec predates the feature-level DoD. Tell the PM to add the DoD line in discovery-spec.md and re-run. Don't invent one or fall back to the description. |
| The composed feature summary (col E) adds or drops a capability vs the requirements | Recompose. The summary rolls up the feature's actual requirements in "shall/will" voice — no inventing, no omitting. |

---

## Reference Files in This Skill

- `template/SoW_Template.xlsx` — bundled canonical template. Don't modify; the script copies it.
- `generate_sow.py` — the generation script. SKILL.md tells you when to run it; the script does the file work.
- `role-mapping.md` — LoE summary roles ↔ rate card roles mapping. Reference if the rate card structure changes.
- `roi-benefit-patterns.md` — guidance on running the ROI benefits interview.
- `mermaid-flow-patterns.md` — examples of good system flow diagrams to model from.
