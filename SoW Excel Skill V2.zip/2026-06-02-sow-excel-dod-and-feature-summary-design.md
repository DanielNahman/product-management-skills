# Design — SoW Excel: feature-level DoD + composed requirement summary

**Date:** 2026-06-02
**Skill affected:** `sow-excel-generator-skill`
**Related:** consumes the new feature-level Definition of Done added to
`ai-sw-discovery-spec-skill` §4.

## Goal

Two changes to the LoE sheet of the generated SoW Excel:

1. Surface each feature's **Definition of Done** (the plain-language,
   no-KPI, feature-level DoD now written in the discovery spec) as its own
   column, derived **verbatim** from the discovery spec, one per feature.
2. Rework the **Feature** column so it carries a **composed plain-language
   summary of the feature's functional requirements** (in "The user shall be
   able to… / The system will…" voice), instead of the raw feature description.

## Key decision — no column shift

The LoE sheet columns are:
A App Type · B User Type · C Epic · D Detailed User Story · E Feature ·
F Requirement ID · G Technical Task · H Implementation Details ·
I FE · J BE · K AI Developer · L AI Validation · M Assumptions.

The day-columns (I/J/K/L) are referenced **by letter** in the summary table's
SUM formulas (`"AI Developer": "K"`, etc.), and the template carries
position-keyed styling and merges. Inserting a real new column before G would
break the summary math and styling.

**Instead: repurpose column F.** In the LoE feature region, col F is
*display-only* — written once, never read by any formula. We retask it from
"Requirement ID" to "Definition of Done". G onward is untouched. Summary table,
day-columns, ROI sheet, and the separate `DoD` sheet are all unaffected.

(Verified: the other `column=6` writes in the script are on different sheets —
the summary HRS row and the ROI calculator — not the LoE feature region.)

## Two distinct DoDs — keep them sharp

- **Project-level DoD** — the existing 1–2 paragraph blob, lives on the template's
  own `DoD` sheet, *references KPIs*. Unchanged.
- **Feature-level DoD** — new, per feature, plain language, **no KPI**, copied
  **verbatim** from discovery §4 into LoE col F.

These are different in kind and must not be merged.

## Column contents after the change

**Col E — Feature (reworked):**
- `<feature name>` + a composed summary of the feature's functional requirements
  in "shall/will" voice. **Composed by Claude at SoW-gen time** (same pattern as
  the existing per-epic `user_story` and project `dod_text`).
- Ends with a compact trace line: `[covers 1.1.1–1.1.3]` so the requirement-ID
  linkage survives the loss of the old F column.
- Replaces the old `name + description`.

**Col F — Definition of Done (was Requirement ID):**
- The feature's DoD line **verbatim** from discovery §4. No composition, no edit.
- Header renamed in the script (overrides the template's row-1 "Requirement ID").

## Data flow changes

`parsed_spec` gains two per-feature fields:
- `definition_of_done` — verbatim DoD line from discovery §4.
- `requirements` — the requirement **statements** (text), not just IDs, so Claude
  can compose the col-E summary. `requirement_ids` is retained for the trace.

The composed summary is passed in via `inputs.json` per feature
(`feature_summary`), so the generator stays a dumb writer and the language
composition lives in the SKILL — consistent with how `user_story` and `dod_text`
already work.

## Edge case — feature missing a DoD line

If a feature in the spec has no DoD line (spec predates the DoD change), the
generator **flags it to the PM and pauses** rather than guessing or falling back.
The PM updates the spec (or re-signs) and re-runs.

## Files changed

- `generate_sow.py` — col E write (name + composed summary + trace), col F write
  (verbatim DoD), row-1 F header rename, DoD-missing guard.
- `SKILL.md` — `parsed_spec` doc (new fields), new "Composing the per-feature
  requirement summary" section, col-F-is-now-DoD note, two-DoDs clarification,
  updated caveats and mistakes table.

## Non-goals

- No new physical column; no summary-formula or styling changes.
- No change to the project-level DoD sheet.
- No change to the day-columns or rate-card logic.
- Claude does not invent DoD text — col F is verbatim from the signed spec.
