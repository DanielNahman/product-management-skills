---
project_id: {project-slug}
customer: {Customer Display Name}
project_type: {assessment|poc|mvp|production}
pm: { name: "{name}", email: "{email}" }
# project_manager: { name: "{name}", email: "{email}" }    # optional — operational PjM, omit the line if not applicable
# eng_lead: { name: "{name}", email: "{email}" }           # optional, omit if not applicable
# ai_lead: { name: "{name}", email: "{email}" }            # optional, omit if not applicable
start_date: {YYYY-MM-DD}
# target_end_date: {YYYY-MM-DD}                            # optional, omit the line if not applicable
# related_projects:                                        # optional — paths to prior CASE.md files
#   - ../{prior-slug}/CASE.md
last_updated: {YYYY-MM-DD}
---

## TL;DR
- **Who:** {customer one-liner — what they do and the part that matters here}.
- **Why us:** {pain or opportunity in their words; quote with citation when possible}.
- **What we're building:** {project_type} — {one-line scope}.
- **Target outcome:** {business success in measurable terms}.
- **Hard constraint:** {only if real and dated — funding gate, regulatory date, contractual deadline; omit the bullet entirely if none}.

## Customer context
{1-2 paragraphs. Cover only what matters to *this project*: what the customer sells or builds, which part of their business or product this engagement touches, and how Commit fits in. Quote the customer where their framing is sharper than ours. Skip generic firmographics like headcount or office locations unless directly relevant.}

## Project goal & success criteria
**Business goal:** {the outcome the customer wants in business terms}.

**Functional goal:** {what the system must do to deliver the business goal}.

**Success criteria:**
- {testable condition 1}
- {testable condition 2}

<!-- Optional sub-section. Include only with a cited customer quote. Otherwise remove the heading and block entirely. -->
**Phase exit signal:**
> "{verbatim quote about what graduating to the next phase requires}" — source: sources/_extracted/{file}.md:{line}

## Scope
**In scope:**
- {action-oriented bullet — one feature/deliverable per line}

**Out of scope:**
- {non-goal} — {one-line "why out"}

## People
| Name | Role | Side | Decision authority | Channel |
|------|------|------|--------------------|---------|
| {name} | {role} | {Customer\|Comm-IT} | {what they decide} | {Slack/email/phone} |

<!-- IMPORTANT section — include only if real signal exists. Omit entirely if not applicable. -->
## Technical context
- **Customer stack:** {tech relevant to the build}
- **Mandatory integrations:** {systems we must integrate with}
- **Compliance/security:** {ONLY if customer explicitly stated requirements; omit the bullet otherwise. If no bullets remain, omit the whole section.}

<!-- IMPORTANT section — include only when sources contain explicit unanswered questions. Every entry needs a citation. Omit entirely if there are none. -->
## Open questions
- {question} — owner: {who} — blocking: {yes\|no} — source: sources/_extracted/{file}.md:{line}

<!-- OPTIONAL section — include only if prior projects with this customer exist. -->
## Engagement history with this customer
- **{Project name}** ({YYYY-MM} → {YYYY-MM}, {project_type}) — {one-line outcome}. CASE.md: ../{slug}/CASE.md

<!-- OPTIONAL section — include only if customer/domain jargon needs explaining. -->
## Glossary
- **{term}**: {definition, customer-specific or industry-specific only}

## Sources
- **SOW:** sources/{filename}
- **Architecture (AI):** sources/{filename}
- **Architecture (Software):** sources/{filename}
- **Architecture (DevOps):** sources/{filename}
- **Kickoff transcript:** sources/{filename}
- **PM notes:** sources/{filename}
<!-- Add more lines for any additional source documents. Drop lines for source types not present. -->
