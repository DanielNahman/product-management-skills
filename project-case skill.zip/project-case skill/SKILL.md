---
name: project-case
description: Use when starting a new customer engagement to anchor project context (creates CASE.md from SOW, transcripts, diagrams, and notes via a guided PM interview), or when an existing CASE.md needs updating after a scope/people/customer change.
argument-hint: "[path-to-project-folder]"
---

# project-case

Creates and updates `CASE.md` — a per-project context anchor that humans and downstream AI agents both read. The skill ingests project sources (SOW, transcripts, diagrams, notes), drafts what it can extract with confidence, then interviews the PM on gaps in plain language, and finally validates and writes the file.

The produced file is always named `CASE.md` and lives at the project folder root.

## Inputs

- **Argument** (optional): path to the project folder. If omitted, defaults to the current working directory.
- **Sources folder** (expected): `<project>/sources/` containing the input documents (SOW, transcripts, diagrams, notes, decks, cost models, etc.). The skill auto-discovers files here.

## Output

- `<project>/CASE.md` — the rendered context anchor.
- `<project>/sources/_extracted/<original-name>.md` — cached structured extraction for any binary source (DOCX/PDF/SVG/PNG/PPTX/XLSX). The skill manages this folder; the PM does not edit it.
- (Update mode only) `last_updated` in CASE.md frontmatter is bumped.

## Operating principles

These are non-negotiable. Apply them throughout every phase.

1. **Plain language with the PM, always.** Use the question library at `prompts/interview-questions.md`. Never invent jargon.
2. **No silent assumptions.** Every value you infer from sources is labeled `Assumption: ...` with a confidence band (high/medium/low) and confirmed by the PM before write.
3. **No empty stubs.** A section is either filled with real content or absent entirely. Never write a CASE.md with `<!-- TBD -->` or `{...}` placeholders.
4. **Citations for live content.** Open questions and the optional Phase exit signal must carry `source: sources/_extracted/<file>:<line>` citations. Without a citation, the entry is omitted.
5. **One question per turn.** During the interview, never batch multiple questions into one message. The PM answers the first and ignores the rest.
6. **Triage before extraction.** Don't run Vision on every diagram by default. Classify sources, show the PM, let them re-classify, then extract.
7. **Cache extractions.** First run extracts; later runs reuse `sources/_extracted/<name>.md` unless the source mtime is newer.
8. **Never silently overwrite the PM's edits.** In update mode, sections the PM didn't approve are left as-is.

## Phase 0 — Mode select

1. Resolve the project folder:
   - If `$ARGUMENTS` is set, use it.
   - Otherwise use the current working directory.
   - If the folder doesn't exist, ask the PM where the project lives. Do not create directories yet.
2. Check for `<project>/CASE.md`:
   - **Exists** → Update mode. Skip to "Update mode" section near the bottom of this file.
   - **Does not exist** → Create mode. Continue to Phase 1.
3. Confirm with the PM in one short message: *"Working in `<project>` (create mode). I'll read what's in `sources/`, draft a CASE.md, and ask you about anything I can't figure out from the documents. Sound good?"*

## Phase 1 — Source ingestion

### Step 1.1 — Discover sources

1. Look for `<project>/sources/`.
2. If `sources/` exists, list every file in it (recursively, but skip `_extracted/` and dotfiles).
3. If `sources/` does **not** exist, or contains zero usable files, run the **source recovery flow**:
   > *"I checked `<project>/sources/` and found {N files / nothing}. To do a good job I'd like more material. You can either:*
   > *1. **Point me at a folder** with the source documents (SOW, transcripts, diagrams, notes). I'll copy them into `sources/`.*
   > *2. **Drop files into the chat** and I'll save them to `sources/` for you (keeping the original filenames).*
   >
   > *What do you have?"*

   - If the PM gives a folder path: create `<project>/sources/` if needed, then copy each file (do not move) preserving filenames. If a name collides with an existing file in `sources/`, ask before overwriting.
   - If the PM drops files in chat: save each into `<project>/sources/` with the original filename.
   - If the PM has no sources at all: the skill cannot proceed. Tell the PM: *"I can't draft CASE.md without source material. Once you have the SOW, kickoff notes, or any project documents, re-run the skill."* Exit cleanly.

### Step 1.2 — Triage sources

For each discovered file, classify it:

| Classification | Heuristics |
|---|---|
| **Primary** | SOW, kickoff/discovery transcript, executive questionnaire, written goals doc, formal interview notes |
| **Architecture** | Filenames containing "architecture", "diagram", "topology", "flow"; SVG/PNG/PDF that look like diagrams |
| **Supporting** | Slide decks, internal notes, emails, status docs, roadmap docs |
| **Reference-only** | Cost models (.xlsx), security checklists, compliance docs, anything tangential to context |

Present the triage to the PM in a single message:

> *"Here's how I'd classify what I found. Tell me anything I should re-classify before I read the files in detail.*
>
> *Primary (will read in full):*
> *- {file} — {one-line reason}*
>
> *Architecture (will describe via Vision):*
> *- {file} — {one-line reason}*
>
> *Supporting (will read; lower weight):*
> *- {file} — {one-line reason}*
>
> *Reference-only (will list in Sources but not pull content unless you flag):*
> *- {file} — {one-line reason}*
>
> *Anything to re-classify, exclude, or add?"*

Apply the PM's edits before continuing.

### Step 1.3 — Extract sources

For each Primary, Architecture, and Supporting source, route by extension:

| Format | Route |
|---|---|
| `.md`, `.txt` | Read tool (raw). Cache: `_extracted/<name>.md` is a copy. |
| `.eml` | Read raw, extract Subject/From/To/Date/body, strip MIME/base64 boilerplate. |
| `.docx` | `uv run extractors/extract_docx.py <path>` → capture stdout to `_extracted/<name>.md`. |
| `.pdf` (text-heavy) | Read tool with `pages` parameter. Save extracted text to `_extracted/<name>.md`. |
| `.pdf` (diagram-heavy) | Read tool (Vision) using the appropriate prompt from `prompts/diagram-prompts.md`. Save to `_extracted/<name>.md` with the YAML header from that file. |
| `.svg` | First try grepping `<text>` and `<tspan>` elements. If no readable text labels emerge, rasterize to PNG (use ImageMagick if available, else ask the PM to provide a PNG export) and use the architecture-diagram Vision prompt. |
| `.png`, `.jpg`, `.jpeg` | Read tool (Vision) with the architecture-diagram or workflow prompt depending on triage class. |
| `.pptx` | `uv run extractors/extract_pptx.py <path>` → `_extracted/<name>.md`. |
| `.xlsx` | `uv run extractors/extract_xlsx.py <path>` → `_extracted/<name>.md` (only if the PM didn't classify as Reference-only). |

Caching: before running any extraction, check if `_extracted/<name>.md` exists and is newer than the source file's mtime. If yes, reuse it.

Failure handling: if extraction fails (bad file, missing dep, illegible scan), surface to the PM:
> *"I couldn't read `<file>` because {reason}. You can: (1) describe the contents in 2-3 sentences and I'll use that, (2) skip it, or (3) provide a different copy."*

Never silently skip a failed extraction.

## Phase 2 — Draft

Read `template.md` to load the CASE.md skeleton. Synthesize the draft section by section, in this order:

### Step 2.1 — Frontmatter

Fill what's safely extractable. For each value:
- **High confidence** (e.g., customer name from SOW header, project_type from SOW title): label `Assumption: high — {reason}`.
- **Medium confidence** (e.g., business goal phrasing, eng_lead from a single mention): label `Assumption: medium — {reason}`.
- **No signal**: leave for interview.

`pm` is always asked from the PM directly (it's the person running the skill). `last_updated` is set to today's date in `YYYY-MM-DD`. `start_date` is asked unless explicit in the SOW.

### Step 2.2 — Body sections

For each REQUIRED section in the template, fill what sources support and mark the rest as gaps:

- **TL;DR** — Try to extract all 5 bullets from sources. The "Hard constraint" bullet is omitted unless an actual dated/funded constraint is found.
- **Customer context** — Draft 1-2 paragraphs grounded in sources. No firmographics filler.
- **Project goal & success criteria** — Extract from SOW where possible. Phase exit signal block included only if a cited customer quote is found.
- **Scope** — Extract in-scope from SOW deliverables. Out-of-scope is a known gap unless the SOW has explicit non-goals.
- **People** — Extract from kickoff transcript, executive questionnaire, notes. Decision-makers and escalation contacts only.
- **Sources** — Auto-fill from the source manifest (point at original files, not `_extracted/`).

For each IMPORTANT section, include only if signal exists:
- **Technical context** — Include only if integrations or stack are explicit in sources.
- **Open questions** — Include only if explicit unanswered questions appear in sources, with citations.

For each OPTIONAL section, include only if applicable:
- **Engagement history** — Include only if prior projects with this customer are referenced in sources or known to the PM.
- **Glossary** — Include only if customer- or industry-specific jargon appears.

### Step 2.3 — Build the gap list

Maintain a parallel list `[{section, question_for_pm, why}]` of every gap. Order by impact:
1. REQUIRED sections still missing content.
2. Medium-confidence assumptions that need confirmation.
3. High-confidence assumptions (PM should sanity-check, but probably fine).
4. IMPORTANT/OPTIONAL inclusion decisions.

## Phase 3 — Karpathy interview loop

Open the question library at `prompts/interview-questions.md` and pick a question for the highest-priority gap. Then loop:

1. Ask **one** question to the PM (use the canonical phrasing from the library, or adapt if the gap doesn't match a canonical question).
2. Wait for the PM's answer.
3. Update the draft with the answer. If the answer reveals a new gap or contradicts an earlier assumption, add to the gap list.
4. Confirm explicitly when an assumption is resolved: *"Confirmed: {value}."*
5. Pop the next-highest-priority gap.
6. Repeat until either:
   - All REQUIRED gaps are closed AND all medium-confidence assumptions confirmed, OR
   - The PM types "done" / "good enough" / similar.

When the PM wants to bail mid-interview, save the in-progress state to `<project>/.case-md.draft` (a hidden file containing the partial draft + remaining gap list as a YAML block) and exit cleanly. The next invocation reads this file and resumes.

### Confirmation patterns for assumptions

Use the canonical phrasing from `prompts/interview-questions.md` ("Confirmation patterns" section). Always show the PM:
- The value you inferred.
- The confidence band.
- The source you inferred it from.
- A clear yes/no path to confirm or correct.

### What "filling the gap" looks like

After the PM answers:
- Replace the placeholder in the draft with the confirmed value.
- Remove the gap from the list.
- If the answer cited a source (e.g., a customer quote), verify the source exists in `_extracted/` and capture the line number for the citation.

## Phase 4 — Validate

Before writing, run the full self-check from `prompts/self-check.md`. Every item must pass.

If any check fails:
1. Identify the affected section.
2. Re-enter Phase 3 with a targeted question for that gap.
3. After the PM's answer, re-run **all** checks.
4. Only proceed to Phase 5 when every check passes.

Never write a partial CASE.md "to come back to later." Save to `.case-md.draft` and exit if the PM wants to stop.

## Phase 5 — Write

1. Render the final CASE.md to `<project>/CASE.md`.
2. Set `last_updated` in frontmatter to today's date (`YYYY-MM-DD`).
3. Print a one-paragraph summary to the PM:
   > *"CASE.md created. Required sections filled: {N}. Optional sections included: {M}. Sections omitted for lack of signal: {K} ({list of names}). File is at `<project>/CASE.md`."*
4. If a `.case-md.draft` file exists from an earlier interrupted session, delete it.
5. Done. Exit.

## Update mode (when CASE.md exists at Phase 0)

1. Read the existing `<project>/CASE.md`.
2. Confirm with the PM:
   > *"CASE.md already exists for this project (last updated {date}). Two ways I can help:*
   > *1. **Refresh from new sources** — point me at new files (or drop them in chat) and I'll diff what's changed.*
   > *2. **Targeted update** — tell me what changed (scope, people, customer info) and I'll adjust the relevant section.*
   >
   > *Which one?"*
3. Run the corresponding flow:
   - **Refresh from new sources**: Run Phase 1 on new files only. Cache extractions. Then in Phase 2, produce a section-level diff against the current CASE.md (only sections affected by the new info). Show each diff to the PM. PM approves/edits each one.
   - **Targeted update**: Ask the PM which section changed and what the new content is. Update only that section.
4. Run the full self-check (Phase 4) on the updated draft.
5. Bump `last_updated` to today's date.
6. Write the updated CASE.md.
7. Print summary: *"CASE.md updated. Sections changed: {list}. last_updated: {date}."*

Sections the PM did not approve are left exactly as they were. Never silently rewrite untouched sections.

## File references

This skill consults these files at runtime — read them when you reach the corresponding phase:

- `template.md` — the CASE.md skeleton with placeholder syntax.
- `prompts/interview-questions.md` — the canonical, jargon-free question library.
- `prompts/self-check.md` — the validation checklist for Phase 4.
- `prompts/diagram-prompts.md` — typed Vision prompts for diagram extraction.
- `extractors/extract_docx.py` — DOCX → Markdown.
- `extractors/extract_pptx.py` — PPTX → Markdown.
- `extractors/extract_xlsx.py` — XLSX → Markdown.
