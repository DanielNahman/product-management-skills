# project-case

A Claude Code skill for creating and updating **CASE.md** — a per-project context anchor used by Comm-IT Software's product team and the AI agents downstream of the SDLC.

CASE.md captures the customer, project goal, scope, people, and technical surface in one lean, predictable file. It sits upstream of every other artifact (specs, designs, retrospectives) so a fresh team member or AI agent can get loaded into a project from a single page.

## Install

Clone or copy this folder into `~/.claude/skills/`:

```
~/.claude/skills/project-case/
  SKILL.md
  template.md
  extractors/
  prompts/
  README.md
```

You'll also need:
- [`uv`](https://docs.astral.sh/uv/) — runs the Python extractors with isolated dependencies. No global pip install required.
- ImageMagick (optional) — used to rasterize SVGs whose text labels are encoded as glyphs and can't be extracted as text.

## Use

```
/project-case [path-to-project-folder]
```

If you omit the path, the skill works in the current directory.

The skill expects a folder layout like:

```
customers/
  <customer>/
    <project>/
      CASE.md          (created or updated by this skill)
      sources/         (input documents — SOW, transcripts, diagrams, notes)
      artifacts/       (downstream outputs — specs, designs, etc.)
```

If `sources/` is missing or sparse, the skill will offer to copy files from a folder you point at, or accept files dropped into the chat.

## What the skill does

1. **Discovers** source documents in `sources/`.
2. **Triages** them (Primary / Architecture / Supporting / Reference-only) and asks you to confirm.
3. **Extracts** content using format-specific routes — Python helpers for DOCX/PPTX/XLSX, Vision via Claude's Read tool for PDFs/images/SVGs.
4. **Drafts** CASE.md from sources alone, marking every inferred value as an `Assumption:` with a confidence band.
5. **Interviews** you in plain language about the gaps (one question at a time).
6. **Validates** the result (no empty stubs, no remaining assumptions, citations on live entries).
7. **Writes** CASE.md.

If CASE.md already exists, the skill detects it and offers an update flow: section-level diffs, no silent rewrites of sections you didn't approve.

## Design rules baked into the skill

- **No silent assumptions.** Every inferred value is labeled and confirmed before write.
- **No empty stubs.** A section is either filled with real content or absent entirely.
- **Citations for live content.** Open questions and phase-exit quotes carry source pointers.
- **Plain language with the PM, always.** Vetted question library; no internal jargon.
- **Lean.** Customer context capped at 2 paragraphs; whole file targets under ~600 lines.

## Files in this skill

- `SKILL.md` — the entry point Claude Code reads when you invoke `/project-case`.
- `template.md` — the CASE.md skeleton.
- `prompts/interview-questions.md` — canonical, jargon-free question library.
- `prompts/self-check.md` — validation checklist run before write.
- `prompts/diagram-prompts.md` — typed Vision prompts for each diagram type.
- `extractors/extract_docx.py` — DOCX → Markdown (python-docx, via `uv run`).
- `extractors/extract_pptx.py` — PPTX → Markdown (python-pptx, via `uv run`).
- `extractors/extract_xlsx.py` — XLSX → Markdown (openpyxl, via `uv run`).
