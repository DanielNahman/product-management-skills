# Diagram extraction prompts

Typed Vision prompts used by the `project-case` skill when extracting content from PDFs, images, and rasterized SVGs. Each prompt is designed to produce **structured, reusable** output that can be cached at `sources/_extracted/<original-name>.md` and cited later.

## Universal preamble (prepend to every diagram prompt)

> You're extracting content from a project diagram so it can be referenced in a project context document. Be **factual** and **specific**. Do not invent components or relationships that aren't visible. If a label is illegible, mark it `[unclear]`. If you're inferring a relationship from layout/proximity rather than an explicit arrow, mark it `[inferred]`.

## Architecture diagram (AI / software / system)

Used for: AI architecture diagrams, software architecture diagrams, generic system diagrams (boxes-and-arrows showing components and data flow).

> **Task:** Describe this architecture diagram so an engineer joining the project can understand the system at a glance.
>
> **Output structure (use these exact headings):**
>
> ### Components
> List every named component as a bullet. For each, give the name verbatim (preserve casing) and a one-line description of its role if labeled or inferable from the diagram. Group by visual cluster if the diagram shows zones (e.g., "Frontend", "Backend", "AWS environment").
>
> ### Connections
> For each visible arrow or line: source → target — direction (one-way / two-way) — label if any (e.g., "HTTPS", "publishes to", "calls"). Do not invent connections.
>
> ### Data flow (if depicted)
> If the diagram shows numbered steps or a flow: list each step in order. If not, write "Not depicted as a flow."
>
> ### External systems / integrations
> List anything that crosses a system or organization boundary (third-party APIs, customer systems, vendor services).
>
> ### Notes & annotations
> Capture any text annotations, legends, or callouts that aren't covered above.
>
> ### Unclear / inferred
> List anything you couldn't read or had to infer.

## Workflow / process diagram

Used for: user-flow diagrams, swim-lane process diagrams, requirements flowcharts.

> **Task:** Describe this workflow as a numbered list of steps with branching points.
>
> **Output structure:**
>
> ### Actors / lanes
> List every actor or swim lane (user, system, third party).
>
> ### Steps
> Number each step. For each: who performs it, what they do, and any outcome shown. Example: `1. User submits form → System validates input → if valid, proceed to step 2; if invalid, return error message.`
>
> ### Decision points
> List each branching point with all visible outcomes.
>
> ### Triggers / entry points
> What kicks off this workflow? (User action, scheduled job, external webhook, etc.)
>
> ### Exit conditions
> Where does the workflow end? (Success state, failure state, suspended state.)
>
> ### Unclear / inferred
> List anything you couldn't read or had to infer.

## Connectivity / DevOps / network diagram

Used for: cloud network diagrams, deployment topology, security zone diagrams.

> **Task:** Describe this connectivity diagram so a DevOps or security engineer can understand the deployment and trust boundaries.
>
> **Output structure:**
>
> ### Environments / zones
> List each network zone, environment, or trust boundary (e.g., "Customer VPC", "Comm-IT VPC", "Public Internet", "DMZ"). For each, note whether it's customer-managed, Comm-IT-managed, or third-party.
>
> ### Systems per zone
> Under each zone heading, list the systems / services / databases / endpoints that live inside it.
>
> ### Cross-zone connections
> For each connection that crosses a zone boundary: source zone → target zone — protocol/port (if labeled) — auth method (if labeled, e.g., "mTLS", "IAM role", "API key") — direction.
>
> ### Trust boundaries crossed
> Explicitly call out any connection where data leaves a customer environment, enters a public network, or crosses an organizational boundary.
>
> ### Identity / auth annotations
> Any IAM roles, service accounts, or auth flows depicted.
>
> ### Unclear / inferred
> List anything you couldn't read or had to infer.

## Routing rules

The skill picks a prompt based on the diagram's role in the source manifest:

| Source classification (Phase 1 triage) | Prompt |
|---|---|
| Architecture (AI) | Architecture diagram |
| Architecture (Software) | Architecture diagram |
| Architecture (DevOps) | Connectivity / DevOps diagram |
| Workflow / process | Workflow / process diagram |
| Requirements flowchart | Workflow / process diagram |
| Other / unclear | Architecture diagram (most generic) |

If the PM re-classified a source during the triage step, the new classification's prompt is used.

## Output handling

Vision returns the structured output. The skill:

1. Writes the result to `sources/_extracted/<original-name>.md`, with a header block:

```markdown
---
extracted_from: sources/<original-name>.<ext>
extracted_at: <ISO timestamp>
extraction_method: vision
diagram_type: <architecture|workflow|connectivity>
---

# Extracted: <original filename>

[Vision output goes here]
```

2. Reuses the cached file on subsequent runs unless the source mtime is newer than `extracted_at`.

3. When CASE.md cites content from a diagram, the citation points at the **extracted** file (which is line-addressable), not the original binary diagram.

## What we never do

- Never invent components or connections that aren't in the diagram.
- Never summarize away a label — if a component is named "Lambda::TicketRouter::v2", capture that exact name, not "the ticket-routing function".
- Never silently skip an illegible region. Mark it `[unclear]` and list it under "Unclear / inferred".
- Never combine the architecture, workflow, and connectivity prompts into a single "describe this diagram" prompt — the structured output gets sloppy.
