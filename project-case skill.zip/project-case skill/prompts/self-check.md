# Self-check (validation before write)

Run every check below before writing CASE.md to disk. If any check fails, re-enter Phase 3 (interview) for the affected gap. Never write a CASE.md that fails any of these.

## Frontmatter

- [ ] YAML between the `---` fences parses cleanly (no tabs, no smart quotes, no unbalanced braces).
- [ ] `project_id` is present, lowercase-kebab-case, and matches the slug used in the folder path.
- [ ] `customer` is present and not a placeholder like `{Customer}`.
- [ ] `project_type` is exactly one of: `assessment`, `poc`, `mvp`, `production`.
- [ ] `pm` has both `name` and `email` filled.
- [ ] `start_date` is present in `YYYY-MM-DD` format.
- [ ] `last_updated` is today's date in `YYYY-MM-DD` format.
- [ ] All optional keys (`project_manager`, `eng_lead`, `ai_lead`, `target_end_date`, `related_projects`) are either filled with real values or removed entirely — no half-filled `{ name: "" }` artifacts.

## REQUIRED body sections

For each of these sections, the heading is present and the section has substantive content (not placeholders, not echoes of the template):

- [ ] `## TL;DR` — at least 4 of the 5 bullets present (the "Hard constraint" bullet is optional). No `{...}` placeholders remain.
- [ ] `## Customer context` — 1-2 paragraphs of real prose. Not just generic firmographics. Mentions the part of the business that this engagement touches.
- [ ] `## Project goal & success criteria` — has both `**Business goal:**` and `**Functional goal:**` lines, plus at least one bullet under `**Success criteria:**`.
- [ ] `## Scope` — both `**In scope:**` and `**Out of scope:**` blocks present, each with at least one bullet. Out-of-scope bullets each carry a one-line "why out".
- [ ] `## People` — table has at least one decision-maker on each side (Customer + Comm-IT). Header row + at least one data row per side.
- [ ] `## Sources` — at least one source entry. Every entry points at a real file under `sources/`.

## IMPORTANT body sections

These sections appear in the file **only if** they have real content. If a section has no real content, the heading must be **absent entirely** (no empty stub).

- [ ] `## Technical context` — if present, has at least one filled bullet. Compliance/security bullet only present if customer explicitly stated requirements.
- [ ] `## Open questions` — if present, every entry carries a `source: sources/_extracted/<file>:<line>` citation. No entries without citations.

## OPTIONAL body sections

Same rule: present only if real content.

- [ ] `## Engagement history with this customer` — present only if at least one prior project exists, with name, dates, type, and outcome.
- [ ] `## Glossary` — present only if at least one customer-specific or industry-specific term needs defining.

## Phase exit signal sub-block

Inside `## Project goal & success criteria`, the `**Phase exit signal:**` block is present **only if** there's a cited customer quote.

- [ ] If present, the block contains a verbatim quote in a `>` blockquote AND a `source: sources/_extracted/<file>:<line>` citation.
- [ ] If absent, neither the heading line nor the blockquote appears.

## Assumption discipline

- [ ] No `Assumption:` labels remain anywhere in the rendered file. (Assumptions exist during the interview only — by write time, every one has been confirmed or replaced with a real value.)
- [ ] No `<!-- TBD -->` markers anywhere.
- [ ] No `{...}` placeholder syntax from the template anywhere in the rendered file.

## Citation discipline

- [ ] Every `source: ...` reference points at a path that exists (either `sources/<file>` or `sources/_extracted/<file>.md`).
- [ ] Every blockquote attributed to the customer has a `source:` line directly below it.

## Sources block consistency

- [ ] Every file listed under `## Sources` exists in `sources/`.
- [ ] No file in `sources/` is missing from `## Sources` unless it's a derived file (under `sources/_extracted/` or starting with `.`).

## Length sanity

These are guardrails against bloat. Soft limits — the skill flags overruns to the PM but does not auto-truncate.

- [ ] `## Customer context` is no more than 2 paragraphs.
- [ ] `## TL;DR` is no more than 5 bullets.
- [ ] Whole file is under ~600 lines (a CASE.md much longer than that has likely lost its "lean anchor" purpose).

## On failure

When a check fails:
1. Identify which section is implicated.
2. Re-open the corresponding gap in Phase 3 with a targeted question to the PM.
3. After the PM's answer, re-run **all** checks (a fix in one section can break another).
4. Only proceed to write when every check passes.

Never write a partial CASE.md "to come back to later." If the PM wants to bail mid-interview, save the in-progress draft to `<project>/.case-md.draft` (hidden) and exit cleanly — the next invocation can pick up from the draft.
