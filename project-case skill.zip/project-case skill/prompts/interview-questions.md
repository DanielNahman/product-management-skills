# Interview question library

Vetted, jargon-free questions used during the Karpathy interview loop in the `project-case` skill. Every question is plain language. No internal acronyms (UAT, RACI, SLA, MVP-as-shorthand, etc.) unless the term appears verbatim in the customer's own materials.

## Principles

1. **Plain language only.** A bright person who's never worked in tech should be able to answer. If a term is unavoidable, define it inline.
2. **One question per turn.** Never batch multiple questions into one message — the PM will only answer the first.
3. **Multiple choice when possible.** Cuts cognitive load. Always include "Other (type your own)" as an escape hatch.
4. **Quote, don't paraphrase, when reaching for customer voice.** When asking the PM to provide a customer's framing, ask for the quote and source — not a summary.
5. **Confirmation, not interrogation.** When the answer is likely already in the sources, ask the PM to confirm the inference, not to re-derive it.

## Question patterns by section

### Frontmatter — project_type
> *"What kind of engagement is this? Pick the option that matches the agreement: [Assessment — discovery + scope for the next step] / [POC — proof of concept to test value] / [MVP — production-grade first version] / [Production — full deployment]."*

### Frontmatter — people (PM, eng lead, ai lead, project manager)
> *"Who's the product manager on this project? (name and email)"*
>
> *"Is there a separate person handling day-to-day project coordination (timelines, meetings, status)? If yes, name and email; if no, skip."*
>
> *"Who's the engineering lead, if one's been assigned? Skip if not yet."*
>
> *"Who's the AI lead, if one's been assigned? Skip if not relevant or not yet assigned."*

### Frontmatter — start_date / target_end_date
> *"When did the project officially start (or when will it)? Date in YYYY-MM-DD."*
>
> *"Is there a target end date in the agreement? If yes, when. If no end date is fixed, skip."*

### TL;DR — Who
> *"In one line, what does the customer do? Focus on the part that matters for this engagement, not their whole company history."*

### TL;DR — Why us (the customer's pain or opportunity)
> *"In the customer's own words, what problem are they trying to solve, or what opportunity are they trying to capture? Paste a quote if you have one (with source: which doc, transcript line, or meeting). If you don't have a direct quote, give your best paraphrase and I'll mark it as your wording, not theirs."*

### TL;DR — What we're building
> *"In one short line, what are we building for them? Focus on the deliverable, not the technology."*

### TL;DR — Target outcome
> *"What's the measurable business outcome the customer is buying? Examples: 'cut support ticket handling time by 40%', 'launch the AI feature to 1,000 users by end of Q3', 'pass internal compliance review with zero findings'. If no measurable target exists yet, say so and I'll flag it as an open question."*

### TL;DR — Hard constraint
> *"Is there a hard deadline or hard rule that has to shape the work? Examples: a funding cutoff date, a regulatory date, a customer contract date, who owns the code. If none, just say 'none' and I'll skip the bullet."*

### Customer context
> *"In two short paragraphs at most, what does the customer sell or build, which part of their business or product does this engagement touch, and how does Commit fit in? I'll draft from the sources I have — please correct anything that's off or generic."*

(Then: *"Here's my draft of the Customer context section. Anything wrong or missing? [shows draft]"*)

### Project goal & success criteria — Business goal
> *"What's the outcome the customer wants in business terms? Try to phrase it as the result they care about, not the system we're building. Example: 'reduce average customer service response time' rather than 'build a chatbot'."*

### Project goal & success criteria — Functional goal
> *"In plain terms, what does the system need to do to deliver that business outcome? Example: 'answer common customer questions automatically and create a support ticket when it can't'."*

### Project goal & success criteria — Success criteria
> *"How will we know this worked? List the testable conditions. Examples: 'AI handles 70% of incoming questions without a human stepping in', 'response time under 30 seconds'. If you don't have specific criteria yet, say so — I'll flag it as an open question."*

### Project goal & success criteria — Phase exit signal (optional)
> *"Did the customer say anything specific about what would convince them to move to a bigger engagement (POC → MVP, MVP → production, etc.)? If yes, paste their words and where you heard them (which document, which transcript, which meeting). If no — just say 'no' and I'll skip this section."*

### Scope — In scope
> *"What are we delivering? List the major pieces. I'll draft from the agreement and you can correct."*

(Then: *"Here's the in-scope list I drafted from the SOW. Anything wrong or missing?"*)

### Scope — Out of scope
> *"What are we explicitly **not** doing, even if the customer might assume we are? Each entry needs a one-line reason ('belongs to phase 2', 'customer's team owns it', 'too complex for current budget'). If you can't think of any, that's a yellow flag — out-of-scope items are how we prevent fights later."*

### People
> *"Who needs to be in CASE.md? I want decision-makers and escalation contacts only — not every CC on every email. For each person: name, role, customer or Commit side, what they decide or own, and the best channel to reach them (Slack, email, phone)."*

### Technical context (when sources show signal)
> *"From the materials I read, the customer's stack looks like {list}. Is that right, and is anything missing?"*

### Technical context — mandatory integrations
> *"Which systems do we have to integrate with? List only the ones the customer requires — not 'nice to haves'."*

### Technical context — compliance/security
> *"Did the customer state any specific compliance or security requirements (SOC2, HIPAA, ITAR, data residency, anything else)? If they didn't say it explicitly, skip — we don't add compliance work that wasn't asked for."*

### Open questions
> *"From the kickoff and notes I read, here are the open questions I noticed: {list}. For each, who's the owner and is it blocking? Add any I missed; remove any that have since been answered."*

### Engagement history (when prior projects exist)
> *"Have we worked with this customer before? If yes, list each prior project with a one-line outcome. I'll link to their CASE.md files if they exist."*

### Glossary
> *"Are there any customer-specific or industry-specific terms that someone joining the project tomorrow wouldn't know? If yes, list them with one-line definitions. If everything is standard, skip."*

## Confirmation patterns (for assumptions)

When the skill has inferred a value with high or medium confidence, present it for explicit confirmation:

> *"Assumption (high confidence): **project_type = MVP** — based on the SOW title 'Commit - Ryvid - SOW3 - AI MVP'. Confirm? [yes / no — type the right one]"*

> *"Assumption (medium confidence): the customer's main pain is **manual triage of support tickets** — paraphrased from the SOW Engagement Summary. I don't have a direct customer quote. Confirm the framing? [yes / no — paste a real quote if you have one]"*

> *"Assumption (low confidence): **eng lead = {name}** — based on a single mention in {sources/notes.md}. Confirm? [yes / no — give the right name, or skip if no eng lead is assigned]"*

## Closing the loop

When all REQUIRED gaps are closed:

> *"All required sections are filled. I have {N} optional sections included and {M} omitted for lack of signal. Want to review the draft top-to-bottom now, or write to CASE.md?"*

## What we never ask

- Anything that's already unambiguous in the sources (re-asking wastes the PM's time).
- Anything that requires the PM to invent content (if the answer isn't in their head or the sources, leave it as an open question and move on).
- Compound questions ("who's the eng lead and what's the deadline and...").
- Yes/no questions when multiple choice would be more informative.
- Generic background questions about the customer that don't change CASE.md content (employee count, when founded, office locations).
