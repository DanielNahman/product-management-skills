# /// script
# requires-python = ">=3.10"
# dependencies = [
#   "python-docx>=1.1.0",
# ]
# ///
"""Extract text from a .docx file, preserving heading hierarchy.

Output format: Markdown. Headings map to ATX (#, ##, ###...). Paragraphs
become plain text blocks. Tables render as Markdown tables. The output
is written to stdout so the caller can capture it or pipe to a cache.

Usage:
    uv run extract_docx.py <path-to-docx>
"""

import sys
from pathlib import Path

from docx import Document
from docx.document import Document as DocxDocument
from docx.oxml.ns import qn
from docx.table import Table
from docx.text.paragraph import Paragraph


def iter_block_items(parent):
    """Yield paragraphs and tables in document order."""
    if isinstance(parent, DocxDocument):
        parent_elm = parent.element.body
    else:
        parent_elm = parent._tc

    for child in parent_elm.iterchildren():
        if child.tag == qn("w:p"):
            yield Paragraph(child, parent)
        elif child.tag == qn("w:tbl"):
            yield Table(child, parent)


def heading_level(paragraph: Paragraph) -> int:
    """Return heading level 1-9, or 0 if not a heading."""
    style_name = ((paragraph.style.name if paragraph.style else "") or "").lower()
    if not style_name.startswith("heading"):
        return 0
    parts = style_name.split()
    if len(parts) >= 2 and parts[1].isdigit():
        return int(parts[1])
    return 0


def render_paragraph(paragraph: Paragraph) -> str:
    text = paragraph.text.strip()
    if not text:
        return ""
    level = heading_level(paragraph)
    if level:
        return f"\n{'#' * min(level, 6)} {text}\n"
    return text


def render_table(table: Table) -> str:
    if not table.rows:
        return ""
    rows = []
    for row in table.rows:
        cells = [c.text.replace("\n", " ").strip() for c in row.cells]
        rows.append("| " + " | ".join(cells) + " |")
    if not rows:
        return ""
    header = rows[0]
    sep = "| " + " | ".join("---" for _ in table.rows[0].cells) + " |"
    body = rows[1:]
    return "\n".join([header, sep] + body) + "\n"


def extract(path: Path) -> str:
    doc = Document(str(path))
    parts: list[str] = []
    for block in iter_block_items(doc):
        if isinstance(block, Paragraph):
            rendered = render_paragraph(block)
            if rendered:
                parts.append(rendered)
        elif isinstance(block, Table):
            rendered = render_table(block)
            if rendered:
                parts.append(rendered)
    return "\n".join(parts).strip() + "\n"


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: extract_docx.py <path-to-docx>", file=sys.stderr)
        return 2
    path = Path(sys.argv[1])
    if not path.is_file():
        print(f"file not found: {path}", file=sys.stderr)
        return 1
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdout.write(extract(path))
    return 0


if __name__ == "__main__":
    sys.exit(main())
