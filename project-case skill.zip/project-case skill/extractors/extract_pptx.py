# /// script
# requires-python = ">=3.10"
# dependencies = [
#   "python-pptx>=1.0.0",
# ]
# ///
"""Extract text from a .pptx file, slide by slide, including speaker notes.

Output format: Markdown. Each slide becomes a section with its title (or
slide number if no title) as an H2, body shapes as paragraphs, and any
speaker notes under an H3.

Usage:
    uv run extract_pptx.py <path-to-pptx>
"""

import sys
from pathlib import Path

from pptx import Presentation


def shape_text(shape) -> str:
    if not shape.has_text_frame:
        return ""
    parts = []
    for paragraph in shape.text_frame.paragraphs:
        text = "".join(run.text for run in paragraph.runs).strip()
        if text:
            parts.append(text)
    return "\n".join(parts)


def slide_title(slide) -> str | None:
    if slide.shapes.title and slide.shapes.title.has_text_frame:
        title = slide.shapes.title.text_frame.text.strip()
        return title or None
    return None


def slide_notes(slide) -> str:
    if not slide.has_notes_slide:
        return ""
    notes_frame = slide.notes_slide.notes_text_frame
    if not notes_frame:
        return ""
    return notes_frame.text.strip()


def extract(path: Path) -> str:
    pres = Presentation(str(path))
    parts: list[str] = []
    for idx, slide in enumerate(pres.slides, start=1):
        title = slide_title(slide)
        header = title if title else f"Slide {idx}"
        parts.append(f"## {header}")

        title_shape = slide.shapes.title if slide.shapes.title else None
        for shape in slide.shapes:
            if shape is title_shape:
                continue
            text = shape_text(shape)
            if text:
                parts.append(text)

        notes = slide_notes(slide)
        if notes:
            parts.append("### Speaker notes")
            parts.append(notes)

        parts.append("")
    return "\n\n".join(parts).strip() + "\n"


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: extract_pptx.py <path-to-pptx>", file=sys.stderr)
        return 2
    path = Path(sys.argv[1])
    if not path.is_file():
        print(f"file not found: {path}", file=sys.stderr)
        return 1
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdout.write(extract(path))
    return 0


if __name__ == "__main__":
    sys.exit(main())
