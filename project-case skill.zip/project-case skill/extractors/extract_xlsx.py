# /// script
# requires-python = ">=3.10"
# dependencies = [
#   "openpyxl>=3.1.0",
# ]
# ///
"""Extract text from an .xlsx file, sheet by sheet.

Output format: Markdown. Each sheet becomes a section. Cell content is
rendered as a Markdown table. Empty trailing rows/columns are trimmed.

Usage:
    uv run extract_xlsx.py <path-to-xlsx>
"""

import sys
from pathlib import Path

from openpyxl import load_workbook


def trim_grid(rows: list[list[str]]) -> list[list[str]]:
    while rows and not any(cell.strip() for cell in rows[-1]):
        rows.pop()
    if not rows:
        return rows
    max_col = 0
    for row in rows:
        for idx in range(len(row) - 1, -1, -1):
            if row[idx].strip():
                max_col = max(max_col, idx + 1)
                break
    return [row[:max_col] for row in rows]


def render_sheet(ws) -> str:
    raw_rows: list[list[str]] = []
    for row in ws.iter_rows(values_only=True):
        cells = ["" if v is None else str(v).replace("\n", " ").strip() for v in row]
        raw_rows.append(cells)
    rows = trim_grid(raw_rows)
    if not rows:
        return f"## {ws.title}\n\n(empty sheet)\n"

    width = max(len(r) for r in rows)
    rows = [r + [""] * (width - len(r)) for r in rows]

    header = "| " + " | ".join(rows[0]) + " |"
    sep = "| " + " | ".join("---" for _ in rows[0]) + " |"
    body = ["| " + " | ".join(r) + " |" for r in rows[1:]]
    return f"## {ws.title}\n\n" + "\n".join([header, sep] + body) + "\n"


def extract(path: Path) -> str:
    wb = load_workbook(filename=str(path), data_only=True, read_only=True)
    parts = [render_sheet(ws) for ws in wb.worksheets]
    return "\n\n".join(parts).strip() + "\n"


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: extract_xlsx.py <path-to-xlsx>", file=sys.stderr)
        return 2
    path = Path(sys.argv[1])
    if not path.is_file():
        print(f"file not found: {path}", file=sys.stderr)
        return 1
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stdout.write(extract(path))
    return 0


if __name__ == "__main__":
    sys.exit(main())
