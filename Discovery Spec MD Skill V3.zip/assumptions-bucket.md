# Assumptions Bucket (master pool)

These are **raw, reusable assumptions** that protect Commit on AI+SW engagements.
They are a starting pool, **not a paste-in list**. For every project:

- **Pull only what applies** to this use case.
- **Tailor the wording** to the actual client, data, and features (replace
  placeholders like `<N>`, `<customer>`, `<format>`).
- **Drop anything that isn't true** for this engagement.
- **Add per-feature assumptions** that aren't in this pool (see the SKILL's
  "Building §6 Assumptions" procedure — the per-feature walk).

Every assumption is written so a non-technical client can read it and either
agree or push back. Keep that bar when you tailor: **one claim, plain words,
one possible meaning.**

Group the final §6 under these five headers. The pool below is organized the
same way.

---

## 1. Engagement & Commercial

These protect the engagement itself, regardless of which features are built.

- All work under this Scope of Work is done remotely, unless both sides agree
  otherwise in writing.
- All deliverables depend on Commit being able to collect and review the needed
  information within the agreed project budget.
- Commit delivers documentation as a README file plus one handover session, so
  the customer can run the solution after the engagement ends.
- The customer names one main point of contact for the whole project.
- The customer's main point of contact gives Commit ongoing feedback and
  guidance on the work.
- The components, services, and architecture described here are based on similar
  past projects and may change during delivery. The agreed functionality stays
  the same.
- Items marked "if time allows" are optional. They are only done if everything
  else is finished within the budget and timeline.
- The solution is made of AI models and modules only. It does not include
  frontend or backend work unless that work is listed explicitly in scope.

## 2. AI / Model

These set expectations about what the AI can and can't be guaranteed to do.

- AI model quality depends on the quality and amount of data provided. Quality
  may drop if there isn't enough good data.
- Commit cannot guarantee the speed of the AI model's responses. Confirming
  speed is one reason a POC is run.
- Latency and other performance numbers are not part of the success criteria for
  this phase.
- The customer provides a Golden Dataset of `<N, e.g. 30>` or more items to test
  the solution against.
- If no Golden Dataset is provided, the result quality will likely be lower.
- If no Golden Dataset is provided, Commit may create a synthetic dataset, and
  that dataset becomes the benchmark.
- Commit chooses the chunking strategy that best serves the required
  functionality.
- Commit chooses the prompt-management tool (for example Langfuse or the AWS
  Prompt Management console) during the engagement.
- Prompt editing is done through that prompt-management tool, not through a
  custom-built user interface.
- Playbook or configuration versions are managed in the AWS console, not in a
  custom-built user interface.
- Files loaded into the knowledge base are in `<format, e.g. PDF>` format.
- The vector database used is the one Commit created in the POC stage.
- Commit may create, change, add, or delete items in the vector database at any
  time during the project.
- Commit may replace the existing vector database with a new one, and delete the
  old one, during the project.
- When records for a given user ID are updated, all earlier records with that
  user ID may be deleted.

## 3. DevOps / Environment

These cap Commit's infrastructure obligations.

- The solution is deployed to one AWS environment, provided by the customer.
- The solution is deployed to the development environment only. The customer
  deploys it to any further environments.
- The customer deploys the solution to its own environment.
- The customer sets up the environment so it can serve more than `<N, e.g. 5>`
  users at the same time.
- Only basic logging is included. Custom dashboards, alerting, and monitoring are
  not included unless listed in scope.
- The customer is responsible for the cyber-security of the deployed solution.
- Some AWS services may run in a different region than the customer's main
  environment, including cross-region use.
- Deploying the solution on a serverless service such as AWS AgentCore or AWS
  Lambda is acceptable.
- The AWS account has high enough service quotas for the project, and at least
  the standard account quotas.

## 4. Customer Responsibilities & Inputs

These make clear what the customer must do so Commit isn't blocked or blamed.

- The customer does all frontend and backend work needed to use the AI solution.
- The customer integrates the AI solution into its own systems (backend,
  frontend, and any other components).
- The customer triggers the ingestion service.
- The customer provides the data needed to build the solution, matching the
  requirements in this document.
- The customer provides a person to help with tasks such as schema enrichment,
  question refinement, response review, and tool-output review, and makes that
  person available to the development team.
- The customer makes a domain expert available to review extraction quality
  (human-in-the-loop review).
- The customer gives Commit the access and permissions needed for this work.
- The customer gives Commit access to its AWS account and resources as needed.
- The customer provides documentation about its existing infrastructure.

## 5. Per-Feature Protective Assumptions

This section is **not** a fixed pool — it is built by walking each feature in §4
and writing, in plain prose, the assumption that protects Commit for that
feature. Examples of the *shape* (do not paste — derive your own per feature):

- The customer provides the field mapping for any third-party system this
  feature writes to, before development of that feature starts.
- This feature reads its source data in `<format>` only; other formats are out
  of scope for this feature.
- The interface this feature calls is stable for the project's duration; if the
  customer changes it, the change is handled as a change order.
- This feature returns a result only when its job finishes; queueing or
  partial-progress reporting is not included.

See the SKILL's "Building §6 Assumptions" procedure for how to run the
per-feature walk.
