---
client: <Client legal name>
project: <Project name>
sow_number: <SOW-N>
project_type: ai_plus_sw
phase: discovery
status: draft                    # draft | in_review | signed | locked
case_doc: ./case.md
linked_specs:
  discovery: null                # only populated in dev-phase specs
budget_usd: <number or null>
funding_notes: <e.g. "$65K AWS Incremental, $X client" — or null>
delivery_partner: Commit
last_updated: <YYYY-MM-DD>
---

# <Client> — <Project> — Discovery Spec

> This spec defines **what** the product must do at MVP. Effort, timeline, team, risks, and platform/infra scope are added by the SOW-generator skill into the Excel and filled by architects. This document stays a pure product artifact.

---

## 1. Business Context

<2–4 sentence anchor: who the client is, the business problem this product solves, and the one-line outcome this MVP is supposed to produce. Not the full case — just enough to orient a reader landing here cold.>

See [`./case.md`](./case.md) for the full business case, target impact, and funding context.

---

## 2. Success Criteria & KPIs

> The MVP is marked Successful only if all KPIs below are Successful.

| KPI | Target | Measurement | Type |
|---|---|---|---|
| <KPI name> | <e.g. ≥80%> | <how it's measured, against what dataset/test> | AI \| NFR |
| <KPI name> | <target> | <measurement> | AI \| NFR |

**Type values:**
- `AI` — measured by running the solution against the eval set (populated in dev phase).
- `NFR` — measured by load/perf/availability tests on the deployed system.

---

## 3. Non-Functional Requirements

| Category | Requirement |
|---|---|
| Latency | <e.g. "Multi-minute responses acceptable at MVP — explicitly deprioritized" or a target> |
| Language | <e.g. English only> |
| Observability | <what gets logged: errors, app events, etc.> |
| Security | <encryption, network controls, access controls> |
| Auth | <how users authenticate — or "out of scope, provided by X"> |
| Regulation | <e.g. "HIPAA, COPPA out of scope" or applicable regs> |
| Environments | <e.g. "Single production environment, customer-provided"> |

Add or remove rows as needed. Keep one constraint per row.

---

## 4. Scope

Scope is organized as **Epic → Feature → Requirement**. Each requirement is tagged `AI` or `SW`:

- **`SW`** requirements become Jira tickets in the dev phase (the Jira-generator skill walks `type=SW` rows).
- **`AI`** requirements feed the AI dev's capability spec and the eval set definition.

**Requirement IDs are stable handles.** Format: `<epic>.<feature>.<requirement>` (e.g. `1.2.3`). Append new IDs at the end of a feature when adding requirements; never renumber. If a requirement is removed, leave its ID retired and don't reuse it.

**Each requirement is written as one sentence**, in the form *"The system shall…"* or *"The user shall be able to…"*. No compound requirements (split "X and Y" into two rows).

---

### Epic 1: <Epic name>

<1–2 sentence description of what this epic covers and why it exists.>

#### Feature 1.1: <Feature name>

<1–2 sentence description of the feature.>

| ID | Type | Requirement |
|---|---|---|
| 1.1.1 | SW \| AI | <The system shall… / The user shall be able to…> |
| 1.1.2 | SW \| AI | <one-sentence requirement> |

**Notes:** <Optional. Constraints, dependencies, or assumptions specific to this feature that an architect needs to read while estimating. Skip the line entirely if there are none.>

#### Feature 1.2: <Feature name>

<description>

| ID | Type | Requirement |
|---|---|---|
| 1.2.1 | SW \| AI | <requirement> |

---

### Epic 2: <Epic name>

<description>

#### Feature 2.1: <Feature name>

<description>

| ID | Type | Requirement |
|---|---|---|
| 2.1.1 | SW \| AI | <requirement> |

---

> *Add additional epics and features following the same shape. The downstream SOW-generator skill produces one row per Feature in the Effort Breakdown sheet — so feature granularity should match what an architect would naturally estimate as a unit.*

---

## 5. Architecture

High-level target architecture:

```
<ASCII diagram showing the major components and data flow.
Keep it conceptual — boxes and arrows, not infrastructure detail.
Component-level detail is fine; AWS resource-level detail belongs in the dev spec.>
```

<Optional: reference a rendered diagram file>
See [`./architecture.png`](./architecture.png) for the rendered diagram.

---

## 6. Assumptions

Each assumption is a single self-contained claim. Split compound assumptions into separate bullets.

- <One assumption.>
- <One assumption.>
- <One assumption.>

---

## 7. Out of Scope

What we explicitly are *not* building in this MVP. Each item should be specific enough to support a change-order conversation later.

- <Out-of-scope item.>
- <Out-of-scope item.> *(Optional italic parenthetical: e.g. "Flagged by client; candidate for SOW #N.")*

---

## 8. Customer-Provided Inputs

What the client must supply for delivery to proceed.

**Content & data:**
- <Data source, format.>
- <Data source, format.>

**Access & credentials:**
- <API keys, account access, permissions required.>

**People & process:**
- <Named POC, sync cadence, UAT participation, domain experts, etc.>
