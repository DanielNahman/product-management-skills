# Section Quality Checks

Apply these checks as you draft each section. When a check fails, ask the PM for specifics rather than guessing.

---

## YAML Frontmatter

| Check | Why it matters |
|---|---|
| `client` is the legal name, not a nickname | The SOW Excel uses this in the contract preamble. |
| `sow_number` follows the `SOW-N` format | Skill convention. |
| `project_type` is exactly `ai_plus_sw` or `pure_sw` | Drives downstream skill routing. |
| `phase` is exactly `discovery` | This skill only produces discovery specs. |
| `last_updated` is today's date in YYYY-MM-DD | Stale dates erode trust. |
| `case_doc` points to a real file | If `./case.md` doesn't exist, you shouldn't be in this skill. |

---

## §1 Business Context

| Check | What good looks like |
|---|---|
| 2–4 sentences, no more | A reader scanning this section gets oriented in <30 seconds. |
| References case.md explicitly | Reader knows where to dig deeper. |
| Names the client and the business problem | Not just "we're building a chatbot" — *whose* chatbot, *what* problem. |
| Mentions the one-line outcome of MVP | What changes for the business when MVP ships. |

**Reject when:**
- It's a copy of case.md §1 — anchor, don't duplicate.
- It opens with company history or mission — irrelevant; cut to the problem.
- It describes the *solution* before the *problem* — flip it.

---

## §2 Success Criteria & KPIs

Every KPI must be a complete, testable claim. The format is:

```
| <KPI name> | <numeric target> | <measurement procedure, including dataset/test> | AI | NFR |
```

| Check | What good looks like |
|---|---|
| Every KPI has a number | "≥80%", "≥20", "99%". Not "high", "fast", "scalable". |
| Every KPI has a measurement procedure | *"Semantic similarity ≥0.8 between solution response and Ideal Response in Golden Dataset"* — clear how to measure. |
| AI KPIs reference the eval/golden dataset | If it's an AI KPI, it's measured against eval data. |
| NFR KPIs reference the load/perf test method | If it's an NFR, it's measured by a test. |
| The Type column is exactly `AI` or `NFR` | No third value. |
| The "Successful only if all KPIs are Successful" line is present | This is the contractual hammer. |

**Reject when:**
- KPI is "user satisfaction" or "great UX" — not measurable at MVP without a survey instrument the SOW doesn't include.
- KPI is a feature presence, not a quality target — *"Chatbot deployed to Shopify"* is scope, not a KPI.
- Two KPIs are bundled — *"Accuracy and correctness ≥80%"* split into two rows.

---

## §3 Non-Functional Requirements

Categorical table. Every row is a constraint the system must respect.

| Check | What good looks like |
|---|---|
| Each row is exactly one category, one constraint | No bundling. |
| Constraints are written as the system's behavior, not goals | *"Encryption in transit"* — clear. *"We aim to be secure"* — useless. |
| Required categories present | At minimum: Latency, Language, Observability, Security, Auth, Environments. |
| Auth row clarifies who builds it | Almost always: "provided by <X>, not built in scope" or "built in scope to <Y> standard". |
| Regulation row is explicit, even when "out of scope" | Saying "HIPAA, COPPA, GDPR out of scope" protects against later scope creep. |

**Reject when:**
- A row is actually a KPI (has a target/measurement) — move to §2.
- A row is actually a feature requirement (a thing the user does) — move to §4.
- A row is "follows industry best practices" — not a constraint, push for specifics.

---

## §4 Scope (the deepest section)

### Hierarchy checks

| Check | What good looks like |
|---|---|
| 2–5 epics | Fewer = epics are too coarse. More = epics are doing the job features should do. |
| Each epic has 2–6 features | Same logic. |
| Each feature has 1+ requirements | A feature with zero requirements is dead weight. |
| Each feature has a 1–2 sentence prose description | Above the requirements table. |

### Requirement ID checks

| Check | What good looks like |
|---|---|
| IDs follow `<epic>.<feature>.<requirement>` | e.g. `2.3.1`, `2.3.2`. Three levels, dot-separated. |
| IDs within a feature are sequential, append-only | If 2.3.4 is added later, it goes after 2.3.3, never reuses a deleted ID. |
| No duplicate IDs anywhere | The Jira-generator skill keys on these. Collision = corrupt output. |

### Requirement statement checks

| Check | What good looks like |
|---|---|
| Each requirement is one sentence | If you need a paragraph, it's actually multiple requirements. |
| Form is "The system shall…" or "The user shall be able to…" | Not "we will implement", not "the chatbot does", not "users can". |
| No compound requirements | Split "X **and** Y" into two rows. Same for "X **or** Y". |
| Type is exactly `AI` or `SW` | No `AI/SW`, no `Both`, no `null`. If it spans both, split into two requirements. |

### AI vs SW typing

This is the most error-prone field. Use this rule:

- **`AI`** — the agent's *behavior*: what it generates, how it reasons, what it retrieves, what it classifies, what it decides. The thing that's tested by an eval set.
- **`SW`** — deterministic system behavior: UI components, API endpoints, data persistence, integrations, file uploads, auth flows. The thing that's tested by unit/integration/E2E tests.

| Requirement | Type | Why |
|---|---|---|
| "The agent shall classify each request as Simple or Complex." | AI | Classification is a model decision, eval-tested. |
| "The user shall be able to upload images up to 50MB." | SW | Deterministic file-handling code. |
| "The agent shall retrieve relevant passages from the KB." | AI | Retrieval quality is eval-tested. |
| "The system shall persist every JSON ticket to S3." | SW | Deterministic storage code. |
| "The agent shall ask 4–5 diagnostic questions for Complex cases." | AI | Generative behavior, eval-tested. |
| "The system shall transform JSON tickets into HubSpot's API schema." | SW | Deterministic transform code. |

### Scope-purity checks (most important)

| Check | What to do |
|---|---|
| §4 contains no Terraform, CI/CD, WAF, IAM, VPC, CloudFront items | Move out. SOW-creation skill adds these. |
| §4 contains no observability/logging tooling setup | Same. |
| §4 contains no security infra (encryption, key rotation) | Same. |
| §4 contains no test framework setup | Same. |

§4 is **product scope only** — what users do, what the system produces. Everything else is platform scope and goes in the SOW Excel by default.

---

## §5 Architecture

| Check | What good looks like |
|---|---|
| ASCII or external diagram present | Not just a list of services. |
| Major components and data flow are visible | Boxes and arrows, not just boxes. |
| Conceptual level | "API Gateway → Lambda → Bedrock" is fine. IAM policies, subnet CIDRs, security groups are NOT. |
| If external diagram referenced, the path is correct | `./architecture.png` should actually exist or be a placeholder the PM commits to. |

**Reject when:**
- It's just a bulleted list of AWS services with no flow.
- It's so detailed that it pre-empts the dev spec's design work.

---

## §6 Assumptions

| Check | What good looks like |
|---|---|
| Each assumption is one self-contained claim | No "X and Y" — split. |
| Each assumption is specific enough to be disputed | The client must be able to read it and say "yes" or "no, that's wrong." |
| No "standard practices" / "industry norms" / "as agreed" | These are non-claims. Push for specifics. |
| Assumptions about customer behavior are flagged | "Ryvid triggers ingestion" — yes. "Ryvid does X" — yes. These prevent surprise blocking. |

**Reject when:**
- Assumption is a project goal in disguise: *"We assume the system will be performant"* — that's a KPI or NFR.
- Assumption is hedging language: *"It's expected that things may vary"* — useless.
- Assumption duplicates a §3 NFR or §7 out-of-scope item — pick one home.

---

## §7 Out of Scope

This section is the **most-skipped and most-important** for change-order conversations. Push hard for completeness.

| Check | What good looks like |
|---|---|
| 3–8 items at minimum | A spec with 1 out-of-scope item is hiding scope risk. |
| Each item is specific | "Performance optimization" is bad. "Latency optimization below the MVP target" is good. |
| Items the client wants but isn't getting are flagged | Italic parenthetical: *"(Flagged by client; candidate for SOW #N.)"* |
| Items mirror discussion from discovery | If you don't know what was discussed, ask the PM. |
| Major obvious exclusions present | Multi-environment, non-English, regulatory cert, bidirectional integrations, mobile native apps, etc. — list whatever's relevant. |

**Reject when:**
- The list is empty or has 1 item — interrogate the PM for what was deferred during discovery.
- An item is a feature the spec actually delivers — contradiction.

---

## §8 Customer-Provided Inputs

Three stable subsections in this order: **Content & data**, **Access & credentials**, **People & process**.

| Check | What good looks like |
|---|---|
| Each subsection has at least one bullet | If a subsection is genuinely empty, write "None." explicitly so it's clear nothing was missed. |
| Content/data items specify format and (where relevant) quantity | "Owner manuals (PDF)", "Golden Dataset (≥30 items: User Request, Operations, Ticket Classification, Ideal Response)" — not just "manuals" or "dataset". |
| Access items specify what permissions are needed | Not just "AWS access" — "AWS account access and IAM permissions sufficient for Terraform-managed provisioning." |
| People & process items name the cadence | "Weekly sync availability" is good. "Their participation" is vague. |

**Reject when:**
- A bullet is "the customer will provide what's needed" — interrogate for specifics.
- The list is missing items the spec depends on (e.g. spec uses HubSpot but no HubSpot key in customer-provided inputs).

---

## Cross-Section Consistency Checks

After all sections are drafted, run these:

| Check | Action if it fails |
|---|---|
| Every AI KPI in §2 references data the customer is providing in §8 | Add the missing input to §8 or relax the KPI. |
| Every external integration in §4 has its credentials/access listed in §8 | Add to §8. |
| Every architecture component in §5 has at least one requirement in §4 | Either remove from architecture or add the missing requirement. |
| Every "out of scope" item in §7 is NOT also in §4 as a requirement | Remove the contradiction. |
| Every assumption in §6 about customer behavior has a matching item in §8 | If we assume the customer does X, X should be in their delivery list. |
| The case.md's stated impact aligns with §2 KPIs | If case.md says "deflect tickets" and §2 has no deflection KPI, ask why. |

These cross-section checks catch the most damaging spec defects — the kind that surface in dev kickoff and force scope renegotiation.
