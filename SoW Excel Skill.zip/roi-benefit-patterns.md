# ROI Benefit Interview Patterns

The ROI Calculator's Section 2 (Annual Benefits) is the most interactive part of SoW generation. PMs typically struggle with this because they don't have firm numbers — but a rough, defensible estimate is better than nothing.

## How to run the interview

1. **Read case.md and discovery-spec.md §1 first.** The business context names what value the project delivers. That tells you which benefit categories apply.
2. **Present 4-5 candidate categories** (from the patterns below) that fit the project. Don't dump all 10 — narrow to what's relevant.
3. **For each candidate the PM agrees on, gather:** the assumption, the calculation, the resulting annual saving in dollars.
4. **Max 5 benefits.** The template's Section 2 has rows for B1-B5 only.
5. **If the PM has no data:** encourage conservative estimates ("a conservative number is better than no number — it's the client's reality check, not a guarantee"). If they refuse all, leave benefits empty.

## Common benefit patterns for AI+SW products

### Pattern 1: Ticket / case deflection
The AI handles cases that previously required a human, reducing variable cost per case.

- **Inputs to ask for:** Current monthly case volume, cost per case (agent time + tooling), target deflection rate.
- **Calculation:** `monthly_cases × 12 × deflection_rate × cost_per_case`
- **Example assumption:** *"30% of current 1000 monthly tickets handled by chatbot at $5 saved per deflected ticket"*
- **Example math:** `1000 × 12 × 0.30 × $5 = $18,000/yr`
- **Applies to:** support chatbots, classification bots, triage agents.

### Pattern 2: Agent capacity redirection
Human time freed up by AI is redeployed to higher-value work.

- **Inputs:** Number of FTEs freed (or fraction), fully-loaded annual cost per FTE.
- **Calculation:** `freed_FTEs × annual_cost_per_FTE`
- **Example assumption:** *"0.5 FTE of agent time freed, valued at $50,000/yr fully-loaded"*
- **Example math:** `0.5 × $50,000 = $25,000/yr`
- **Applies to:** support automation, content drafting tools, internal copilots.

### Pattern 3: Response time / resolution time improvement
Faster service translates to retention, conversion, or customer satisfaction in dollar terms.

- **Inputs:** Current avg response time, target response time, monetary value of the improvement.
- **Calculation:** Often imprecise — the PM has to assign a value (e.g. $X retention saved per hour faster, or % conversion lift × revenue).
- **Example assumption:** *"Reduced wait time improves rider satisfaction; estimated $5,000/yr in retention value"*
- **Applies to:** anything customer-facing.

### Pattern 4: Consistency / accuracy improvement
AI's consistent output reduces error costs (refunds, escalations, rework).

- **Inputs:** Current error rate, current error cost, expected error rate reduction.
- **Calculation:** `current_volume × error_rate_reduction × error_cost`
- **Example assumption:** *"Reduce 5% misclassification rate to 1% across 10K tickets/yr at $20 rework cost"*
- **Example math:** `10000 × 0.04 × $20 = $8,000/yr`
- **Applies to:** classification, data entry automation, content review.

### Pattern 5: 24/7 availability
Service hours expand without proportional staffing cost.

- **Inputs:** Current service-hours/week, expected after-hours volume served by AI.
- **Calculation:** `additional_hours_served × value_per_hour_served`
- **Example assumption:** *"After-hours chat (16 hrs/day not currently staffed) serves 100 cases/month at $5 case value"*
- **Example math:** `100 × 12 × $5 = $6,000/yr`
- **Applies to:** any customer-facing product where current service has limited hours.

### Pattern 6: Scalability without proportional cost
Product handles growing volume without hiring proportionally.

- **Inputs:** Projected volume growth, current cost-per-unit, AI's cost-per-unit.
- **Calculation:** `(projected_volume - current_volume) × (current_cost - AI_cost)`
- **Example assumption:** *"50% volume growth handled without hiring; saved hiring of 2 FTEs at $80K"*
- **Example math:** `2 × $80,000 = $160,000/yr`
- **Applies to:** growth-stage products.

### Pattern 7: Compliance / audit cost reduction
AI produces audit-friendly artifacts (logs, ticket trails) that reduce manual compliance overhead.

- **Inputs:** Current audit cost, expected reduction.
- **Example assumption:** *"Structured ticket capture reduces annual audit-prep effort by 40 hours at $150/hr"*
- **Example math:** `40 × $150 = $6,000/yr`
- **Applies to:** regulated industries.

### Pattern 8: Onboarding / ramp time reduction
For internal copilots, faster onboarding of new employees.

- **Inputs:** Current ramp time, expected reduction, employee fully-loaded cost.
- **Applies to:** internal copilots and knowledge tools.

### Pattern 9: Lead conversion / revenue uplift
For products that affect sales funnel.

- **Inputs:** Current conversion rate, expected lift, revenue per conversion.
- **Calculation:** `traffic × conversion_lift × revenue_per_conversion`
- **Applies to:** customer-acquisition AI, recommendation systems.

### Pattern 10: Avoided cost of building manually
If the AI replaces a planned manual hire or build, the avoided cost is a benefit.

- **Inputs:** Cost of the alternative the AI is displacing.
- **Applies to:** when AI replaces a planned project / hire.

## What to push back on

- **"We can't measure that."** Push for an estimate. *"What would be a conservative number that you'd defend in front of the client? Underestimating is fine."*
- **"All five categories apply at $X each."** Probe for distinctness — overlapping categories double-count. E.g. "ticket deflection" and "agent capacity redirection" overlap; deflected tickets ARE the freed capacity. Pick one framing.
- **PM cites very large numbers casually.** Ask for the input assumptions. If they don't have them, suggest dropping a zero or two.
- **PM picks "Lead conversion" with no data.** This category is the most prone to inflation. If they pick it, anchor on a tight number (1-2% conversion lift, not 20%).

## Example interview output structure

After the interview, you should have an array like:

```json
[
  {
    "category": "Ticket deflection",
    "assumption": "30% of current 1000 monthly tickets handled by chatbot at $5 saved per ticket",
    "annual_saving": 18000,
    "calculation": "1000 × 12 × 0.30 × $5"
  },
  {
    "category": "Agent capacity redirection",
    "assumption": "0.5 FTE freed at $50K/yr fully-loaded",
    "annual_saving": 25000,
    "calculation": "0.5 × $50,000"
  }
]
```

This array is passed to the generator script in `inputs.json` and populates rows 19-23 of the ROI Calculator.
