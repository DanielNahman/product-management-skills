# Role Mapping (LoE Summary ↔ Rate Card)

The LoE summary table uses role names that don't exactly match the rate card's role names. The generator script applies this mapping automatically; this file documents it for maintenance.

## Mapping table

| LoE summary role | Rate card role (both IL and Global sheets) |
|---|---|
| AI Developer | Architect/ Data Expert/ Team Lead / AI Developer |
| Frontend Developer | Software Developer |
| Backend Developer | Software Developer |
| DevOps | IT/Cloud engineer/Dev-Ops |
| QA | QA Engineer |
| Designer | Graphic Designer or UI/UX Expert |
| Product Manager | Product/Project Manager |
| Project Manager | Product/Project Manager |
| TL | Architect/ Data Expert/ Team Lead / AI Developer |
| AI Architect | AI Expert / AI Architect |
| SW Architect | Architect/ Data Expert/ Team Lead / AI Developer |

## Notes

- **AI Validation** is a separate role in the Global rate card (`AI validation `) but NOT in the IL rate card. For IL projects, the AI Validation column in ROI may be left blank or use the Product Manager rate as a proxy. The generator script handles this gracefully (leaves blank if no match found).
- The rate card's "Off-shore Software Developer" is NOT mapped — Commit uses on-shore developers by default. If an off-shore mix is needed, an architect adjusts the rate manually in the LoE summary.
- The "Commit AI CTO" and "AI R&D Transformation lead" rows in the IL rate card are special-purpose and don't appear in the LoE summary.

## What to update if the rate card changes

If Commit ops adds/renames roles in the rate card:

1. Update `ROLE_TO_RATECARD` dict at the top of `generate_sow.py`.
2. If a new LoE role is added to the template, update the `role_order` list in `_build_summary_table()` and add it to the mapping above.
3. Re-test against a known project to confirm rates flow correctly.
