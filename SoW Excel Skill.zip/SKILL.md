---
name: sow-excel-generator-skill
description: Use when a Commit product manager has a signed AI+SW discovery spec and needs to produce the SoW Excel that goes to the client and to the architects for effort estimation. Triggers on requests like "generate the SoW", "create the SoW excel from the spec", "make the SoW", "build the SoW from this discovery spec", or after a discovery spec hits status signed and the PM is ready to estimate effort. Refuses to run if the discovery spec is unsigned. Requires a rate card file in the project directory.
---

# SoW Excel Generator Skill

## Overview

You convert a **signed** discovery-spec.md into the SoW Excel file that:
- Goes to the **client** for signature (contains scope, success criteria, NFRs, assumptions, DoD).
- Goes to the **architects** (AI architect, SW architect, DevOps) for effort estimation. Architects fill in the Technical Task, Implementation Details, and Days columns themselves — **you do NOT fill those columns**.

The SoW is **less descriptive than the spec.** It's a structured estimation artifact, not a narrative.

**Your job:**
1. Gate-check: discovery spec exists AND is signed/locked, rate card available.
2. Read the spec and case.md.
3. Determine PoC vs MVP (read spec, confirm with PM).
4. Ask a small set of project-specific questions (IL/Global, dual env, AWS account, AWS Calculator).
5. Generate the DoD text and Mermaid diagrams from spec content.
6. Interview the PM on ROI benefits.
7. Build an inputs.json with all gathered data.
8. Run `generate_sow.py` to produce the SoW.xlsx.
9. Surface the file and any caveats.

---

## Hard Gates

Before any other action, check the working directory:

**1. `discovery-spec.md` must exist.** If missing:
> ```
> No discovery-spec.md found. The SoW is generated from a signed discovery spec.
> Use the ai-sw-discovery-spec-skill first, get the spec signed by the client,
> then come back here.
> ```

**2. `discovery-spec.md` frontmatter `status` must be `signed` or `locked`.** If `draft` or `in_review`:
> ```
> discovery-spec.md status is "<status>". The SoW is the contractual artifact —
> it can only be generated from a signed discovery spec. Get the spec to status
> "signed" (after client review and approval), then come back.
> ```

**3. Rate card file.** Check for `RateCard.xlsm`, `RateCard.xlsx`, or `rate_card.xlsx` in the working directory. If missing:
> ```
> No rate card found in this directory. The SoW summary table needs current rates
> to compute costs. Please place your rate card file (RateCard.xlsm or similar)
> in the project directory and run again.
> ```

**4. Existing `SoW.xlsx`.** If one already exists, ask:
> ```
> A SoW.xlsx already exists in this directory. Want me to:
> a) replace it (overwrite),
> b) version it (SoW-v2.xlsx),
> c) abort?
> ```

---

## Read Everything First

Before talking to the PM, read in this order:

1. `discovery-spec.md` — fully. Parse frontmatter, all 8 sections.
2. `case.md` — for business framing (used in DoD text and ROI guidance).
3. The bundled template at `<this-skill-folder>/template/SoW_Template.xlsx`.
4. The rate card file (already located).

Then build a parsed-spec data structure in memory:

```python
parsed_spec = {
  "client": <from frontmatter>,
  "project": <from frontmatter>,
  "epics": [
    {
      "id": <int>,
      "name": <Epic name>,
      "description": <epic description prose>,
      "user_story": <YOU generate this — see "Generating user stories" below>,
      "features": [
        {
          "id": <feature id e.g. "1.1">,
          "name": <feature name>,
          "description": <feature description prose, single paragraph>,
          "notes": <feature-level Notes line if present, else None>,
          "requirement_ids": [<list of requirement IDs under this feature>]
        }
      ]
    }
  ],
  "assumptions": [<each spec §6 bullet, verbatim>],
  "nfrs": [{"category": ..., "requirement": ...}],   # spec §3 rows
  "kpis": [{"kpi": ..., "target": ..., "measurement": ..., "type": ...}],  # spec §2 rows
  "architecture_services": [<list of AWS services mentioned in spec §5>]
}
```

### Generating per-epic user stories

The SoW has a "Detailed User Story" column merged across all features of an epic. The discovery spec doesn't have a per-epic user story — you generate one.

For each epic, write ONE user story (40-80 words) that summarizes what users do across all features in that epic. Form: *"As a <user type>, I want <capability> so I can <outcome>."*

Read the epic name, description, and feature descriptions to inform it. Example for Ryvid Epic 1 (Conversational Support Surface):

> *"As an authenticated Ryvid rider, I want to chat with an AI support agent on the Shopify site that lets me ask questions, attach images and videos of issues, and continue past conversations, so I can get help 24/7 without waiting for a human agent on simple questions."*

### Extracting architecture services

Read spec §5 Architecture (ASCII block or prose). Extract the AWS service names and major components. For Ryvid: `["S3", "Bedrock", "Bedrock Knowledge Base", "Lambda", "API Gateway", "DynamoDB", "CloudFront", "WAF", "ALB"]`. These are used in DevOps sheet descriptions.

---

## Pre-Interview Setup

Tell the PM what's about to happen, briefly:

> ```
> I've read the signed discovery spec for <project>. I'll now generate the SoW
> Excel. I need to ask a few project-specific questions, then I'll generate the
> Mermaid system flows and propose the DoD text and ROI benefits structure for
> your review.
>
> Architects fill in the Technical Task, Implementation Details, and Days columns
> after — I won't pre-fill those.
> ```

---

## Inputs to Gather (in this order, one question per message)

### 1. PoC or MVP

First look in `discovery-spec.md` and `case.md` for explicit markers ("PoC", "MVP", "Proof of Concept", "Minimum Viable Product"). The `sow_number` field is not a reliable signal.

If clearly indicated, confirm:
> "I see this is an MVP project (case.md title mentions MVP). Confirm to proceed."

If unclear, ask:
> ```
> Is this project a PoC (proof of concept) or an MVP (minimum viable product)?
> The DevOps sheet structure and effort differ significantly between these.
> ```

### 2. IL or Global

> ```
> Is this an Israeli (IL) or Global project? This drives the rate card currency:
> IL = NIS rates (column B of Rate Card IL), Global = USD rates (column C of
> Rate Card Global).
> ```

### 3. (MVP only) Dual environment?

> ```
> Will the project deploy to a single production environment, or to both dev
> and prod environments? Two-env adds 50 hours of DevOps effort (rows 21-23 of
> the DevOps sheet).
> ```

### 4. (MVP only) New AWS account?

> ```
> Will you need to create a new AWS account for the customer (Landing Zone +
> Control Tower setup), or does the customer already have an AWS account
> provisioned for this work? Creating a new account adds 15 hours of DevOps
> effort.
> ```

### 5. AWS Calculator

> ```
> Do you have an AWS Pricing Calculator export with the projected annual
> consumption cost for this project?
>   - If yes: paste the total annual cost in USD (or attach the file path).
>   - If no: I'll proceed with a placeholder ($1000). Note that you should
>     create an AWS Calculator estimate before sending the SoW to the client —
>     it's expected in the ROI section.
> ```

### 6. Application Type / User Type

Default both. Only ask if the PM's context suggests otherwise:
> ```
> The LoE sheet labels each row with Application Type and User Type. I'll
> default to "Web App" + "End User" unless you tell me otherwise. Want to
> override (e.g. "Mobile App", "BO Admin")?
> ```

---

## Generating the DoD Text

After gathering inputs, draft the Definition of Done. 1-2 paragraphs, concise.

For an MVP, the DoD should cover:
- Production deployment to the target AWS environment.
- All KPIs from spec §2 met against the agreed dataset (cite specifically).
- Key feature flows working end-to-end (cite the top-level epics from spec §4).
- Critical integrations confirmed (cite the external systems in spec §5 architecture).
- Infrastructure provisioned and observability in place.
- NFRs satisfied (cite the key ones from spec §3).

For a PoC, the DoD is shorter — the agent passes the success criteria against the golden dataset, demo UI works, evaluation results documented.

Show the draft to the PM for review before finalizing.

---

## Generating the Mermaid Diagrams

Generate 2-4 Mermaid diagrams from spec context. Common useful ones:

1. **Main happy-path sequence diagram** — user interaction through the system. Use `sequenceDiagram`.
2. **Agent decision flowchart** — if the project has AI classification or branching logic. Use `flowchart TD`.
3. **External integration sequence** — for projects with vendor integrations (HubSpot, Salesforce, etc.).

Use exact Mermaid syntax. The diagrams are stored as text in the System Flows sheet — they don't render in Excel, but architects/clients can paste them into a Mermaid renderer (mermaid.live, GitHub, Notion).

Show the diagrams to the PM for review before finalizing.

---

## ROI Benefits Interview

The ROI Calculator sheet's Section 2 (Annual Benefits) is the interactive part. Walk the PM through it.

Read `roi-benefit-patterns.md` for the full guidance. In short: present 4-6 common benefit categories for AI+SW products, ask the PM which apply, and gather the assumptions for each.

For each benefit (max 5):
- **Category**: short name (e.g. "Ticket deflection", "Agent capacity redirection").
- **Assumption**: the assumption the calculation rests on (e.g. "30% of current 1000 monthly tickets handled by chatbot at $5 saved per deflected ticket").
- **Annual saving**: the dollar number.
- **Calculation**: the math behind it (e.g. "1000 * 12 * 0.3 * $5 = $18,000").

If the PM doesn't have data for a benefit, encourage them to make a conservative estimate (it's the client's reality check, not a guarantee). If they refuse all categories, leave the benefits empty — the ROI ratio will be 0 but the formula machinery stays intact.

---

## Building the inputs.json

Once all data is gathered, write it to a temporary `inputs.json` file in `/tmp` (or the project directory) and pass it to the generator script.

Structure:
```json
{
  "spec_path": "...",
  "case_path": "...",
  "template_path": "<bundled in skill folder>",
  "rate_card_path": "...",
  "output_path": "./SoW.xlsx",
  "project_type": "mvp" or "poc",
  "location": "il" or "global",
  "dual_env": true/false,
  "new_aws_account": true/false,
  "aws_calculator_annual_cost": number or null,
  "application_type": "Web App",
  "user_type": "End User",
  "parsed_spec": { ... full parsed spec ... },
  "dod_text": "...",
  "mermaid_diagrams": [...],
  "roi_benefits": [...]
}
```

---

## Running the Generator

Execute:
```bash
python3 <skill-folder>/generate_sow.py /tmp/inputs.json
```

The script:
- Copies the bundled template to `./SoW.xlsx`.
- Modifies sheets per the inputs.
- Preserves template styling throughout.
- Renames the LoE sheet to "PoC LoE" or "MVP LoE".
- Deletes the unused DevOps sheet.
- Applies rate card values to the LoE summary table and ROI calculator.
- Returns "OK: wrote <path>" on success.

If the script errors, surface the error to the PM with context.

---

## After Generation

1. Verify the file exists at `./SoW.xlsx`.
2. Call `present_files` to show it to the PM.
3. Summarize what was generated and any caveats:
   - "Architects need to fill in Technical Task, Implementation Details, and Days columns in the LoE sheet."
   - "If you didn't supply an AWS Calculator export, the Yearly Consumption Cost in ROI is a placeholder ($1000). Update before sending to client."
   - "The System Flows sheet contains Mermaid text — paste into mermaid.live or a Mermaid renderer to view."
   - "The Cloud Architecture sheet is empty by design — architect/SA fills this."

---

## What This Skill Does NOT Do

- ❌ Generate the discovery spec — that's `ai-sw-discovery-spec-skill`.
- ❌ Generate the dev spec — that's `ai-sw-dev-spec-skill`.
- ❌ Fill in days/effort estimates — architects do this manually after.
- ❌ Generate Jira tickets — separate future skill.
- ❌ Modify the discovery spec — discovery is locked at signature.
- ❌ Draw the cloud architecture diagram — architect's deliverable.
- ❌ Generate the AWS Pricing Calculator export — PM does this separately in AWS console.

If the PM asks for any of these, point them to the right skill or note it's outside this skill's scope.

---

## Common PM Mistakes to Watch For

| Mistake | What to do |
|---|---|
| PM runs this skill before the spec is signed | Hard gate fails — refuse and explain. |
| PM wants to fill in effort estimates here | Redirect — those go in the SoW after architect review. The PM doesn't estimate. |
| PM forgets the AWS Calculator | Surface as a caveat after generation; note in the SoW the ROI placeholder must be updated. |
| PM picks "Global" but the team is in Israel | Confirm — "Global" means SoW is in USD; doesn't mean the team. IL is for projects billed in NIS. |
| PM wants to skip the ROI interview | Acceptable — leave benefits empty. The sheet's formulas still work; output ROI ratio will be 0:something. |
| PM wants to add features to the SoW that aren't in the spec | Stop. Either trigger a change order to the discovery spec, or remove from SoW. The SoW must reflect signed scope exactly. |
| PM wants the SoW in a different template format | This skill produces only the Commit-standard template. If a different format is needed, the PM does it manually. |

---

## Reference Files in This Skill

- `template/SoW_Template.xlsx` — bundled canonical template. Don't modify; the script copies it.
- `generate_sow.py` — the generation script. SKILL.md tells you when to run it; the script does the file work.
- `role-mapping.md` — LoE summary roles ↔ rate card roles mapping. Reference if the rate card structure changes.
- `roi-benefit-patterns.md` — guidance on running the ROI benefits interview.
- `mermaid-flow-patterns.md` — examples of good system flow diagrams to model from.
