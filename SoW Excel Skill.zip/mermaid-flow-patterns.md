# Mermaid Flow Patterns for the System Flows Sheet

Generate 2-4 Mermaid diagrams from the spec's architecture and key flows. These are stored as text in the System Flows sheet — they don't render in Excel itself, but architects and clients can paste them into mermaid.live or any Markdown renderer.

## Guidelines

- **One concern per diagram.** Don't try to show everything in one. Better: 3 focused diagrams than 1 sprawling one.
- **Use real component names.** Pull from spec §5 architecture — not generic placeholders.
- **Keep it conceptual.** No IAM details, no VPC subnets — that's developer territory.
- **Show data flow, not internal logic.** Components send messages; what they do internally is a black box.

## Pattern 1: Main happy-path sequence diagram

The most important diagram. Shows the user's primary interaction through the system from start to end.

Use `sequenceDiagram`. Include:
- The user actor at top.
- Each major component (UI, API, business logic, AI, storage, external integrations).
- Numbered messages with descriptive labels.

Example (Ryvid):
```mermaid
sequenceDiagram
  actor User as Rider (Shopify auth)
  participant UI as Chatbot UI
  participant API as API Gateway
  participant Lambda as Chatbot Lambda
  participant Agent as AI Lambda (Bedrock)
  participant KB as Bedrock KB
  User->>UI: Type message, optionally attach media
  UI->>API: POST /chat/messages
  API->>Lambda: Forward request
  Lambda->>Agent: generateResponse(history, msg, media)
  Agent->>KB: Retrieve relevant passages
  KB-->>Agent: Top 5 passages
  Agent->>Agent: Classify simple/complex
  Agent-->>Lambda: response + classification
  Lambda-->>UI: assistantResponse
  UI-->>User: Display message bubble
```

## Pattern 2: Decision flowchart

When the system has branching logic — classification, safety rules, routing — show it as a flowchart.

Use `flowchart TD` (top-down) for vertical or `flowchart LR` (left-right) for wide flows.

Example (Ryvid safety + classification):
```mermaid
flowchart TD
  A[User message arrives] --> B{Safety trigger?<br/>fire/smoke/crash/electrical}
  B -->|Yes| C[Escalate to Complex<br/>+ safety disclaimer<br/>+ suppress DIY advice]
  B -->|No| D[Retrieve KB passages]
  D --> E{Classification}
  E -->|Simple| F[Generate grounded answer]
  E -->|Complex| G[Enter diagnostic mode]
  G --> H[Ask 4-5 diagnostic questions]
  H --> I[Emit JSON ticket]
  I --> J[Write to S3 → HubSpot]
  C --> I
```

## Pattern 3: Integration sequence

For external integrations — vendor APIs, CRMs, payment systems — show the asynchronous handoff.

Example (Ryvid → HubSpot):
```mermaid
sequenceDiagram
  participant Agent as AI Lambda
  participant S3 as S3 (tickets)
  participant Integ as HubSpot Integration Lambda
  participant HS as HubSpot CRM
  Agent->>S3: Write JSON ticket
  S3->>Integ: S3 event trigger
  Integ->>Integ: Transform JSON to HubSpot schema
  Integ->>HS: createTicket via Tickets API
  HS-->>Integ: ticket ID
  Note over Integ: Unidirectional only — no read-back
```

## Pattern 4: Memory / state flow (optional)

For projects with conversation memory, session state, or cross-session continuity.

```mermaid
sequenceDiagram
  participant Agent
  participant ShortTerm as Short-term context<br/>(last 10 turns)
  participant LongTerm as Long-term memory<br/>(user prefs, facts)
  Agent->>ShortTerm: Read current thread (10 turns)
  Agent->>LongTerm: Read user context
  Agent->>Agent: Generate response with combined context
  Agent->>LongTerm: Write durable facts (if any)
```

## Pattern 5: Component diagram (use sparingly)

Some specs benefit from a high-level component overview. Use `graph LR` or `graph TB`.

```mermaid
graph TB
  subgraph "Shopify"
    UI[Chatbot UI]
  end
  subgraph "AWS"
    API[API Gateway]
    L1[Chatbot Lambda]
    L2[AI Lambda]
    L3[HubSpot Integ Lambda]
    S3[(S3)]
    KB[(Bedrock KB)]
    DDB[(DynamoDB)]
  end
  subgraph "External"
    HS[HubSpot CRM]
  end
  UI --> API --> L1
  L1 --> L2 --> KB
  L1 --> DDB
  L2 --> S3 --> L3 --> HS
```

## What NOT to do

- **Don't include implementation details.** No IAM policies, no VPC structure, no security group rules.
- **Don't draw deployment topology.** That belongs in Cloud Architecture (which we leave empty for the SA).
- **Don't include things not in the spec.** If the spec says nothing about caching, don't add a cache to your diagram.
- **Don't number diagrams "Diagram 1, Diagram 2".** Give them descriptive labels: "Happy path", "Triage logic", "HubSpot handoff".

## How many diagrams?

- Minimum **2**: happy-path sequence + one branching flowchart OR integration sequence.
- Typical **3**: happy path + decision flowchart + integration sequence.
- Maximum **4**: add a memory/state or component overview only if the spec is complex enough to warrant it.

More than 4 is over-engineering for a SoW — the SoW is a contract artifact, not architecture documentation.
