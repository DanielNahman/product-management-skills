# Feature Splitting Guide

A feature in dev-spec §4 produces **one ticket** in most cases. Sometimes a feature has multiple distinct customer-value flows and needs to be split into 2-4 tickets. This guide tells you when and how.

---

## The default: one feature, one ticket

Most features cleanly map to one ticket. If a feature has 2-6 SW stories that all describe one user flow, **one ticket is the right answer.**

Examples that stayed as one ticket:
- "Chatbot Page on Shopify" (4 reqs, ~14 stories, all describing rendering the chat page) → one ticket. All stories serve one flow: rendering the chatbot interface.
- "Media Uploads" (4 reqs, ~10 stories) → one ticket. All stories serve one flow: attaching media to a chat.
- "Conversation History" (3 reqs, ~9 stories) → one ticket. One flow: browse and resume past threads.

---

## When to split

Split a feature into multiple tickets when **any** of these apply:

### Signal 1: ≥7 SW stories total
With 7+ stories, the ticket is too big to be independently testable in one slice. Look for natural breakpoints.

### Signal 2: Sequential lifecycle stages
The feature spans distinct lifecycle moments (start → middle → end) that each represent independent customer value.

Example: "Automation wizard" covers launch → name → configure goal → configure tone → configure rules → preview → publish. That's 6+ stages. The user gets value at each stage (e.g. after "configure goal" they have a working draft, even if they pause). Split along lifecycle boundaries.

### Signal 3: Disjoint surfaces
The feature touches multiple unconnected UI surfaces or screens that don't share state.

Example: "Knowledge Base management" has stories about a list view, an upload modal, an edit modal, and a delete flow. These are visually and temporally disjoint. Split into separate tickets.

### Signal 4: Multiple distinct customer outcomes
The feature delivers multiple separate outcomes that a user could realistically use independently.

Example: "Creator Configuration Flow" might have stories for "configure language", "configure tone", and "configure frustration threshold". A user could plausibly want to configure just one of these. Each is independent customer value.

---

## When NOT to split

Don't split when:

### Stories form one cohesive flow even if numerous
If 8 stories all describe one continuous user action (e.g. "user authenticates → lands on page → sees content → can scroll → can search → can refresh"), that's still one flow. Don't slice mid-flow.

### Splitting would create a ticket with <2 stories
A 1-story ticket is too small. Better to keep the feature whole, or merge that story with an adjacent ticket.

### Stories are tightly coupled
If story B literally cannot work without story A (e.g. "click button" before "see modal open"), they belong in the same ticket. Coupled stories should not be split unless one delivers value on its own (which they don't, by definition).

### The "split" is just by component
"FE story + BE story + DB story" is not a customer-value split — it's an implementation split. Don't split by tech layer; split by user-visible flow.

---

## How to identify split boundaries

Once you've decided to split, find the right cut lines. Use these techniques:

### Technique 1: Group by user lifecycle moment
List the stories in temporal order from the user's perspective. Look for natural pauses — places where the user could stop and the work-so-far would still be useful.

Example for Automation wizard:
- (moment 1) launch wizard, name automation, select trigger post
- (moment 2) configure goal + tone + rules + frustration threshold
- (moment 3) preview the agent against test inputs
- (moment 4) publish to production

Each moment is an independently-valuable cut.

### Technique 2: Group by surface
List the stories by UI surface they affect. Stories on the same surface go together.

Example for Knowledge Base management:
- (surface A) Library view (list of sources)
- (surface B) Upload modal (add new source)
- (surface C) Edit modal (modify existing source)
- (surface D) Inline list actions (delete, rename)

Each surface = one ticket.

### Technique 3: Group by outcome
List the customer outcomes the feature enables. Each outcome with its supporting stories = one ticket.

Example for Creator Configuration:
- (outcome A) Creator can pick the AI's language for responses
- (outcome B) Creator can pick the AI's tone
- (outcome C) Creator can set the AI's frustration threshold

Each outcome = one ticket.

---

## Naming split tickets

When a feature splits into multiple tickets, name each ticket by **what the user can do** after this ticket, not by which slice of the feature it covers.

**Good naming (lifecycle split of Automation wizard):**
- TICK-101: Creator launches automation wizard and selects a trigger post
- TICK-102: Creator configures automation goal, tone, and rules
- TICK-103: Creator previews automation against test inputs
- TICK-104: Creator publishes the automation

**Bad naming (just labels the slice):**
- TICK-101: Automation wizard part 1
- TICK-102: Automation wizard part 2
- TICK-103: Automation wizard part 3
- TICK-104: Automation wizard part 4

---

## Distributing the feature description and background

When a feature splits, each ticket needs its own User Story and Background. Both should:
- Use the parent feature's epic-level user-story as the role/persona source.
- Frame the user story around what *this ticket's* slice enables.
- Background can reference the broader feature and note "this is part of <N> tickets covering <feature>" if helpful.

Example (Automation wizard, split):

**TICK-101 (launch + name + select post):**
> **User story:** As a Linkme creator, I want to start configuring a new AI automation by naming it and picking which post triggers it, so I have a working draft I can come back to.
> **Background:** Automations are how creators put their AI to work — without an automation, the AI does nothing. This ticket delivers the first slice of the wizard so creators can begin configuring. Part of 4 tickets covering the Automation Wizard feature.

**TICK-102 (configure goal, tone, rules):**
> **User story:** As a Linkme creator with a draft automation, I want to configure the AI's goal, tone, and response rules, so the AI behaves the way I want for this campaign.
> **Background:** Goal, tone, and rules are what differentiate one creator's AI from another's — this is where the personalization happens. Without these knobs, every creator gets the same generic agent. Part of 4 tickets covering the Automation Wizard feature.

---

## Edge cases

### Feature has 0 SW stories (all AI)
Skip the feature entirely. No ticket. AI stories will be picked up by the eval-md skill (future). Note in the feature plan summary: "Feature X.Y skipped — all stories AI-typed."

### Feature has exactly 1 SW story
Look for an adjacent feature in the same epic to merge with. Two questions:
- Does adjacent feature serve a related customer outcome? If yes, merge.
- If no clear adjacent fit, keep as a single-story ticket but flag to PM during review — they may want to drop it or merge differently.

### Feature has 20+ stories
Probably an over-broad feature in the dev spec. Split into 3-5 tickets along the cleanest boundaries. Also flag to PM that the feature definition might need tightening in a future dev-spec revision.

### Feature splits don't fit into 2-6 stories each
If the natural splits leave one ticket with 1 story and another with 8, the split-line is wrong. Look for another cut. If you can't find a clean cut, present both options to the PM and ask which they prefer.

---

## Summary checklist

Before deciding on a split, verify:
- [ ] The feature has ≥7 SW stories OR exhibits Signal 2/3/4.
- [ ] Each proposed ticket delivers independent customer value.
- [ ] Each proposed ticket has 2-6 stories.
- [ ] Stories within a ticket are tightly enough coupled that splitting them further would create context-loss.
- [ ] Each proposed ticket is independently testable (perhaps after its dependencies are met).
- [ ] Each ticket name describes a customer outcome, not a slice label.

If any of the above fails, reconsider the split.
