# Implicit Scenarios Library

Dev specs are rarely complete. They capture the requirements that came up in discovery and dev-spec interviews, but they often miss **implicit scenarios** that a senior PM would catch from product judgment.

This library lists common implicit scenarios by feature type. During ticket review, the skill should surface these to the PM with the question: *"based on this feature, here are 2-3 scenarios I think are likely-but-not-in-the-spec. Want to add any to the flows?"*

The PM accepts, edits, or rejects each. The skill never adds them silently — they're surfaced for PM judgment.

---

## How to use this library

For each ticket being drafted:

1. **Identify the feature type** — does this ticket involve a form, a list, an upload, an in-flight action, etc.?
2. **Look up the relevant patterns** below.
3. **For each pattern: is it already covered in the dev spec's stories?**
   - If yes — already included in the ticket, no need to surface.
   - If no — surface to the PM during ticket review.
4. **Present the surfaced items** as candidate additions, not as required scope:
   > ```
   > A few implicit scenarios I'd flag for this ticket — none of these are in the
   > dev spec, but they're common in features like this. Want any added to the flows?
   >   - Drafts per conversation (unsent input persists when switching threads)
   >   - Mid-stream interaction (what if the user switches while a reply is streaming)
   >   - Scroll position on return (where does the view land when reopening)
   > ```

---

## Pattern library by feature type

### Forms and input fields

Any feature where the user types into an input.

- **Drafts persist when navigating away** — if the user types but doesn't submit, then navigates elsewhere, the draft should reappear when they return. Common gap in dev specs.
- **Drafts persist per context** — if there are multiple instances (multiple chats, multiple forms), each has its own draft.
- **Inline validation timing** — does validation fire on blur, on every keystroke, on submit? Often unspecified.
- **Submit while empty** — should submit be disabled, or should it run and show validation? Often unspecified.
- **Submit while in-flight** — can the user re-submit while the first request is processing? Usually should be blocked.
- **Paste behavior** — does pasting trigger validation immediately or only on next keystroke?

### Lists, sidebars, and paginated content

Any feature that displays a collection of items.

- **Empty state** — what does the user see when zero items exist? (Usually called out in dev specs.)
- **Loading state** — what shows while the initial list is fetching? Skeletons, spinners, blank?
- **Stale data on revisit** — when the user returns to a list they viewed before, does it refresh or show cached state?
- **Items added/removed by other tabs or sessions** — should the list update live, or only on next reload?
- **Scroll position on revisit** — when reopening, does the scroll position restore or reset to top?
- **Active item highlighting** — visual indicator of which item is "current" (if applicable).
- **List item changes while it's the active item** — what if the active row gets renamed/deleted by another action?

### Streaming responses or in-flight operations

Any feature with async behavior the user can wait on (uploads, AI responses, long server operations).

- **Interruption while in-flight** — what if the user navigates away mid-stream? Does the operation continue or cancel?
- **Switching contexts while in-flight** — what if the user switches to another item while one is mid-stream? Does the stream continue in the background?
- **Failure during stream** — partial response received, then connection drops. What does the user see?
- **Multiple in-flight at once** — can the user start a second operation while the first is mid-stream?
- **Stream timeout** — how long until the system gives up on a stuck stream?
- **Return to view mid-stream** — if the user returns to a context with a stream still running, what state is shown?

### Authentication-gated features

Any feature behind an auth gate.

- **Session expiry mid-action** — what happens if the JWT expires while the user is in the middle of something? (Re-auth flow, draft preservation, etc.)
- **Concurrent session conflict** — what if the user is signed in on two devices/tabs and one signs out? (Usually unspecified, but matters for security UX.)
- **Permission changes mid-session** — what if the user's role/permissions change while they're using the feature?

### File uploads and media

Any feature accepting user-uploaded content.

- **Cancel mid-upload** — can the user cancel partway through? What state does the cancel leave behind?
- **Drag-drop in addition to file picker** — common UX expectation often unspecified.
- **Paste image from clipboard** — same.
- **Multiple files selected at once** — most upload UX limits to one at a time, but the file picker may allow multi-select. What happens if user picks 3?
- **File picker dismissed without selection** — no error, just no change.
- **Preview before upload completes** — does the user see a thumbnail before the upload finishes, or only after?

### Search and filter

Any feature with search input over a collection.

- **Debounce timing** — when does the search fire? Every keystroke, after N milliseconds idle, on Enter?
- **Search with active selection** — if the user has an item selected and search filters it out, does the selection persist or clear?
- **Clear search re-shows full list** — usually called out, but sometimes missed.
- **Search query in URL** — can the user share or bookmark a search? (Often a "later" feature, but worth flagging as out-of-scope explicitly.)
- **Case sensitivity** — is search case-insensitive? Diacritic-insensitive? Common gap.

### Multi-step flows (wizards)

Any feature where the user walks through sequential steps.

- **Back navigation preserves state** — going back doesn't reset entered values.
- **Forward navigation requires valid current step** — can't proceed if validation fails.
- **Abandoning mid-wizard** — what if the user closes the wizard halfway through? Drafts? Discard prompt?
- **Resuming an abandoned wizard** — does next entry start from beginning or from where they left off?
- **Step skipping** — can the user jump to any step or only the next/previous?

### Notification or alerting features

Any feature that displays alerts, toasts, or notification badges.

- **Stacking** — what happens if multiple notifications fire in quick succession? Stack, replace, queue?
- **Dismiss persistence** — once dismissed, does it stay dismissed across sessions?
- **Notification visibility while user is in another context** — does the user see it immediately or on next visit?

### Real-time / WebSocket features

Any feature with live updates.

- **Reconnection behavior** — what happens if the connection drops? Auto-reconnect, prompt, silent?
- **Stale state on reconnect** — does the client re-sync, or trust local state?
- **Multiple tabs / sessions** — do updates propagate to all open tabs, or only the active one?

### Data modification (create, rename, delete)

Any feature that mutates persistent state.

- **Optimistic vs server-confirmed updates** — does the UI update before or after the server confirms?
- **Conflict resolution** — what if two clients edit the same item simultaneously?
- **Undo / soft-delete** — can the user reverse the action? For how long?
- **Cascading effects** — if the modified item is referenced elsewhere, what happens to the references?

### Mobile-specific implicit scenarios (always check for UI tickets)

- **Mobile keyboard interaction** — input area must stay visible above the on-screen keyboard.
- **Pull-to-refresh** — common mobile expectation. Often unspecified.
- **Long-press gestures** — common for context menus on mobile.
- **Network conditions** — features behave gracefully on flaky / 3G connections.
- **Background-to-foreground transition** — what happens when the user returns to the app after the OS backgrounded it?

---

## What the skill says to the PM during review

After drafting a ticket but before saving, the skill checks this library against the ticket's feature type and presents up to 5 implicit scenarios that:
- Are NOT already covered in the ticket's flows
- ARE relevant to this ticket's feature type

The presentation is non-prescriptive:

> ```
> A few implicit scenarios I noticed aren't in your dev spec — common in
> features like this. Each is optional. Tell me which to add as flows:
>
> A) Drafts per conversation (unsent input persists when switching threads)
>    → would add Flow N "Resume conversation with preserved draft"
>
> B) Mid-stream switch (user switches threads while a reply is streaming)
>    → would add Flow N "Switch while a reply is mid-stream"
>
> C) Scroll position on revisit (returning to a thread lands at most-recent message)
>    → would extend Flow 1's step list
>
> D) Sidebar updates when other tabs change something (live refresh vs reload-only)
>    → would add a cross-cutting baseline "Live updates: ..."
>
> Reply with letters (e.g. "add A and C, skip B and D") or "skip all" if none apply.
> ```

The PM picks which to fold in. The skill applies them. The dev spec may also be updated by the PM as a follow-up (flagged as a dev-spec quality issue).

---

## Discipline

- **Never add implicit scenarios silently.** They go through PM review.
- **Don't surface more than 5 per ticket.** Too many becomes noise.
- **Prioritize the ones most likely to bite in production** (mid-stream behavior, draft persistence, error recovery) over polish ones (scroll position, debounce timing).
- **If the PM rejects a pattern repeatedly, learn.** If the PM keeps saying "no drafts," stop suggesting drafts on similar features.
- **Surface clearly that these are NOT in the dev spec.** This protects against scope creep — the PM knows they're adding net-new scope, and may want to update the dev spec too.
