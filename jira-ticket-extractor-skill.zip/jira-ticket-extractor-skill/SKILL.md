---
name: jira-ticket-extractor-skill
description: Use when a Commit product manager has a finalized dev spec and needs to produce a jira-tickets.md file containing one ticket per independent customer-value flow — copy-pasteable into Jira. Triggers on requests like "create the Jira tickets", "extract tickets from the dev spec", "break the dev spec into tickets", "generate the Jira backlog", or when a PM uploads a dev-spec.md and asks for tickets. Refuses to run if the dev spec is missing or incomplete. Produces non-technical, testable tickets with traceability back to the dev spec.
---

# Jira Ticket Extractor Skill

## Overview

You convert a finalized `dev-spec.md` into a `jira-tickets.md` file — one ticket per independent customer-value flow. The PM copies tickets out of the MD into Jira manually (Jira API integration is a future enhancement).

**Your job:**
1. Gate-check that `dev-spec.md` exists and is reasonably complete (has §4 Scope with epics and features).
2. Walk every feature in dev-spec §4.
3. For each feature, decide whether to produce 1 ticket or split into multiple tickets based on flow coherence and story count.
4. Draft each ticket using the template in `ticket-template.md`.
5. Show each ticket to the PM, accept edits, save it to `jira-tickets.md`, move on.
6. After all tickets are drafted, detect dependencies heuristically and present them for PM confirmation.
7. Write the final `jira-tickets.md` and surface it.

**Key constraints:**
- Only `SW`-typed requirements/stories become tickets. AI-typed requirements go to the eval-md skill (future), NOT here. Mixed features produce SW-only tickets.
- Each ticket must be **testable** (acceptance criteria observable by QA).
- Each ticket must be **non-technical** in language (rephrase implementation vocabulary).
- Each ticket must deliver **independent customer value** (something a user can actually do at the end).
- Sequential IDs `TICK-001, TICK-002, ...` — traceability to dev spec via "Traces to:" line.

---

## Hard Gates

Before any other action, check the working directory:

**1. `dev-spec.md` must exist.** If missing:
> ```
> No dev-spec.md found in this directory. Tickets are generated from a finalized
> dev spec. Use the ai-sw-dev-spec-skill first to build dev-spec.md from the
> signed discovery spec, then come back here.
> ```

**2. dev-spec.md must have §4 Scope with at least one epic.** If §4 is empty or only has placeholder text:
> ```
> dev-spec.md exists but §4 Scope appears empty or incomplete. The skill walks
> §4's epic/feature/requirement tree to produce tickets. Complete §4 first.
> ```

**3. Existing `jira-tickets.md`.** If one already exists:
> ```
> A jira-tickets.md already exists in this directory. Want me to:
> a) replace it (overwrite),
> b) version it (jira-tickets-v2.md), or
> c) abort?
> ```

---

## Read Everything First

Before talking to the PM, read in this order:

1. `dev-spec.md` — fully. Parse frontmatter and all sections. Focus on §4 Scope (the tree), §1 Business Context (feeds Background sections), and §2 Reference to Discovery Spec (for the Out-of-Scope inheritance).
2. `discovery-spec.md` if linked — needed for inherited Out-of-Scope items referenced in §2.
3. `case.md` if present — feeds Background context.
4. The 4 reference files in this skill: `ticket-template.md`, `story-classification-guide.md`, `feature-splitting-guide.md`, `dependency-detection-guide.md`.

Then build a working plan: a list of (epic, feature, planned-ticket-count) for the whole spec.

---

## Pre-Interview Briefing

Before starting ticket-by-ticket review, give the PM an orientation:

> ```
> I've read your dev spec for <project>. Here's the plan:
>
> Total features in scope: <N>
> Features filtering to SW-only after dropping AI-typed reqs: <M>
> Estimated ticket count: <K> (some features will split into multiple tickets
> because they cover multiple distinct flows)
>
> I'll go through each feature one at a time. For each, I'll show you the
> ticket(s) I propose with their structure, you accept or edit, then I move on
> and save to jira-tickets.md as we go.
>
> After all tickets are drafted, I'll surface detected dependencies between
> them and ask you to confirm them before finalizing.
>
> Ready to start with Epic 1?
> ```

Wait for the PM's go-ahead. Then walk feature-by-feature.

---

## Per-Feature Workflow

For each feature in dev-spec §4 (in epic order, feature order within epic):

### Step 1: Determine ticket count

Read `feature-splitting-guide.md` for the full guide. In short:

- **Count SW-typed stories under this feature.** (Stories under requirements typed `SW`. AI-typed reqs and their stories are excluded.)
- **2-6 SW stories** → 1 ticket covering the whole feature.
- **≥7 SW stories** → split along flow boundaries (lifecycle stages, distinct surfaces, disjoint UX moments).
- **≤1 SW story** → merge into an adjacent feature ticket (or skip if no adjacent fit).
- **All stories are AI-typed** → no ticket from this feature (note in feature plan summary, skip).

If splitting: identify natural breakpoints in the story list. Each split should still represent **one independent customer-value flow** — a thing a user can do start-to-finish that delivers value.

### Step 2: Announce

> ```
> Feature <id>: <name>
> SW stories: <count> | AI stories (skipped, will go to eval): <count>
> Decision: <single ticket | split into N tickets along: flow1 / flow2 / flow3>
> ```

If the split is non-obvious, briefly explain your reasoning.

### Step 3: Draft the ticket(s)

For each ticket from this feature, use the template in `ticket-template.md`. Apply this drafting order:

**3a. Group stories into user journeys.** Before classifying stories into in-scope / error / edge, group them into the distinct user journeys this ticket needs to support. Each journey becomes a named flow in the Acceptance Criteria. See "Step 0" in `story-classification-guide.md`.

Typical ticket has 2-5 flows. Each flow is a named user journey (e.g. "Switch to a past conversation", "Switch while a reply is mid-stream", "Retry failed upload"). Flows force scenario thinking that flat AC lists miss.

**3b. Classify each story** into in-scope / error / edge using `story-classification-guide.md`.

**3c. Identify implicit scenarios.** Check `implicit-scenarios-library.md` for common implicit scenarios by this ticket's feature type. Pick up to 5 scenarios that are:
- NOT already covered in the ticket's flows
- ARE relevant to this ticket's feature type
- Most likely to matter in production

These will be surfaced to the PM in step 4 as candidate additions.

**3d. Draft each section** per the template:
- Title (customer-value focused, 6-10 words)
- Epic (verbatim from dev-spec §4)
- Traces to (feature ID + requirements covered)
- Depends on (leave blank — filled during the dependency-detection pass at the end)
- User story (one strict-format sentence)
- Background (2-3 strategic sentences, not tactical)
- In scope (one bullet per SW happy-path story, rephrased non-technical)
- Out of scope (sourced from dev-spec §2, feature Notes, adjacent deferrals — no cross-ticket refs in body)
- Acceptance criteria (Entry Point + 2-5 named flows + cross-cutting baselines like Responsiveness)
- Error handling (failure-path stories)
- Edge cases (boundary-condition stories)
- Related tickets (leave blank — filled at dependency-detection pass)

**3e. Show the drafted ticket(s) to the PM:**

> ```
> ── TICK-<NNN> ────
> [Full ticket per template]
> ────
>
> A few implicit scenarios I noticed aren't in your dev spec — common in
> features like this. Each is optional. Tell me which to add as flows:
>
> A) <implicit scenario 1>  → would add Flow N "<name>"
> B) <implicit scenario 2>  → would add a step to Flow X
> C) <implicit scenario 3>  → would add a cross-cutting baseline
>
> Then review the ticket and tell me what to change:
>   - accept as-is (and which implicit scenarios to add: e.g. "add A and C")
>   - edit a flow or section
>   - reword the user story or background
>   - move a story between in-scope / error / edge
>   - I missed a story / I should drop a story
> ```

### Step 4: Iterate with the PM

Apply edits. If multiple tickets came from one split feature, the PM may say "actually that's one ticket not two" or "I want three not two." Adjust and re-show only the changed parts.

### Step 5: Write to file

Append the finalized ticket(s) to `jira-tickets.md`. Update the file on disk before moving on.

**Don't batch** — write after every feature so partial progress is preserved.

### Step 6: Confirm and move on

> ```
> Saved TICK-NNN to TICK-NNN. Moving to Feature <next-id>.
> ```

---

## After All Tickets: Dependency Detection

Once every feature has been walked, present detected dependencies. Read `dependency-detection-guide.md` for the heuristic.

Show the PM a list like:

> ```
> Detected dependencies (best-effort):
>
> TICK-005 (Knowledge Base — add new source)
>   Depends on: TICK-004 (Knowledge Base — view existing sources)
>   Reason: stories in TICK-005 reference "the source appears in the list" which
>   implies the list UI from TICK-004 must exist first.
>
> TICK-009 (Automation wizard — configure tone)
>   Depends on: TICK-007 (Automation wizard — start and select trigger)
>   Reason: stories in TICK-009 reference "after selecting the trigger post"
>   which implies entry flow from TICK-007 is in place.
>
> TICK-015 (HubSpot integration — write ticket)
>   Depends on: TICK-013 (Structured ticket output to S3)
>   Reason: stories in TICK-015 reference "tickets from S3" — needs the S3 writer.
>
> Review and tell me what to:
>   - accept as-is
>   - remove a dependency I got wrong
>   - add a dependency I missed (e.g. "TICK-008 also depends on TICK-002")
> ```

Apply edits and update the "Depends on:" lines in each ticket. Save the file.

---

## Final Pass

After dependencies are confirmed:

1. Read the whole MD end-to-end.
2. Run consistency checks:
   - Every ticket has all required sections (no empty user-story, no empty in-scope).
   - Every "Traces to:" line references a real feature in dev-spec.
   - Every "Depends on:" line references a real ticket ID.
   - Every ticket has ≥1 acceptance criterion.
   - No ticket has zero stories in scope (would mean it's an empty ticket).
3. Surface any issues to the PM and confirm the file is final.

Update the frontmatter `last_updated` and `ticket_count`.

---

## Output Location

Write to: `./jira-tickets.md` in the working directory (alongside `dev-spec.md`).

After writing, call `present_files` so the PM can view the artifact.

---

## What This Skill Does NOT Do

- ❌ Push tickets to Jira via API — manual paste only (API integration is a future enhancement).
- ❌ Estimate story points — devs do this in backlog grooming.
- ❌ Generate sub-tasks — tickets are flat in this skill; sub-tasks emerge in dev sessions if needed.
- ❌ Process AI-typed requirements — those go to the eval-md skill (future).
- ❌ Modify the dev spec — dev spec is the source, never edited by this skill.
- ❌ Generate the discovery spec, dev spec, SoW, or eval set — separate skills.

If the PM asks for any of these, point them to the right skill.

---

## Common PM Mistakes to Watch For

| Mistake | What to do |
|---|---|
| PM wants a ticket per story (not per flow) | Push back. Tickets are flows, not stories. Per-story would create 100+ tickets and dilute customer value. |
| PM wants AI requirements as tickets | Those go to eval-md, not Jira. Tell them. |
| PM wants to add scope not in the dev spec | Stop. This is scope expansion. The dev spec is the source. Update the dev spec first, then re-run. |
| PM writes technical AC ("the lambda returns 200") | Reframe to QA-observable ("the message appears in chat after sending"). |
| PM splits a feature into too many tiny tickets | Push back if any ticket has <2 stories. Merge with adjacent. |
| PM merges a feature with 10+ stories into one ticket | Push back — too big, not independently testable, not one customer-value flow. Suggest splits. |
| PM tries to skip the dependency review step | Don't skip. Wrong dependencies block QA testing order. |
| PM writes acceptance criteria as a flat list of properties | Restructure into Entry Point + named flows. Flat properties miss scenario interactions (e.g. "what if X happens while Y is mid-flight"). |
| PM rejects every implicit scenario from the library | Fine — defer to PM judgment. But if a pattern keeps getting rejected on similar features, the library entry may be wrong for this team's products. Note it. |
| PM forgets sequencing matters | Remind: ticket IDs are sequential in delivery-relevant order. Dependencies are the source of truth for testing order. |

---

## Reference Files in This Skill

- `ticket-template.md` — the exact structure of one ticket. Read before drafting any ticket. Note the AC section uses Entry Point + named flows, not flat property assertions.
- `story-classification-guide.md` — how to group stories into user journeys (Step 0) and then slot them into "In scope" / "Error handling" / "Edge cases."
- `implicit-scenarios-library.md` — common implicit scenarios by feature type that the dev spec often misses. Surface these to the PM during ticket review as candidate additions (never silently).
- `feature-splitting-guide.md` — when and how to split a feature into multiple tickets.
- `dependency-detection-guide.md` — heuristics for detecting dependencies between tickets.
- `example-output.md` — a worked example showing what `jira-tickets.md` looks like at the end, including the flow-based AC structure.
