# Story Classification Guide

Every SW story in a feature lands in one of three ticket sections:
- **In scope** — happy-path stories. The thing the user does and what the system shows when everything works.
- **Error handling** — failure-path stories. Network drops, expired sessions, server errors, system breakdowns.
- **Edge cases** — boundary-condition stories. Oversized inputs, empty states, wrong formats, concurrent actions, off-hours behaviors.

The skill classifies each story into one of these three. This guide is the heuristic.

**Order of operations:**
1. **Group stories into user journeys** (see below) — this drives the AC flow structure.
2. **Classify each story** into in-scope / error / edge using the rules in this guide.

---

## Step 0: Group stories into user journeys (before classifying)

Before classifying stories, group them into the **distinct user journeys** this ticket needs to support. Each journey becomes a named flow in the Acceptance Criteria.

**Why this matters:** classifying stories first and then trying to build flat ACs misses scenario interactions. Grouping into journeys first surfaces scenarios you'd otherwise miss (e.g. "what happens if the user does X while Y is in progress").

A user journey is a sequence of user-system interactions that delivers a complete unit of customer value. Within one ticket, expect 2-5 distinct journeys.

### How to find the journeys

For each ticket, ask:
- What's the **primary happy-path journey** (the thing the user does most often)?
- What **alternative paths** exist (variations the user can choose)?
- What **interruption journeys** exist (what if the user switches contexts, navigates away, refreshes, etc.)?
- What **recovery journeys** exist (what if something fails — how does the user get back on track)?

Each of these becomes a named flow.

### Example: conversation history sidebar ticket

For a ticket about "rider opens and resumes a past conversation":
- **Flow 1: Switch to a past conversation** — primary happy path
- **Flow 2: Switch back to original** — variation (the round-trip case)
- **Flow 3: Switch while a reply is mid-stream** — interruption journey
- **Flow 4: Start a new conversation** — alternative path
- **Flow 5: Persist active conversation across refresh** — recovery / continuity journey

These would NOT have surfaced from a flat list of stories — they emerge when you specifically ask "what journeys does this ticket need to cover?"

### Use implicit-scenarios-library.md to find what's missing

After grouping stories into journeys, check `implicit-scenarios-library.md` for common implicit scenarios by feature type. If a likely scenario is missing from the journey list, surface it to the PM during ticket review.

---

## In scope (happy path)

A story is **in scope** if it describes the normal, expected user behavior — what happens when the user does what they're supposed to do and everything works.

Patterns:
- Story name contains: "user lands", "user sees", "user taps", "user enters", "system displays", "system responds", "user submits", "user navigates", "page renders", "agent generates".
- No mention of failure, expiry, error, retry, validation rejection.
- Describes a successful interaction.

Examples (in scope):
- "User taps send → message appears in chat with timestamp"
- "Authenticated rider lands on chatbot page"
- "Agent generates response and streams it back"
- "User selects valid image → file appears as thumbnail"
- "Sidebar displays past threads sorted by recency"

**These all describe the path that produces value.**

---

## Error handling (failure path)

A story is **error handling** if it describes what the system does when something *external or systemic* fails — not when the user does something wrong, but when the system itself encounters trouble.

Patterns:
- Story name contains: "fails", "error", "expires", "expired", "unavailable", "timeout", "retry", "disconnect", "lost", "network", "server error", "outage".
- Describes the response to a system breakdown the user didn't cause.

Examples (error handling):
- "Upload fails (network) → user sees retry button"
- "Auth expires mid-session → modal prompts re-sign-in, draft preserved"
- "Vendor API unavailable → graceful fallback message displayed"
- "Server returns 5xx → user-friendly error replaces technical detail"

**These describe how the system stays usable when things go wrong.**

---

## Edge cases (boundary conditions)

A story is an **edge case** if it describes the system's behavior at the boundary of allowed inputs or unusual states — usually triggered by user action that's technically permitted but at the limits.

Patterns:
- Story name contains: "oversized", "too large", "too small", "empty", "no items", "first-time", "wrong format", "invalid", "exceeds limit", "max", "min", "off-hours", "concurrent", "simultaneous", "no results", "deleted", "soft delete".
- Describes what happens when the user is *allowed* to do something but hits a constraint.

Examples (edge cases):
- "User selects file larger than 50MB → inline 'must be under 50MB' message"
- "User selects HEIC file → 'Accepted: JPEG, PNG, MP4' message"
- "Empty state — new user has no threads → 'No conversations yet' placeholder"
- "User submits empty input → send button disabled, no API call"
- "Long message wraps without horizontal scroll"

**These describe the system's behavior at the edges of normal use.**

---

## Disambiguation: failure vs edge case

The line between error handling and edge cases is subtle. Use this test:

**Did the user do something that triggered the case? → Edge case.**
**Did the system fail / something went wrong externally? → Error handling.**

| Story | Classification | Why |
|---|---|---|
| "Upload fails (network drop)" | Error handling | Network failure — system-side problem |
| "User selects file >50MB" | Edge case | User-initiated boundary condition |
| "Auth expires mid-session" | Error handling | Session expiration — system-side state change |
| "User clicks send with empty input" | Edge case | User-initiated unusual input |
| "Server returns 500" | Error handling | Server-side failure |
| "Empty thread list for new user" | Edge case | Boundary condition (zero items) |
| "User retries after upload failed" | Error handling | Following a system failure |

Ambiguous cases: if you can't decide, default to **edge cases** for user-initiated and **error handling** for system-initiated.

---

## What if a story doesn't fit any category?

Some stories are pure "context" or setup — they describe initial state without an action. These go in **in scope** by default.

Example: "Server-side auth gate on initial page load" — this describes the system's normal initial behavior. In scope.

Example: "S3 lifecycle policy: 90 days" — actually NOT a story, this belongs in acceptance criteria. The skill should recognize and route it.

---

## What about stories that mix happy path and failure?

A story like "User taps send → message appears OR if network fails, user sees retry" should be **split** into two stories:
1. (In scope) "User taps send → message appears"
2. (Error handling) "If network fails when sending, user sees inline retry button"

If the dev spec has compound stories, the skill should split them before classifying. Flag this to the PM if it happens — it's a dev-spec quality issue.

---

## Cross-cutting truths that aren't stories

The dev spec sometimes has stories that are really cross-cutting assertions — e.g. "All form fields validate inline" or "All API calls require auth JWT." These are **acceptance criteria**, not stories.

If you encounter one:
- Don't put it in In scope / Error / Edge.
- Put it in Acceptance Criteria.
- If it's already in the feature's AC list in dev-spec, you'll see it there.

---

## Examples by feature type

### File upload feature
Typical breakdown:
- **In scope:** select valid file, file appears as thumbnail, send with file attached
- **Error handling:** upload fails (retry button), session expires mid-upload
- **Edge cases:** oversized file, wrong format, removing attached file before send

### Auth-gated screen
- **In scope:** authenticated user lands, content renders
- **Error handling:** unauthenticated redirect, auth expires mid-session
- **Edge cases:** soft-deleted user, account suspended

### List / paginated content
- **In scope:** list renders, items displayed sorted, scroll/paginate loads more
- **Error handling:** fetch fails, no internet on initial load
- **Edge cases:** empty state, very long list, deleted item still in cache

### Form submission
- **In scope:** valid input accepted, submit shows progress, success state
- **Error handling:** submit fails (retry), session expires mid-submit
- **Edge cases:** empty submit blocked, invalid input rejected with inline message, partial submit

### Agent classification
- **In scope:** clear-case classification correct → routed correctly
- **Error handling:** classification confidence below threshold → clarification asked
- **Edge cases:** safety override (classification overruled by safety rule)

---

## When in doubt

When you can't confidently classify a story, **ask the PM during ticket review**. It's better to surface ambiguity than to silently miscategorize. The PM has the product context to make the call.
