# Dependency Detection Guide

After all tickets are drafted, walk the list and detect dependencies between them. This guide covers the heuristics for finding them.

Dependencies are then surfaced to the PM as a bulk list at the end of the session — the PM confirms or corrects them, then the skill writes the "Depends on:" lines back into each ticket.

---

## What counts as a dependency

A ticket B **depends on** ticket A when A must ship (be functionally complete) before B can be tested or delivered.

Dependencies are about delivery / testing order, not just code coupling. Two tickets can share code and still ship independently. Two tickets that share zero code can still be sequentially dependent if user-facing behavior in B assumes outcomes from A.

---

## Signal sources

### Signal 1: Same-epic precedence by lifecycle

Within an epic, look for lifecycle ordering. Earlier-stage features tend to be dependencies of later-stage features.

Common patterns:
- **"View/list" tickets precede "edit/delete" tickets** on the same surface. You can't edit what you can't see.
- **"Create" tickets precede "configure" tickets** for the same entity. Configuration needs an existing entity.
- **"Wizard launch" tickets precede "wizard middle/end" tickets** if the wizard was split.
- **"Auth gate" tickets precede every authenticated feature.**

Example:
- TICK-004 (View list of knowledge sources) → no dependency
- TICK-005 (Add new knowledge source) → depends on TICK-004 (because "the new source appears in the list")
- TICK-006 (Edit existing knowledge source) → depends on TICK-004 (must see source to edit it)
- TICK-007 (Delete knowledge source) → depends on TICK-004

### Signal 2: Cross-epic infrastructure dependencies

Some epics build foundations that later epics consume.

Common patterns:
- **Conversational surface tickets** (chat UI, webhook ingestion) → depended on by **agentic response tickets** (agent generates response).
- **Ticket-output tickets** (write to S3) → depended on by **integration tickets** (HubSpot reads the S3 ticket).
- **Authentication/onboarding tickets** → depended on by every authenticated-user ticket.

Example from Ryvid:
- TICK-001 (Chatbot page renders) — no dependencies
- TICK-009 (Agent generates response) — depends on TICK-001 (no chat surface, no agent invocation)
- TICK-015 (HubSpot integration writes ticket) — depends on TICK-013 (Structured ticket output to S3)

### Signal 3: Explicit references in stories

Story text often signals dependencies through verbs like:
- "after the user has X"
- "when the X already exists"
- "if X has been configured"
- "given the X is set up"

When you see these in a ticket's stories, look for the ticket where X is established.

Example:
- TICK-009's stories include "after selecting a trigger post" → depends on whichever ticket has "select trigger post" in its stories (TICK-008 say).

### Signal 4: Feature notes from dev spec

Dev spec `**Notes:**` lines often flag dependencies:
- *"Reuses Linkme's existing Instagram OAuth integration"* → if any ticket builds the OAuth, this ticket depends on it.
- *"Schema must match HubSpot field mapping"* → no ticket dependency (it's a data dependency), but check.

### Signal 5: Shared UX surface

When two tickets work on the same UI surface and one builds the surface while the other adds behavior to it, the behavior ticket depends on the surface ticket.

Example:
- TICK-001 (Chatbot page rendering) — builds the page
- TICK-002 (Media upload control) — adds upload behavior to the page → depends on TICK-001

---

## Patterns that are NOT dependencies

Some apparent connections aren't real dependencies:

### Shared component, but independently testable
TICK-007 and TICK-008 both use the same input component. Neither depends on the other — they can be built and tested in parallel.

### Same epic, but independent flows
TICK-005 (configure language) and TICK-006 (configure frustration threshold) are both in the Configuration epic but they're parallel options on different surfaces. No dependency.

### Backend service used by multiple tickets
TICK-009 and TICK-010 both call the same AI Lambda. The Lambda is infrastructure — both depend on the infrastructure being in place, but not on each other.

### Same data model used by multiple tickets
Same as above. Two tickets reading/writing the same data don't depend on each other unless one's writes are precondition for the other's reads.

---

## Edge cases

### Circular dependency suspected
If you detect that TICK-A depends on TICK-B AND TICK-B depends on TICK-A, something's wrong:
- One ticket might be too broad (covering two flows that should be separate).
- One dependency might be incorrect.
- The split-line between the tickets might be wrong.

Flag it to the PM during the dependency-review step. Don't write a circular dependency to the file.

### Chained dependencies
TICK-C depends on TICK-B which depends on TICK-A. In the MD, write only the direct dependency:
- TICK-C: "Depends on: TICK-B"
- TICK-B: "Depends on: TICK-A"
- NOT: TICK-C: "Depends on: TICK-B, TICK-A"

Transitivity is implicit. Listing it pollutes the dependency list.

### Optional vs hard dependencies
If TICK-B can technically ship without TICK-A but is much better with it, that's not a real dependency. Don't list it. Maybe note as "Related tickets:" instead.

### External dependencies
If a ticket depends on something outside the dev spec (existing Linkme infrastructure, customer-side integration), say so in the user story's role or in Background, NOT as a "Depends on:" line. Depends on is for inter-ticket dependencies only.

---

## How to present detected dependencies to the PM

After detection, show the PM a structured summary:

```
Detected dependencies (best-effort — review and correct):

TICK-005 → depends on TICK-004
  Reason: "the new source appears in the list" implies the list UI from TICK-004
  exists.

TICK-009 → depends on TICK-008
  Reason: stories reference "after selecting trigger post" — that's TICK-008's
  outcome.

TICK-015 → depends on TICK-013
  Reason: "transforms tickets from S3" requires the S3 writer from TICK-013.

TICK-002 → depends on TICK-001
  Reason: media upload control attaches to the chatbot page surface, which is
  TICK-001.

Total dependencies detected: 4

Review and tell me what to:
  - accept as-is
  - remove a dependency (which one and why)
  - add a missing dependency (which tickets and reason)
```

After the PM responds, update the "Depends on:" lines in each affected ticket.

---

## Writing the "Depends on:" line

Format:
```
**Depends on:** TICK-004 (knowledge sources list must be visible), TICK-001 (chatbot page surface)
```

- Multiple dependencies separated by commas.
- One-line reason in parentheses per dependency.
- Reason should be concise — a phrase, not a sentence.

If no dependencies:
```
**Depends on:** None
```

Always include the field, even when empty. Predictable structure.

---

## When the PM disagrees

If the PM rejects a detected dependency, ask why. Sometimes the answer reveals:
- A misclassification in your detection (great — apply for similar cases).
- Hidden context not in the dev spec (this is the PM's product knowledge — defer to them, but consider whether to note this in the dev-spec for future readers).
- A real conflict — they want the tickets to be independent for delivery reasons. Honor it.

If the PM adds a dependency you didn't detect, ask for the reason and use it to learn the pattern.
