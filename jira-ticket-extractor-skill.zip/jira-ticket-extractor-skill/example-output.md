# Example Output

What `jira-tickets.md` looks like at the end. Excerpt showing 3 tickets across 2 epics — derived from the Ryvid dev spec. **Note the AC structure: Entry Point + named flows + cross-cutting baselines, not flat property assertions.**

---

```markdown
---
project: Ryvid AI Chatbot MVP
source_dev_spec: ./dev-spec.md
source_discovery_spec: ./discovery-spec.md
ticket_count: 12
last_updated: 2026-05-22
---

# Ryvid AI Chatbot MVP — Jira Tickets

Generated from dev-spec.md. Each ticket below copies cleanly into a Jira issue. Use the "Epic" line to set the Jira epic link, the "Traces to" line for spec traceability, and the "Depends on" line to inform backlog ordering.

Only SW-typed requirements appear here. AI-typed capabilities are covered separately in `eval.md` (consumed by the AI developer alongside the dev spec).

---

## Epic 1: Conversational Support Surface

The user-facing chatbot embedded in Ryvid's Shopify storefront — the chat page, message UI, media uploads, and thread history. These tickets deliver the rider's primary interaction surface.

---

### TICK-001: Authenticated rider lands on the chatbot page

**Epic:** Conversational Support Surface
**Traces to:** Feature 1.1 — Chatbot Page on Shopify, requirements 1.1.1, 1.1.2, 1.1.3, 1.1.4
**Depends on:** None

**User story**
As an authenticated Ryvid rider, I want to access a chatbot page on Ryvid's site that recognizes me as a signed-in customer, so I can ask support questions without re-authenticating.

**Background**
The chatbot is Ryvid's primary self-service support surface. Riders today either email support or wait on chat with a human agent. The first thing any rider does is land on the chatbot page — if this entry experience is broken, nothing else matters.

**In scope**
- A signed-in Ryvid rider visiting the `/chat` page sees the chat interface, with their avatar shown alongside their messages.
- The page exposes a message input, a send button, and an upload control.
- The user can type in the input field; the field grows up to 5 lines, then scrolls.
- Sending a message via Enter (or the send button) submits it; Shift+Enter inserts a newline.

**Out of scope**
- Multi-language support (English only at MVP).
- Voice input.
- Anonymous (unauthenticated) chat access.

**Acceptance criteria**

**Entry Point:** Rider with a valid Shopify session navigating to `/chat`.

**Flow 1 (Authenticated entry):**
1. Rider visits `/chat`.
2. Server-side auth gate verifies the Shopify session JWT.
3. The chatbot page renders with the rider's Shopify avatar shown alongside their messages.
4. Message input, send button, and upload control are visible and ready.

**Flow 2 (Unauthenticated entry):**
1. A visitor without a valid Shopify session navigates to `/chat`.
2. They are redirected to Shopify's sign-in page.
3. After successful sign-in, they are returned to `/chat`.
4. The chatbot page renders as per Flow 1.

**Flow 3 (Session expires mid-page):**
1. The rider is on the chatbot page; their Shopify JWT expires.
2. On the next interaction, a modal prompts re-sign-in.
3. The rider's unsent draft is preserved; after re-auth, the rider returns to the same state with the draft intact.

**Flow 4 (Send a message via keyboard):**
1. Rider types text into the input field.
2. Rider presses Enter (without Shift).
3. The message submits.

**Responsiveness:** UI must remain fully functional across viewports from 320px wide. The input area stays visible above the device keyboard on mobile.

**Error handling**
- _None specific to this ticket beyond Flow 3's auth-expiry recovery._

**Edge cases**
- Pressing Shift+Enter inserts a newline rather than submitting.
- The input field expands vertically up to 5 lines, then scrolls.

**Related tickets**
- TICK-002 (media upload control attaches to this page surface)

---

### TICK-002: Rider attaches an image or video to a chat message

**Epic:** Conversational Support Surface
**Traces to:** Feature 1.2 — Media Uploads, requirements 1.2.1, 1.2.2, 1.2.3, 1.2.4
**Depends on:** TICK-001 (chatbot page surface must exist for the upload control)

**User story**
As a Ryvid rider, I want to attach an image or short video of my bike issue to a chat message, so the AI can see what I'm describing and triage me better.

**Background**
Many Ryvid support cases are visual — a flickering dashboard, a loose mount, a strange noise. Without media attachments, riders describe issues in words alone, which limits first-contact resolution and slows triage of complex cases. Media attachment is high-leverage for first-turn understanding.

**In scope**
- The rider taps the upload control on the chat page and picks an image (JPEG/PNG) or short video (MP4) up to 50MB.
- A thumbnail of the file appears in the attachment slot above the input.
- While the file uploads, a progress indicator is visible in the thumbnail.
- The send button is disabled while a file is mid-upload; it enables once the upload completes.
- The user can remove an attached file (tap X on thumbnail) before sending.

**Out of scope**
- Multiple files per message (one file per message at MVP).
- Audio file attachments.
- Live camera capture in-app.
- Drag-and-drop or paste-from-clipboard upload.

**Acceptance criteria**

**Entry Point:** Rider authenticated and on the chatbot page.

**Flow 1 (Attach a valid file and send):**
1. Rider taps the upload control.
2. Rider picks a JPEG, PNG, or MP4 file ≤50MB.
3. A thumbnail appears in the attachment slot above the input.
4. A progress indicator displays while the upload runs; the send button is disabled.
5. Upload completes; the send button enables.
6. Rider taps send. The message — with the attached file — is submitted.

**Flow 2 (Remove an attached file before sending):**
1. Rider attaches a file (per Flow 1, steps 1-5).
2. Before sending, rider taps X on the thumbnail.
3. The file is removed from the attachment slot. The send button's state re-evaluates based on the text input.

**Flow 3 (Upload fails and rider retries):**
1. Rider attaches a file. Upload begins, then fails (network drop, server error).
2. The thumbnail shows an error state with a "Tap to retry" button.
3. Rider taps retry; the same upload is attempted again.
4. After 3 consecutive failures, the rider is prompted to re-select the file.

**Flow 4 (Session expires mid-upload):**
1. Rider's upload is in progress.
2. The Shopify session expires; the re-sign-in modal appears.
3. The rider's selected file is preserved.
4. After re-auth, the upload resumes or restarts.

**Responsiveness:** UI must remain fully functional across viewports from 320px wide.

**Error handling**
- Upload failures (network or server) surface as a "Tap to retry" button in the thumbnail. After 3 failures, the rider is prompted to re-select.
- The send button never enables while an upload is mid-flight, regardless of any other state.

**Edge cases**
- A file larger than 50MB → an inline message "File must be under 50MB" appears below the upload control. No network call is made.
- A file in an unsupported format → an inline message "Accepted: JPEG, PNG, MP4" appears. No network call is made.
- All file size and format validations happen client-side before any network call.

**Related tickets**
- TICK-001 (shared chat page surface)

---

## Epic 3: Ticket Capture & HubSpot Handoff

When the AI identifies a case that needs a human, it captures a structured ticket and routes it into Ryvid's existing CRM. These tickets deliver the handoff layer — without them, the AI's triage work never reaches a support agent.

---

### TICK-013: Structured complex-case ticket persists to internal storage

**Epic:** Ticket Capture & HubSpot Handoff
**Traces to:** Feature 3.1 — Structured Ticket Output, requirement 3.1.3
**Depends on:** None

**User story**
As Ryvid support operations, I want every complex-case ticket the AI generates to be reliably saved, so we never lose a captured case before it reaches our CRM.

**Background**
The AI generates structured tickets for complex cases. Generation alone doesn't deliver value — the ticket must be reliably persisted before the integration layer hands it off to HubSpot. Unreliable persistence means customers fall through the cracks during peak load.

**In scope**
- Every AI-generated ticket is durably stored when emitted.
- Each ticket has a unique identifier and is associated with its conversation session.
- Stored tickets are discoverable by the integration layer (which writes them to HubSpot).

**Out of scope**
- The format/schema of the ticket itself (covered separately in the AI-typed feature; validated via the eval set).
- The HubSpot transformation and write itself.
- Long-term archival beyond the 90-day retention window.

**Acceptance criteria**

**Entry Point:** The AI agent has decided a case is complex and is emitting a structured ticket.

**Flow 1 (Successful persistence):**
1. Agent emits a structured ticket.
2. The ticket is persisted to durable storage with a unique identifier.
3. The persistence completes within the operational timeout.
4. The ticket is discoverable by the integration layer for downstream handoff.

**Flow 2 (Persistence fails and retries):**
1. Agent emits a ticket.
2. Persistence fails (storage error, transient outage).
3. The agent retries with exponential backoff, up to 3 attempts.
4. On success of any retry, Flow 1 step 4 applies.

**Flow 3 (Persistence fails permanently):**
1. All 3 retries fail.
2. The failure is logged with the full ticket payload preserved in application logs.
3. Support ops has enough information in logs to manually recover the case.

**Durability baseline:** Stored tickets survive service restart and process crashes. Local-only state is never the source of truth.

**Error handling**
- Persistent failure (Flow 3) is logged with the ticket payload preserved so support ops can manually recover.

**Edge cases**
- A ticket with unusually large diagnostic Q&A pairs persists correctly without truncation.

**Related tickets**
- _None._
```

---

## What to notice about the example

**AC structure: Entry Point + named flows + cross-cutting baselines.** Not a flat list of properties. Each flow describes a journey QA walks through; baselines (Responsiveness, Durability) are properties that apply across all flows.

**Scenarios caught by the flow structure:** Session-expires-mid-upload, retry-after-failure, remove-attached-file-before-sending. None of these would surface from a flat "the upload validates X" assertion list.

**No cross-ticket references in the body.** Out of scope lists capabilities ("Drag-and-drop or paste-from-clipboard upload"), not pointers. The dev infers what other tickets cover from titles alone. Cross-references live ONLY in "Depends on:" and "Related tickets:" sections.

**Background is strategic, not tactical.** User story is "what the user does." Background is "why this matters to the business."

**ACs all observable by QA without reading code.** "The send button never enables while an upload is mid-flight" → observable. "The Redux store transitions to PENDING" → not observable.

**Out of scope is specific, not vague.** "Multiple files per message (one file per message at MVP)" → specific. "Advanced upload features" → would be vague.

**Tone: customer-facing nouns, observable verbs, no implementation vocab.** "Attaches a file" not "POSTs to /uploads." "Thumbnail appears" not "MediaCard component renders." "Sign-in page" not "Shopify OAuth redirect endpoint."
