# Ticket Template

Every ticket in `jira-tickets.md` follows this exact structure. Sections appear in this order. If a section has no content for this ticket, write "_None._" rather than omitting — predictable structure helps the PM scan.

---

## Structure

```markdown
### TICK-<NNN>: <Concise title (~6-10 words, customer-value focused)>

**Epic:** <epic-name-from-dev-spec>
**Traces to:** Feature <feature-id> — <feature-name>, requirements <req-ids>
**Depends on:** <TICK-XXX, TICK-YYY — or "None">

**User story**
As a <user role>, I want to <do something>, so that <outcome / value>.

**Background**
<2-3 sentences. Why this ticket exists in the broader product. Pulls from dev-spec §1 Business Context, the epic-level user story, and case.md if available. Strategic, not tactical.>

**In scope**
- <Story rephrased as customer-observable behavior.>
- <Another story.>
- <Another story.>

**Out of scope**
- <Items from dev-spec §2 Reference to Discovery Spec → Out-of-Scope-list that are relevant to this ticket's surface.>
- <Items from this feature's **Notes:** line that explicitly bound scope.>
- <Adjacent capabilities deliberately excluded — e.g. "Multi-file attachment (one file per message at MVP)".>
- <If genuinely nothing: "_None specific to this ticket beyond dev-spec §2._">

**Acceptance criteria**

**Entry Point:** <one-sentence precondition state — what's true before any flow runs. E.g. "Authenticated user with at least one prior conversation, on the chat page.">

**Flow 1 (<descriptive name>):**
1. <Step describing what the user does or what the system does.>
2. <Next step.>
3. <Outcome step.>

**Flow 2 (<descriptive name>):**
1. <Step.>
2. <Step.>

**Responsiveness:** <if this is a UI ticket: "UI must remain fully functional across viewports from 320px." or "_N/A — not a UI ticket._">

**<Other cross-cutting baselines as needed, e.g. Persistence, Accessibility, Internationalization>:** <one-line assertion.>

**Error handling**
- <Stories that name a failure, expiry, invalid input, or network/system error.>
- <If genuinely none for this ticket: "_None._">

**Edge cases**
- <Stories that describe boundary conditions: oversized, empty, wrong format, concurrent, off-hours, etc.>
- <If genuinely none: "_None._">

**Related tickets**
- <TICK-XXX (brief reason — e.g. "shared UI shell")>
- <Or "_None._">
```

---

## Section-by-section guidance

### Title
- 6-10 words.
- Customer-value focused. "User uploads a file" not "POST /upload handler."
- Active voice. Verb + object pattern works well.
- Examples: "User adds a new knowledge source", "Creator previews automation behavior before publishing", "Visitor signs in to the chatbot via Shopify auth".
- **Bad examples:** "Chatbot Page" (no verb), "Implement upload endpoint" (technical), "1.1: Chatbot Page on Shopify" (raw feature copy with ID).

### Epic
- Verbatim from dev-spec §4. This drives Jira's epic-link feature when pasted.

### Traces to
- Format: `Feature <id> — <feature name>, requirements <list>`.
- The "list" is the comma-separated requirement IDs from dev-spec whose stories fall into this ticket.
- If the ticket covers a partial set of a feature's requirements (because it's a split), list only the requirements actually included.

### Depends on
- Format: `<TICK-ID> (one-line reason)` for each dependency.
- "None" if no dependencies.
- Filled in during the dependency-detection pass at the end, not during initial drafting.

### User story
- Strict format: `As a <role>, I want to <action>, so that <outcome>.`
- The "role" comes from the parent epic's user-story (in dev-spec §4) — usually a specific user persona ("Linkme creator", "Ryvid rider", "fan").
- The "action" is the ticket's primary outcome — what the user can do at the end of this ticket.
- The "outcome" / value — why this matters to the user.
- One sentence. No compound user stories ("…so that A and B and C").

### Background
- 2-3 sentences.
- Strategic context, not tactical. Why does this matter to the business or product?
- Pull from dev-spec §1, the parent epic's user-story, and case.md (especially the business case).
- **NOT a repeat of the user story.** The user story is "what the user can do." Background is "why we care."
- Example (good): *"Knowledge base configuration is the heart of the AI tier — without creator-specific knowledge, the AI is generic and creators won't pay the $29/mo. This ticket delivers the first slice: creators can see what knowledge their AI uses today."*
- Example (bad): *"This implements the knowledge base view."* (Repeats the user story, no strategic context.)

### In scope
- One bullet per SW story under this ticket.
- Rephrase each story from dev-spec to be observable + non-technical.
- Format: "The <user role> can <do something> and sees <observable result>." OR "When the <user role> <action>, the system <visible response>."
- **Strip implementation language.** No lambda names, AWS service names, internal API paths, JSON schemas, table names. Keep nouns the user would say.
- See `story-classification-guide.md` for which stories belong here vs error / edge.

### Out of scope
- Items explicitly excluded so the dev doesn't accidentally do extra work.
- **Each ticket should read as a standalone artifact.** Avoid cross-references to other tickets in the body of out-of-scope items. Don't write "Search (see TICK-011)" — write "Search across past conversations." The dev infers from the title that another ticket covers it.
- Three sources:
  1. **Inherited from dev-spec §2** (which references discovery-spec §7 Out of Scope) — pull items relevant to this ticket's surface.
  2. **Feature `**Notes:**` line** — often calls out "X is explicitly out of MVP scope."
  3. **Adjacent deferred capabilities** — things a dev might assume but shouldn't build. Name the capability ("Multi-thread bulk actions"), not the ticket where it lives.
- If genuinely none beyond dev-spec §2, write "_None specific to this ticket beyond dev-spec §2._" — don't restate everything.

### Acceptance criteria
- **Organized as flows, not flat properties.** A flow is a small named user journey with sequential steps. Each ticket should have 2-5 flows.
- **Always start with an Entry Point line** establishing the precondition state — what's true before any flow runs. This is the setup state QA reproduces before walking the flows.
- Each flow has a **descriptive name** that names the scenario it covers (e.g. "Switch to a past conversation", "Switch while a reply is mid-stream", "Retry failed upload"). Names are journey-focused, not property-focused.
- Each flow has **2-6 numbered steps**. Steps describe what the user does OR what the system does, in sequence. The last step is the outcome QA verifies.
- After all flows, add **cross-cutting baselines** as standalone one-liners — these are properties that apply across all flows (responsiveness, persistence, accessibility, etc.).
- Every flow step must be **QA-observable** without reading code. "The main pane replaces with the full transcript" is observable. "The state machine transitions to ACTIVE" is not.
- See the flow examples in `example-output.md`.

**Why flows instead of flat properties:** flows force scenario thinking. Flat property lists tend to miss interactions between behaviors (e.g. "what if the user switches conversations while a reply is mid-stream"). Walking through named journeys catches scenarios that flat assertions don't surface.

**Drawn from:** feature-level ACs in dev-spec (distributed across tickets if the feature splits), ticket-specific scenarios from this ticket's stories, AND judgment-driven scenarios from `implicit-scenarios-library.md` (apply when the dev spec is silent on common behaviors).

### Error handling
- Stories about failure paths, captured in plain language.
- Each line: trigger + visible system behavior.
- Example: "If the upload fails (network drop, server error), the user sees an inline 'Tap to retry' button and the file isn't lost."
- Story-classification-guide identifies which stories go here.

### Edge cases
- Stories about boundary conditions.
- Each line: scenario + system behavior.
- Example: "When the user selects a file larger than 50MB, the system blocks the upload with an inline message ('File must be under 50MB') and doesn't make any network call."

### Related tickets
- Tickets that share UX, surface, or context but aren't dependencies.
- **Lightweight pointers only — max 2-3 entries per ticket.** Don't restate cross-references that are already implicit in the ticket structure (e.g. don't list every TICK-XXX in the same epic).
- Helps the dev pick up context without polluting the standalone reading of this ticket.
- Example: "TICK-007 (sidebar surface this ticket attaches to)."
- "_None._" if nothing genuinely related.

**Cross-ticket reference discipline:** TICK-XXX references should appear ONLY in **Depends on:** and **Related tickets:** sections. The body of the ticket (User story, Background, In scope, Out of scope, Acceptance criteria, Error handling, Edge cases) must read as a standalone artifact without TICK-XXX links. Use capability names ("Search across past conversations") not ticket pointers ("see TICK-011") in those sections.

---

## Distributing feature-level ACs across split tickets

When a feature splits into multiple tickets, the feature-level AC list in dev-spec doesn't naturally map to one ticket. Three placement strategies:

**Place an AC in the ticket where it's most directly testable.** If the AC mentions "the validation message appears below the upload control" and only Ticket 2 has the validation flow, that AC goes in Ticket 2.

**If an AC genuinely applies across all tickets from this feature** (e.g. "All form fields validate inline"), include it in EACH ticket with the note `(applies to all tickets from feature X.Y)` so QA knows it's a cross-cutting requirement.

**If an AC is unclear**, ask the PM. Don't guess silently.

---

## Tone rules

- **Active voice.** "The user uploads a file." Not "A file is uploaded by the user."
- **Customer-facing nouns.** "Knowledge source" not "vector store entry." "Page" not "route handler." "Message" not "event."
- **Observable verbs.** "Sees", "appears", "blocks", "shows" — what the user perceives. Not "validates", "transforms", "persists" — what the code does.
- **No AWS / framework vocabulary.** No "Lambda", "S3", "DynamoDB", "Bedrock", "API Gateway", "Shopify webhook", "Meta Send API" in the ticket body. These are dev-spec content, not ticket content. (Exception: when a dev needs to know an integration exists for context — e.g. in Background — fine.)
- **Concrete, not vague.** "Within 5 seconds" not "quickly." "Up to 50MB" not "reasonable size." "JPEG, PNG, MP4" not "common formats."
