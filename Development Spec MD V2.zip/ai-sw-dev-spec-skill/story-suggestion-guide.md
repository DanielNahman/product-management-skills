# Story Suggestion Guide

This is the file you load every time you draft suggested stories for a feature. It's what separates useful suggestions from generic boilerplate.

---

## What a story is

A story is **one implementable unit of UX or system behavior** under a discovery-level requirement. It has:

- A **trigger** — a user action or system event.
- A **resulting behavior** — what the user sees and what the system does.

The story line in the table is one sentence:

> *Trigger → behavior.*

Example: *"User selects JPEG/PNG ≤50MB → file appears as thumbnail in attachment slot above input. Send button enables (if not already)."*

---

## What a story is NOT

| Not a story | Why | What it is instead |
|---|---|---|
| "Implement the upload Lambda" | Implementation step | A dev task, lives in code/Jira sub-tasks. |
| "Use S3 pre-signed URLs" | Tech choice | An architecture or API decision. |
| "Files are uploaded securely" | Vague property | Either an acceptance criterion or an NFR. |
| "Upload component" | A component, not a behavior | The component is implied by stories that describe its behaviors. |

If you find yourself drafting any of the above, stop and reframe.

---

## How to draft suggested stories for one requirement

### Step 1: Read the requirement carefully

The requirement is verbatim from the discovery spec — *"The user shall be able to upload images (JPEG/PNG) and videos (MP4) up to 50MB."*

### Step 2: Identify the shape of the requirement

Most requirements fall into a small number of shapes. Recognize the shape, then expand it.

#### Shape A: User performs an action that has multiple inputs/branches

Example: *"The user shall be able to upload images up to 50MB."*

Stories cover:
- **Happy path** — valid input → expected behavior.
- **Boundary failures** — input exactly at boundaries, oversized, undersized, wrong type.
- **In-progress states** — what the user sees while the action is happening.
- **Recovery / retry** — what happens when the action fails and how user retries.
- **Cancellation / undo** — what happens if the user wants to abandon mid-action.

#### Shape B: System provides information / displays content

Example: *"The chatbot page shall display message bubbles for both user and bot."*

Stories cover:
- **Initial render with content** — bubbles appear correctly.
- **Render with no content** — empty state.
- **Render while loading** — skeletons, spinners, typing indicators.
- **Render with error** — error states, retry affordances.
- **Edge content** — long messages, code blocks, links, embedded media.

#### Shape C: User navigates between states

Example: *"The user shall be able to view a sidebar listing past threads and reopen any thread to continue."*

Stories cover:
- **Default navigation** — happy path entry/exit.
- **Empty state** — what the user sees when no items exist.
- **Active state** — visual indication of where the user is.
- **State preservation** — what happens when navigating away and back.
- **Pagination / scroll** — what happens with large lists.

#### Shape D: System enforces a rule (auth, validation, safety)

Example: *"The user shall only reach the chatbot if Shopify has authenticated their session."*

Stories cover:
- **Pass case** — rule met, action proceeds.
- **Fail case at entry** — rule fails up front, what user sees.
- **Fail case mid-flow** — rule fails after action started (auth expires, session times out).
- **Recovery** — how user re-establishes the rule's preconditions.

#### Shape E: AI agent behavior

Example: *"The agent shall ask 4–5 targeted diagnostic questions when a request is classified as Complex."*

Stories cover:
- **Trigger condition** — when does this behavior activate.
- **Mid-behavior steps** — what the agent does turn-by-turn.
- **Termination condition** — when does the behavior end.
- **Output** — what's produced at the end.
- **Adjacent behaviors** — what happens if the agent's classification changes mid-flow.

#### Shape F: One action over an enumerated set (atomic-list requirement)

The new discovery rules allow a single requirement to apply one capability across a **closed enumerated set** — e.g. *"The agent shall extract the following IFRS 16 fields: commencement date, termination date, payment amounts, …"* or *"…including create, edit, and deactivate."* This is one atomic capability, deliberately not split at discovery. Do **not** try to re-split the requirement, and do **not** mechanically generate one story per list member (that produces noise).

Stories cover:
- **Happy path across the set** — the action succeeds over a representative item, and the behavior generalizes (one story, not one-per-field).
- **A genuinely distinct member** — only if a specific member behaves differently (e.g. a CPI-linked field needs an index lookup other fields don't; a date field has format ambiguity). One story per *genuinely distinct* member, not per member.
- **Partial / missing members** — what happens when some of the set is absent (e.g. a field the contract doesn't contain → low-confidence / flagged-for-review).
- **Whole-set failure** — the action fails for the whole set (e.g. OCR unreadable → nothing extracted).
- **The set boundary** — an item *outside* the closed set appears (e.g. a clause type not in the field list → ignored, not invented).

The test for "do these deserve separate stories": do two members exercise **different behavior**? If yes, story each. If they're the same behavior over different data, one story covers them.

### Same-controls features inherit parity, not re-derivation

If the discovery spec marked a feature as running under the **same controls** as another (the index records this in the `mirrors` column — e.g. "Manual Lease Entry mirrors the AI flow's validation / audit / versioning / role gating"), do **not** re-derive the mirrored behavior from scratch. Draft **parity-assertion** stories instead: *"User submits manual form with a missing required field → same validation block as the AI flow (Feature 5.3.5), same inline error."* The story's job is to assert the two paths behave identically and to catch the cases where they might silently diverge (a control present in one path but skipped in the other). One parity story per shared control surface is usually enough; add divergence stories only where the two paths genuinely differ (e.g. the manual path has no OCR step).

### Step 3: For the shape, draft stories — as many as the requirement honestly needs

Cover the happy path plus the edge cases that genuinely apply (typically 3–6, but there is **no cap and no floor beyond the happy path**). Draft as many stories as the requirement's real branches demand and no more.

**Do not infer anything about the discovery spec from story count.** A requirement that yields many stories is not a sign it "should have been split at discovery" — discovery requirements are atomic *capabilities*, and one atomic capability (e.g. an enumerated-set extraction, or a rule with many failure modes) can legitimately fan out into many stories. Story count reflects behavioral branches, not requirement granularity. Never tell the PM their signed discovery spec is malformed because a requirement produced a lot of stories.

Each story is a row in the table:

```
| ID | Story name (3-6 words) | Trigger → behavior (one sentence) |
```

### Step 4: Apply the cross-cutting checklist

Before showing the suggestions to the PM, walk this list. Have you covered the relevant items?

| Cross-cut | When to include |
|---|---|
| **Auth expiry mid-flow** | Any feature behind auth where the user spends time on screen (uploads, multi-step flows, long forms). |
| **Network failure / retry** | Any feature involving an API call. |
| **Oversized / out-of-range input** | Any feature accepting user input with bounds (file size, text length, numeric range). |
| **Wrong type / format** | Any feature accepting user-chosen content type (file picker, paste, drag-drop). |
| **Empty state** | Any feature that lists or displays content. |
| **Loading state** | Any feature that fetches content. |
| **Error state with recovery** | Any feature that can fail externally. |
| **Cancellation / interruption** | Any multi-step or long-running flow. |
| **Concurrent / race conditions** | Any feature where the user can act while a prior action is in flight. |
| **Mobile-specific behavior** | Any feature with input controls (keyboards), gestures, or layout that differs from desktop. |

You don't need to include every cross-cut for every requirement — apply only the ones that genuinely apply. But err on the side of including rather than skipping. PMs habitually forget edge cases; the skill's job is to surface them.

### Step 5: Present to the PM

Show the full feature's stories at once (all requirements under that feature drafted), then ask for review and edits. Don't drip them one requirement at a time — the PM benefits from seeing the feature whole.

---

## Story phrasing rules

### Required form: trigger → behavior

Every story's UX/System Behavior cell starts with the trigger and uses an arrow (→) or "when X, then Y" to separate trigger from behavior.

✅ *"User taps send → message appears as right-aligned bubble with user avatar. Send button disabled until response begins."*

✅ *"When agent classifies a message as Complex, it enters diagnostic mode and does not generate an immediate answer."*

❌ *"Message bubbles appear correctly."* (No trigger, no behavior — vague.)

❌ *"Send button is disabled while message in flight."* (Implies trigger but doesn't state it explicitly.)

### One concrete behavior per story

✅ *"Upload fails (network) → inline retry button + error message 'Upload failed. Tap to retry.'"*

❌ *"Upload fails — UI shows error and retries automatically and then if it still fails shows error message."* (Three behaviors — split into stories: auto-retry, retry exhaustion, manual retry.)

### Story names are short noun phrases

The "Story" column (3–6 words). Description goes in the "UX / System Behavior" column.

✅ "User selects oversized image" / "Authenticated user lands on chatbot page" / "Agent encounters ambiguous classification"

❌ "Story 1.2.1.2" (number, not a name) / "When user picks file" (full sentence)

### Stories under AI requirements describe agent behavior, not code

For `AI`-typed requirements, stories are about what the agent **does** — its decisions, reasoning steps, tool calls, outputs. Not about deterministic supporting code.

✅ *"Agent receives a complex case → enters diagnostic mode and asks the first question grounded in the matching playbook."*

❌ *"System checks if classification field equals 'complex' and routes to diagnostic handler function."* (Implementation, not behavior.)

---

## Common patterns by feature type

These aren't templates — every feature is handcrafted — but recognizing patterns helps you remember what to cover.

### Chatbot / message UI feature
- Render a message
- Render typing indicator
- Send via keyboard vs button
- Long-message wrapping
- Embedded content (code, links, media)

### File upload feature
- Select valid file
- Select file too large
- Select file wrong format
- Upload in progress (progress indicator)
- Upload success (thumbnail / confirmation)
- Upload failure with retry
- Cancel mid-upload
- Remove attached file before sending

### Auth-gated screen
- Authenticated user enters
- Unauthenticated user redirected
- Auth expires while on screen / mid-action

### List / sidebar / paginated content
- Items displayed in expected order
- Empty state (no items)
- Active item highlighted
- Pagination or infinite scroll
- Long list overflow handling

### Form / input field
- Valid input accepted
- Invalid input rejected with inline message
- Empty submission blocked
- Submit in progress
- Submit success
- Submit failure with retry

### AI agent classification / decision
- Clear-case classification correct
- Edge-case classification (ambiguous → fallback behavior)
- Classification confidence too low → handoff or clarifying question
- Classification overridden by safety rule

### AI agent retrieval (RAG)
- Relevant retrieval succeeds
- No relevant content → fallback (clarify or escalate)
- Retrieval returns conflicting passages
- Retrieval cached vs fresh

### External integration (API call to vendor)
- Successful call → expected outcome
- Vendor returns error → retry or fail-with-message
- Vendor unavailable → graceful degradation
- Vendor schema/field mapping verified

---

## When to push back on the PM

After showing suggestions, the PM may push back. Some pushback is good (they know the product). Some isn't.

**Accept these:**
- "Remove story X — that's covered by NFR / it's not in MVP / Ryvid said no."
- "Reword X — the trigger should be Y, not Z."
- "Add story X — I forgot to mention this in discovery."

**Push back on these:**
- "Just delete the failure stories — we'll handle errors generically." → No. Failure stories are tickets that get implemented. Generic error handling is fine, but the cases need to be enumerated so we know what we're testing.
- "The empty state isn't important." → It's almost always important. Push to confirm.
- "Just one story for the whole feature." → Almost certainly under-specified. Walk why each story matters.
- "Add a story about how we'll implement it." → Reframe: implementation lives in code; the story should describe what the user sees or what the system does at the user/product level.

---

## When the PM accepts everything without changes

If the PM accepts your draft verbatim, that's not necessarily a sign of great drafting — it might be a sign the PM is rushing or not engaged. Probe gently once:

> ```
> Before I save and move on — anything feel missing? Is the upload-failure flow
> actually three retries, or just one and done? And on auth expiry, do we
> preserve the unsent message or discard it?
> ```

Pick a couple of the story specifics that involve real product judgment and ask. If the PM confirms with detail, save and move on. If the PM is dismissive ("yeah whatever just save it"), save and move on but note in your final pass that the spec deserves a second review.
