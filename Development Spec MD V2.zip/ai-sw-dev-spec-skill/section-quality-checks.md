# Section Quality Checks (Dev Spec)

Apply these as you draft. When a check fails, ask the PM for specifics rather than guessing.

---

## YAML Frontmatter

| Check | Why |
|---|---|
| `phase` is exactly `development` | Distinguishes from discovery spec. |
| `linked_specs.discovery` points to `./discovery-spec.md` | Lineage. |
| `discovery_locked_at` is the actual signature date from the discovery spec | Traceability for change-order conversations. |
| `client`, `project`, `sow_number` match the discovery spec exactly | These are inherited, not redefined. |
| `last_updated` is today | Stale dates erode trust. |

---

## §1 Business Context

| Check | What good looks like |
|---|---|
| 2–4 sentences | Same as discovery — orient a reader in <30 seconds. |
| Anchors to `case.md` AND `discovery-spec.md` | The reader has both for deeper context. |

**Reject when:**
- It's a copy of discovery-spec §1 — anchor, don't duplicate.
- It introduces new framing not present in discovery — that's scope drift.

---

## §2 Reference to Discovery Spec

| Check | What good looks like |
|---|---|
| Lists exactly the inherited items (KPIs, NFRs, Out of Scope, Customer-Provided Inputs, feature/req list) | Each as one bullet pointing to its discovery-spec section. |
| Change orders table is present | Empty with "No change orders to date" if none, populated if any. |
| Each change order entry names what changed, from what, to what, and the change order ID | Audit trail. |

**Reject when:**
- The PM tries to silently rewrite KPIs / NFRs / out-of-scope here — those are locked. Either reject or convert into a logged change order.

---

## §3 Resolved Assumptions & New Constraints

| Check | What good looks like |
|---|---|
| Every discovery assumption walked explicitly | Walk the assumptions list from discovery §6 one by one. |
| Resolved assumption → concrete decision + date | Not vague — "Bedrock model selected" is bad; "Bedrock model: Claude Sonnet 4.6" is good. |
| Unresolved assumptions stay in the discovery spec, not here | This section is for *resolutions*, not unresolved hedging. |
| New constraints have a source | "Surfaced by Ryvid CRM admin during integration kickoff" — better than just stating the constraint. |

**Reject when:**
- A row says "TBD" or "to be decided" — that's an open question, belongs in §8.
- A new constraint contradicts a discovery assumption without acknowledgment — flag it.

---

## §4 Scope

This is the deepest section. The bulk of the work.

### Hierarchy & ID checks

| Check | What good looks like |
|---|---|
| Every epic and feature from discovery-spec §4 appears here | None silently dropped. |
| Every requirement appears verbatim with its discovery ID and type | Don't reword the "shall" statements — they're contractual. |
| Story IDs are `<epic>.<feature>.<requirement>.<story>` | 4-level. |
| Story IDs are sequential and append-only within a requirement | If a story is removed, leave the ID retired. |
| Story type inherits from parent requirement | Don't tag stories with their own `AI`/`SW` — the requirement carries it. |

### Story content checks (apply story-suggestion-guide as primary reference)

| Check | What good looks like |
|---|---|
| Every story has a trigger and a behavior | "Trigger → behavior" or "When X, then Y". |
| One concrete behavior per story | Multi-behavior stories get split. |
| Stories cover happy path AND edge cases AND failures | At least 3 stories per requirement; aim for 3–6. |
| AI stories describe agent behavior, not deterministic code | See story-suggestion-guide. |

### Acceptance Criteria checks

| Check | What good looks like |
|---|---|
| Acceptance criteria sit at the **feature level**, not per story | Less repetition. |
| Each criterion is testable | "Given X, when Y, then Z" or a clear assertion the system must satisfy. |
| Criteria cover cross-cutting truths the stories don't repeat | E.g. "all auth checks happen server-side", "S3 lifecycle policy: 90 days". |
| Acceptance criteria don't restate stories | If you can derive a criterion by reading the stories, drop it. Criteria add new constraints. |

### UI References checks

| Check | What good looks like |
|---|---|
| Figma link present for every feature with user-facing UI | If there's no Figma yet, write `TBD` and surface as a blocker — UI features can't ship without UI design. |
| For features with no UI (pure agent behavior, pure backend integration) | Explicit statement: *"No user-facing UI for this feature — purely agent behavior."* Don't leave the section blank. |

### Scope-purity checks

| Check | What to do |
|---|---|
| §4 has no infrastructure stories | Move out. SOW Excel covers infra. |
| §4 has no implementation-level stories ("write a function that…") | Reframe as user/system behavior or remove. |
| §4 doesn't add new requirements not in discovery | Stop. Change order required. |
| §4 doesn't drop discovery requirements | Stop. Change order required. |

---

## §5 API Schema (product surface)

| Check | What good looks like |
|---|---|
| Only user-facing entry points listed | "Send a chat message" yes. "AI Lambda → Bedrock" no. |
| Each entry point has trigger, request shape, response shape | All three present. |
| Request/response shapes are conceptual fields | `{userQuery, sessionId, authJWT}` yes. Full JSON schemas with types and constraints, no. |
| 3–8 entry points typical | Fewer = probably missed some. More = probably leaking internals. |

**Reject when:**
- Entries describe lambda-to-lambda or service-to-service calls.
- Entries describe vendor API calls (HubSpot, Bedrock, Shopify) that the *system* makes — that's developer territory.
- Entries include status codes, header specs, retry semantics, or error code matrices.

---

## §6 Storage & Persistence

| Check | What good looks like |
|---|---|
| Each bullet names what's stored, where (at storage-medium level), and retention | "Complex tickets stored in an S3 bucket. Retained 90 days, then auto-deleted." |
| 4–8 bullets typical | Each major persistent entity gets one. |
| No schema details | No partition keys, sort keys, field lists, indexes. |
| Retention decisions are PM-level | "Retained 90 days" — PM owns this. "TTL set to 7776000 seconds" — implementation. |

**Reject when:**
- A bullet describes a schema or table structure.
- A bullet specifies field-level details ("user ID stored as a UUID v4").
- A bullet describes implementation mechanics ("uses DynamoDB Streams to trigger…") — that's architecture.

---

## §7 Architecture

| Check | What good looks like |
|---|---|
| Lifted from discovery-spec §5, optionally enriched | Don't redo from scratch. |
| Changes-from-discovery subsection present if anything changed | Even if just one decision (specific model selected). |
| Stays at conceptual block-diagram level | Same boundary as discovery — boxes and arrows, not VPC subnets and IAM policies. |

**Reject when:**
- Architecture has been redrawn at infra-detail level.
- Changes-from-discovery omits decisions captured in §3 — they should appear in both.

---

## §8 Open Design Questions

| Check | What good looks like |
|---|---|
| Each question has owner, needed-by, and status | All four columns populated. |
| Resolved questions stay in the table | Don't delete on resolution — record the decision. |
| Questions are real decisions, not generic placeholders | "Should we use ML or rules?" — bad (too vague). "Should KB retrieval results cache across sessions or stay per-turn?" — good. |
| Owner is a named role or person | Not "TBD" or "the team". |

**Reject when:**
- The skill invented a question to fill the table — only PMs add questions.
- A question duplicates content elsewhere (an unresolved discovery assumption belongs in §3 marked unresolved, not here).

---

## §9 Sibling Artifacts

| Check | What good looks like |
|---|---|
| Links to `case.md`, `discovery-spec.md`, `eval.md`, `qa.md` | All four. `eval.md` and `qa.md` may be marked "to be created" if not yet. |
| Figma project URL if any | Lifted from feature-level UI references, deduped. |
| Architecture diagram path | If §7 references one. |
| Reader-orientation paragraph at end | "For the AI developer: read this + eval.md. For the SW developer: read this + Jira tickets." Helps newcomers find their way. |

---

## Cross-Section Consistency Checks

After every section is drafted, run these:

| Check | Action if it fails |
|---|---|
| Every story is under a requirement that exists in the discovery spec | Stop. Either remove the story or trigger a change order. |
| Every requirement from discovery has at least one story | Either add stories or surface that the requirement is intentionally without UI/system behavior (rare). |
| Every architecture component in §7 has at least one story or storage entry referencing it | Component without behavior or data isn't doing anything — remove or add the missing scope. |
| Every assumption resolved in §3 has consistent treatment elsewhere | If §3 says "Bedrock model: Claude Sonnet 4.6", §7 architecture should reflect that. |
| Every stored thing in §6 has at least one story that creates or reads it | Storage without behavior is dead weight. |
| Every new constraint in §3 is reflected in stories or acceptance criteria | If a constraint is binding but not visible in §4, it's either fictional or §4 is missing coverage. |
| Every Figma link in §4 is reachable | Run a quick check — broken links in a signed spec are embarrassing. |
| Every change order in §2 has corresponding scope/story changes in §4 | Otherwise the change order is a paper change without the actual work. |
| Every open question in §8 has a needed-by date before MVP target | Otherwise it's not actually blocking dev — surface for re-evaluation. |

These cross-section checks catch the most damaging dev-spec defects — the kind that turn into rework after dev kickoff.
