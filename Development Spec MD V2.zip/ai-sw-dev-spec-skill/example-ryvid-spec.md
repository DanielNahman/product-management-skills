---
client: Ryvid Inc.
project: AI Chatbot MVP
sow_number: SOW-3
project_type: ai_plus_sw
phase: development
status: draft
case_doc: ./case.md
linked_specs:
  discovery: ./discovery-spec.md
discovery_locked_at: 2026-05-15
budget_usd: 69550
funding_notes: "$65K AWS Incremental Workloads, $4,550 Ryvid"
delivery_partner: Commit
last_updated: 2026-05-20
---

# Ryvid — AI Chatbot MVP — Development Spec

> This spec extends the signed [discovery spec](./discovery-spec.md) with development-phase detail.
>
> **What's locked at signature** (inherited from discovery, change order required to modify): KPIs, NFRs, Customer-Provided Inputs, Out-of-Scope items, the list of features, and the discovery-level "shall" requirements.
>
> **What's added here:** detailed stories with UX and system behavior, feature-level acceptance criteria, high-level API and data shapes, resolved decisions, open design questions, and links to sibling artifacts.

---

## 1. Business Context

Ryvid is converting its validated PoC chatbot into a production MVP embedded in the Shopify storefront, grounded in their owner manuals/FAQs/playbooks, that deflects simple support tickets and writes structured tickets into HubSpot for complex ones.

See [`./case.md`](./case.md) for the full business case and [`./discovery-spec.md`](./discovery-spec.md) for the contracted scope.

---

## 2. Reference to Discovery Spec

The following items are **inherited from `./discovery-spec.md`** (signed 2026-05-15) and are NOT redefined here:

- **Success Criteria & KPIs** — see discovery-spec §2 (≥80% classification accuracy, ≥80% response correctness, ≥20 concurrent sessions, 99% stability).
- **Non-Functional Requirements** — see discovery-spec §3 (English only, multi-minute latency acceptable, Shopify auth, single prod env, etc.).
- **Out of Scope** — see discovery-spec §7 (no bidirectional HubSpot sync, no multi-env, no latency optimization, no usage dashboards, etc.).
- **Customer-Provided Inputs** — see discovery-spec §8.
- **Feature list and high-level "shall" requirements** — see discovery-spec §4.

**Change orders to date:** No change orders to date.

---

## 3. Resolved Assumptions & New Constraints

### Resolved assumptions

| Discovery assumption | Resolved decision | Resolved on |
|---|---|---|
| Prompt management via Langfuse OR AWS Prompt Management | **Langfuse**, hosted on Ryvid's AWS account, managed by Commit AI team | 2026-05-18 |
| Bedrock model selection (PoC used Claude Sonnet 3.5) | **Claude Sonnet 4.6** for the agent; **Claude Haiku 4.5** for the safety classifier | 2026-05-19 |
| Long-term memory store | **DynamoDB single-table design**, partitioned by user ID | 2026-05-19 |
| Knowledge Base ingestion trigger | **Manual trigger by Ryvid via AWS console + scheduled re-index every 24h** | 2026-05-20 |

### New constraints surfaced post-signature

- Ryvid's HubSpot account uses custom ticket properties for severity and bike model — JSON ticket schema must include these fields. (Surfaced by Ryvid CRM admin during integration kickoff.)
- Shopify session JWT expires after 30 minutes; chatbot must handle re-auth mid-conversation gracefully. (Surfaced during Shopify auth integration review.)

---

## 4. Scope

### Hierarchy

- **Epics, Features, and Requirements** are inherited from discovery-spec §4 (same names, IDs, descriptions).
- **Stories** (IDs `<epic>.<feature>.<requirement>.<story>`) are NEW in this spec.
- **Acceptance Criteria** sit at the feature level.

### ID conventions

- Story IDs: `<epic>.<feature>.<requirement>.<story>` (e.g. `1.1.3.4`).
- Append-only — never renumber.
- Story type inherits from parent requirement.

---

### Epic 1: Conversational Support Surface

The user-facing chatbot embedded in Ryvid's Shopify storefront — the page, the message UI, media uploads, and conversation history.

---

#### Feature 1.1: Chatbot Page on Shopify

A custom chatbot landing page hosted on Ryvid's Shopify domain, accessed by authenticated riders.

##### Requirement 1.1.1 (SW): The user shall access the chatbot via an authenticated landing page on Ryvid's Shopify domain.

**Stories:**

| ID | Story | UX / System Behavior |
|---|---|---|
| 1.1.1.1 | Authenticated user lands on chatbot page | User navigates to `/chat` on Ryvid's Shopify domain → Shopify auth middleware verifies JWT → page renders with empty thread or last-active thread restored. |
| 1.1.1.2 | Unauthenticated user blocked | User navigates to `/chat` without a valid Shopify session → redirected to Shopify's sign-in page → on success, returned to `/chat`. |
| 1.1.1.3 | Auth expires mid-session | Shopify JWT expires while user is in chat → next API call returns 401 → UI displays modal "Session expired. Please sign in again." with sign-in button → on re-auth, draft message preserved and chat resumes. |

##### Requirement 1.1.2 (SW): The chatbot page shall display message bubbles for both user and bot, each with a timestamp and avatar.

**Stories:**

| ID | Story | UX / System Behavior |
|---|---|---|
| 1.1.2.1 | User sends message → bubble appears | User taps send → user's message appears immediately as a right-aligned bubble with their Shopify avatar and the local timestamp. Send button disabled until response begins. |
| 1.1.2.2 | Bot response renders | Agent response streams in as a left-aligned bubble with Ryvid logo avatar and timestamp at the moment streaming completes. |
| 1.1.2.3 | Bot is "thinking" | After user sends → before first bot token → animated typing indicator (three dots) appears in left-aligned bubble. |
| 1.1.2.4 | Long messages | Bubbles wrap text with no horizontal scroll. Code blocks and links inside bot messages render with appropriate styling. |

##### Requirement 1.1.3 (SW): The chatbot page shall expose an input field, a send button, and an upload control.

**Stories:**

| ID | Story | UX / System Behavior |
|---|---|---|
| 1.1.3.1 | Input field accepts text | User types in input field → text appears as typed → input expands vertically up to 5 lines, then scrolls. |
| 1.1.3.2 | Send button states | Send button disabled when input is empty AND no media attached. Enabled when either condition met. Disabled while a message is in flight. |
| 1.1.3.3 | Send via keyboard | User presses Enter (without Shift) → message sends. Shift+Enter inserts a newline. |
| 1.1.3.4 | Upload control opens file picker | User taps upload icon → native OS file picker opens with image/video filter. |

##### Requirement 1.1.4 (SW): The user shall only reach the chatbot if Shopify has authenticated their session.

**Stories:**

| ID | Story | UX / System Behavior |
|---|---|---|
| 1.1.4.1 | Server-side auth gate on initial page load | First page request validates Shopify session JWT server-side. Invalid → 302 redirect to Shopify sign-in. Valid → page rendered. |
| 1.1.4.2 | Server-side auth gate on every API call | Every API call from chatbot UI → Shopify session JWT validated by Chatbot Lambda. Invalid → 401 returned, UI shows re-auth modal (see 1.1.1.3). |

##### Feature 1.1 — Acceptance Criteria

- All Shopify auth checks happen server-side; client never trusts client-side auth state alone.
- Avatars resolve from Shopify customer object (user) and a static Ryvid asset (bot).
- Chat page is responsive: usable on screens ≥ 360px wide. Input area always visible above the device keyboard on mobile.
- Send button never appears enabled when there is no valid content to send.
- All UI text is in English (per discovery NFR).

##### Feature 1.1 — UI References

- **Figma:** https://figma.com/file/ryvid-chatbot/main?node-id=1-1
- **Notes:** Chatbot page is a custom Shopify page template, not a Shopify app block. Routing is `ryvid.com/chat`. Design system inherits Ryvid's existing tokens (typography, color palette).

---

#### Feature 1.2: Media Uploads

The ability for the rider to attach images and short videos to a chat turn so the agent can reason over visual evidence.

##### Requirement 1.2.1 (SW): The user shall be able to upload images in JPEG or PNG format up to 50MB per file.

**Stories:**

| ID | Story | UX / System Behavior |
|---|---|---|
| 1.2.1.1 | User selects valid image | User picks JPEG/PNG ≤50MB → file appears as thumbnail in attachment slot above input. Send button enables (if not already). |
| 1.2.1.2 | User selects oversized image | User picks JPEG/PNG >50MB → inline validation message "File must be under 50MB" appears below upload control. No upload initiated. |
| 1.2.1.3 | User selects unsupported format | User picks file in unsupported format (e.g. HEIC, GIF) → inline validation "Accepted: JPEG, PNG, MP4". No upload initiated. |
| 1.2.1.4 | User removes attached image | User taps X on thumbnail → file removed from attachment slot, send button re-evaluates enabled state. |

##### Requirement 1.2.2 (SW): The user shall be able to upload videos in MP4 format up to 50MB per file.

**Stories:**

| ID | Story | UX / System Behavior |
|---|---|---|
| 1.2.2.1 | User selects valid video | User picks MP4 ≤50MB → first-frame thumbnail appears in attachment slot with play icon overlay. |
| 1.2.2.2 | User selects oversized video | User picks MP4 >50MB → same inline validation as 1.2.1.2. |

##### Requirement 1.2.3 (SW): The system shall store each uploaded file in a dedicated S3 bucket under a session-unique key.

**Stories:**

| ID | Story | UX / System Behavior |
|---|---|---|
| 1.2.3.1 | Upload initiated | After client-side validation passes → Chatbot Lambda requests pre-signed PUT URL from Media Upload Lambda → client uploads directly to S3 using returned URL. |
| 1.2.3.2 | S3 key format | S3 key generated as `sessions/<sessionId>/<uploadId>.<ext>` where uploadId is a server-generated UUID v7. |
| 1.2.3.3 | Upload progress visible | While upload is in progress → progress bar inside thumbnail shows percent complete. Send button disabled until upload completes. |
| 1.2.3.4 | Upload failure | Upload fails (network, S3 error) → thumbnail shows error state with "Tap to retry" → tap retries the same upload. After 3 failures, prompt user to re-select file. |

##### Requirement 1.2.4 (SW): The system shall issue a pre-signed URL for each uploaded file and pass it to the AI agent.

**Stories:**

| ID | Story | UX / System Behavior |
|---|---|---|
| 1.2.4.1 | Pre-signed GET URL on send | When user taps send with attached media → Chatbot Lambda generates pre-signed GET URLs (15-minute expiry) for each file → URLs included in payload to AI Lambda. |
| 1.2.4.2 | URL refresh on retry | If AI Lambda call fails and is retried → fresh pre-signed URLs generated (so URLs don't expire mid-retry). |

##### Feature 1.2 — Acceptance Criteria

- Client-side validation (size, format) blocks upload before any network call.
- Pre-signed PUT URLs expire after 5 minutes.
- Pre-signed GET URLs expire after 15 minutes.
- Files in S3 are encrypted at rest (SSE-S3) — inherited from NFR.
- S3 lifecycle policy: uploaded media auto-deleted 90 days after upload (matches ticket retention).
- Maximum one attached file per message (multi-attachment is out of scope).

##### Feature 1.2 — UI References

- **Figma:** https://figma.com/file/ryvid-chatbot/main?node-id=2-1
- **Notes:** Multi-file attachment is explicitly out of MVP scope (see discovery §7). Future SOW.

---

#### Feature 1.3: Conversation History

Persistent thread history per user, surfaced in a sidebar so riders can return to past conversations.

##### Requirement 1.3.1 (SW): The user shall be able to view a sidebar listing their past conversation threads.

**Stories:**

| ID | Story | UX / System Behavior |
|---|---|---|
| 1.3.1.1 | Sidebar opens on page load | When `/chat` loads → sidebar visible by default on desktop (≥1024px wide), collapsed behind a hamburger on mobile. |
| 1.3.1.2 | Threads listed by recency | Sidebar shows user's threads sorted by last-updated descending. Each row shows thread title (auto-generated from first user message, max 60 chars) and relative timestamp. |
| 1.3.1.3 | Active thread highlighted | The currently-open thread is visually distinguished (background shade + left border). |
| 1.3.1.4 | Empty state | New users with no threads → sidebar shows "No conversations yet" placeholder. |
| 1.3.1.5 | Long thread list | Sidebar scrolls independently of the main chat area when threads exceed viewport height. |

##### Requirement 1.3.2 (SW): The user shall be able to reopen any past thread and continue the conversation in it.

**Stories:**

| ID | Story | UX / System Behavior |
|---|---|---|
| 1.3.2.1 | Open a past thread | User taps a thread in sidebar → main chat area replaces current thread with selected thread's messages, scrolled to bottom. Input cleared. |
| 1.3.2.2 | Resume conversation | User sends new message in reopened thread → message appended to existing thread, sent to AI Lambda with the thread's context (last 10 turns). |
| 1.3.2.3 | New thread button | Sidebar exposes a "+ New conversation" control → tapping creates an empty thread, makes it active, clears the main chat area. |

##### Requirement 1.3.3 (SW): The system shall start each new thread with empty short-term context.

**Stories:**

| ID | Story | UX / System Behavior |
|---|---|---|
| 1.3.3.1 | New thread → empty context | When a new thread is created → AI Lambda's first call for that thread receives no prior turns in `conversationHistory` (long-term memory may still inject user context). |

##### Feature 1.3 — Acceptance Criteria

- Thread auto-title generation runs server-side after first user message; truncates at 60 chars and strips trailing whitespace.
- Threads persist indefinitely while user account is active. No auto-deletion.
- Sidebar list pagination: load most-recent 50 threads on initial render, fetch older threads on scroll.
- Reopened threads preserve message order and timestamps exactly as originally sent.
- Active thread state survives page refresh (last-active thread ID stored in user record).

##### Feature 1.3 — UI References

- **Figma:** https://figma.com/file/ryvid-chatbot/main?node-id=3-1
- **Notes:** Thread deletion / archiving by the user is out of MVP scope.

---

### Epic 2: Agentic Response & Triage

What the AI agent does once a user message arrives — retrieving grounded answers, interpreting media, deciding simple vs complex, and either answering or producing a structured ticket.

---

#### Feature 2.1: RAG-Grounded Responses

The agent answers user questions using retrieval over Ryvid's owner manuals, FAQs, and diagnostic playbooks.

##### Requirement 2.1.1 (AI): The agent shall retrieve relevant passages from the Knowledge Base before composing a response.

**Stories:**

| ID | Story | UX / System Behavior |
|---|---|---|
| 2.1.1.1 | Agent invokes KB retrieval tool on every user message | For every incoming user message → agent calls KB retriever as the first tool, regardless of message complexity. |
| 2.1.1.2 | Retrieval returns top-K passages with citations | KB retriever returns top 5 passages with source filename and section reference. Agent has visibility to all 5 in its context. |
| 2.1.1.3 | No relevant passages found | If KB returns zero passages above similarity threshold → agent surfaces this in reasoning and either asks a clarifying question or escalates to Complex. |

##### Requirement 2.1.2 (AI): The agent shall ground every answer in retrieved Knowledge Base content rather than uninformed model output.

*(Stories continue — abbreviated here for the example.)*

| ID | Story | UX / System Behavior |
|---|---|---|
| 2.1.2.1 | Answer cites at least one KB passage | Every Simple-classified answer references at least one KB passage in its reasoning trace (visible to evaluators, not necessarily to user). |
| 2.1.2.2 | Out-of-scope question handling | If user question has no grounding in KB → agent says "I don't have information on that — let me connect you with a human" and escalates to Complex. |

##### Feature 2.1 — Acceptance Criteria

- KB retrieval similarity threshold set to ≥0.7 cosine similarity (tunable post-launch via Langfuse).
- Top-K = 5 passages.
- Agent's reasoning trace logged to Langfuse for every turn — includes which passages were retrieved and which were cited.
- Eval set must include cases that test: in-KB questions, out-of-KB questions, ambiguous questions, multi-document questions.

##### Feature 2.1 — UI References

- *(No user-facing UI for retrieval mechanics — this feature is purely agent behavior.)*

---

> **Note:** The remaining features and requirements of Epic 2 (2.2 Image Interpretation, 2.3 Diagnostic Question Generation, 2.4 Conversation Memory, 2.5 Safety Guardrails) and Epic 3 (3.1 Structured Ticket Output, 3.2 HubSpot Integration) follow the same shape: discovery-level requirement (verbatim from discovery-spec §4) → stories table → feature-level acceptance criteria → UI references (or note that there is no UI). Abbreviated here for example purposes.

---

## 5. API Schema (product surface)

> The user-facing input/output of the product only — what flows in and out at the chatbot's edge. Internal APIs between lambdas, services, and external systems (Bedrock, HubSpot) are the developer's design work and are not specified here.

**Send a chat message**
- Trigger: user taps send in the chatbot UI (with optional attached media).
- Request: `{userQuery, sessionId, threadId, authJWT, attachedMedia?}`.
- Response: `{assistantResponse, ticketEmitted, error?}`.

**Attach a file**
- Trigger: user picks a file via the upload control before sending.
- Request: `{filename, contentType, sizeBytes, sessionId, authJWT}`.
- Response: `{uploadURL, error?}` — the UI uses `uploadURL` to send the file directly to storage.

**List my conversation threads**
- Trigger: chatbot page loads, or user refreshes the sidebar.
- Request: `{authJWT}`.
- Response: `{threads: [{id, title, lastUpdatedAt}]}`.

**Open a past thread**
- Trigger: user taps a thread in the sidebar.
- Request: `{threadId, authJWT}`.
- Response: `{threadId, title, messages: [{role, content, timestamp, mediaRefs}]}`.

---

## 6. Storage & Persistence

> A storage inventory: what gets stored, where (at the bucket/database level), and the retention or scope decisions the PM owns. Schemas, table structures, and field-level design are the developer's work and are not specified here.

- **Complex tickets (JSON):** stored in an S3 bucket. Each ticket persisted on emission and consumed by the HubSpot integration. Retained 90 days, then auto-deleted.
- **Conversation history:** stored in a database. Includes thread metadata (title, timestamps) and per-turn messages. Persisted indefinitely while the user's account is active. No auto-deletion.
- **Long-term user memory:** stored across sessions so the agent can recall user preferences and factual context (e.g. which bike model they own). Persisted indefinitely while the user's account is active.
- **Uploaded media (images, videos):** stored in an S3 bucket, scoped per session. Auto-deleted 90 days after upload (matches ticket retention so referenced media is available while the ticket is live).

---

## 7. Architecture

```
Shopify (auth'd rider)
   └─ Embedded Chatbot UI (Ryvid domain, /chat)
        └─ API Gateway → Chatbot Lambda (session, routing, uploads)
             ├─ Media Upload Lambda → S3 (ryvid-chatbot-uploads-prod, session-scoped, pre-signed)
             ├─ DynamoDB (threads, messages)
             └─ AI Lambda (Bedrock agent: Claude Sonnet 4.6)
                   ├─ Tool: KB retriever → Bedrock Knowledge Base (RAG, top-K=5)
                   ├─ Tool: Image interpreter (Bedrock vision)
                   ├─ Tool: JSON ticket writer → S3 (ryvid-chatbot-tickets-prod)
                   ├─ Memory: short-term (10-turn context from DDB) + long-term (DDB ryvid-chatbot-memory)
                   └─ Guardrails: safety classifier (Claude Haiku 4.5)
        └─ Ticket Integration Lambda (S3 event → HubSpot Tickets API, unidirectional)

Observability: Langfuse for agent traces, CloudWatch for lambda logs.
```

**Changes from discovery architecture:**
- Bedrock model selected: Claude Sonnet 4.6 (was "TBD" at discovery).
- Safety classifier separated as Claude Haiku 4.5 — cheaper than running full agent on every safety check.
- Thread/message persistence: DynamoDB (was unspecified at discovery).
- Long-term memory: DynamoDB single-table design partitioned by user ID.

---

## 8. Open Design Questions

| ID | Question | Owner | Needed By | Status | Resolution |
|---|---|---|---|---|---|
| Q-1 | Should we cache KB retrieval results across sessions, or keep retrieval per-turn? Affects latency vs freshness when KB is updated. | AI architect | 2026-06-01 | open | |
| Q-2 | Auto-title generation for threads — generate after first user message, or after first assistant response (so it can use context)? | AI PM | 2026-06-05 | open | |
| Q-3 | Re-auth flow when JWT expires mid-stream — preserve partial assistant response or discard and restart? | SW architect | 2026-06-10 | open | |
| Q-4 | Long-term memory write triggers — agent decides which facts to persist, or PM-defined heuristic? | AI PM + AI architect | 2026-06-12 | open | |
| Q-5 | Ticket retention period for HubSpot-synced tickets — does Ryvid want S3 copies retained beyond 90 days for audit? | Ryvid CRM admin | 2026-06-01 | resolved | 90 days confirmed sufficient by Ryvid; matches HubSpot retention. (Resolved 2026-05-22.) |

---

## 9. Sibling Artifacts

- [`./case.md`](./case.md) — business context.
- [`./discovery-spec.md`](./discovery-spec.md) — signed discovery spec (locked 2026-05-15).
- `./eval.md` — eval set definition. *To be created by the eval-md skill before AI dev kickoff.*
- `./eval-set.csv` — populated by Ryvid (≥30 items per discovery §8).
- `./qa.md` — QA / E2E test plan. *To be created before UAT.*
- Figma project: https://figma.com/file/ryvid-chatbot/main
- Architecture diagram: `./architecture.png`

**For the AI developer:** read this file + `eval.md`. Stories under `AI`-typed requirements (epics 2 and parts of 3) are your capability spec.

**For the SW developer:** read this file + the Jira tickets generated from it. Stories under `SW`-typed requirements (epic 1 and parts of 3) become Jira stories grouped under feature- and epic-level Jira issues.
